import { createRouter, createWebHistory } from 'vue-router'
import { message } from 'ant-design-vue'
import { useAuth } from '@/composables/useAuth'

const router = createRouter({
  history: createWebHistory('/admin/'),
  routes: [
    { path: '/login', component: () => import('@/views/LoginView.vue'), meta: { public: true } },
    { path: '/', redirect: '/dashboard' },
    {
      path: '/dashboard',
      component: () => import('@/views/DashboardView.vue'),
      meta: { title: 'Dashboard' },
    },
    {
      path: '/destinations',
      component: () => import('@/views/DestinationsView.vue'),
      meta: { title: 'Destinations' },
    },
    {
      path: '/subscriptions',
      component: () => import('@/views/SubscriptionsView.vue'),
      meta: { title: 'Subscriptions' },
    },
    {
      path: '/data-flow',
      component: () => import('@/views/DataExplorer.vue'),
      meta: { title: 'Data Flow' },
    },
    {
      path: '/sources',
      component: () => import('@/views/SourcesView.vue'),
      meta: { title: 'Sources' },
    },
    {
      path: '/devices',
      component: () => import('@/views/DevicesView.vue'),
      meta: { title: 'Devices' },
    },
    {
      path: '/assets',
      component: () => import('@/views/AssetsView.vue'),
      meta: { title: 'Assets' },
    },
    // Maintenance and Energy were merged into tabs on /assets to shorten the
    // sidebar — redirect old bookmarks/links rather than 404 them.
    { path: '/maintenance', redirect: '/assets' },
    { path: '/energy', redirect: '/assets' },
    {
      path: '/discovery-rules',
      component: () => import('@/views/DiscoveryRulesView.vue'),
      meta: { title: 'Discovery' },
    },
    {
      path: '/applications',
      component: () => import('@/views/ContainersView.vue'),
      meta: { title: 'Applications' },
    },
    {
      path: '/marketplace',
      component: () => import('@/views/MarketplaceView.vue'),
      meta: { title: 'Marketplace' },
    },
    {
      path: '/anomaly',
      component: () => import('@/views/AnomalyView.vue'),
      meta: { title: 'Analytics' },
    },
    {
      path: '/network',
      component: () => import('@/views/NetworkView.vue'),
      meta: { title: 'Network' },
    },
    {
      path: '/terminal',
      component: () => import('@/views/TerminalView.vue'),
      meta: { title: 'Terminal' },
    },
    {
      path: '/logs',
      component: () => import('@/views/LogsView.vue'),
      meta: { title: 'Logs' },
    },
    {
      path: '/settings',
      component: () => import('@/views/SettingsView.vue'),
      meta: { title: 'Settings' },
    },
    {
      path: '/admin/users',
      component: () => import('@/views/UsersView.vue'),
      meta: { title: 'Users', minRole: 'admin' },
    },
    {
      path: '/admin/mqtt-users',
      redirect: '/mqtt-broker?tab=users',
    },
    {
      path: '/admin/backups',
      component: () => import('@/views/BackupsView.vue'),
      meta: { title: 'Backups', minRole: 'admin' },
    },
    {
      path: '/user/profile',
      component: () => import('@/views/ProfileView.vue'),
      meta: { title: 'Profile' },
    },
    {
      path: '/support',
      component: () => import('@/views/SupportView.vue'),
      meta: { title: 'Support' },
    },
    {
      path: '/mqtt-broker',
      component: () => import('@/views/MqttBrokerView.vue'),
      meta: { title: 'MQTT Broker' },
    },
  ],
})

let authChecked = false

router.beforeEach(async (to) => {
  if (to.meta.public) return true
  if (!authChecked) {
    const { checkAuth } = useAuth()
    await checkAuth()
    authChecked = true
  }
  const { currentUser, hasRole } = useAuth()
  if (!currentUser.value) return { path: '/login' }
  if (currentUser.value.must_change_password && to.path !== '/user/profile') {
    return { path: '/user/profile' }
  }
  const minRole = to.meta.minRole as 'viewer' | 'operator' | 'admin' | undefined
  if (minRole && !hasRole(minRole)) {
    message.warning(`You need the "${minRole}" role or higher to access ${(to.meta.title as string | undefined) ?? 'this page'}.`)
    return { path: '/dashboard' }
  }
  return true
})

export default router
