<script setup lang="ts">
import { ref, computed, onMounted, watch, h } from 'vue'
import { useRoute } from 'vue-router'
import { message, Modal } from 'ant-design-vue'
import type { TableColumnType } from 'ant-design-vue'
import {
  SaveOutlined, ReloadOutlined, LinkOutlined, CheckCircleOutlined, EditOutlined,
  QuestionCircleOutlined, CloudDownloadOutlined, ExclamationCircleOutlined,
} from '@ant-design/icons-vue'
import AppLayout from '@/components/layout/AppLayout.vue'
import { useAuth } from '@/composables/useAuth'
import { settingsApi } from '@/api/settings'
import { client as apiClient } from '@/api/client'
import { dockerConfigApi } from '@/api/containers'
import type { DockerConfig } from '@/api/containers'
import type { AgentSettings, AnomalyConfig, Destination } from '@/types'
import { dashboardApi, type CanonicalUnit, type CustomUnitAlias } from '@/api/dashboard'
import { anomalyApi, type DriftOptions, type DriftAlertType } from '@/api/anomaly'
import { destinationsApi } from '@/api/destinations'
import { licenseApi } from '@/api/license'
import type { LicenseStatus } from '@/api/license'
import { updateApi } from '@/api/update'
import type { UpdateCheckResult } from '@/api/update'

const route = useRoute()
const { hasRole } = useAuth()

const VALID_TABS = ['agent', 'features', 'logging', 'intervals', 'docker', 'units', 'alerts', 'license', 'state']
const activeTab = ref(
  typeof route.query.tab === 'string' && VALID_TABS.includes(route.query.tab) ? route.query.tab : 'agent'
)

const loading = ref(false)
const saving = ref(false)
const saved = ref(false)
const loadError = ref<string | null>(null)

const settings = ref<AgentSettings>({})

// Deep clone for "discard changes" reset
let lastSaved: AgentSettings = {}

onMounted(() => { load(); loadDockerConfig(); loadCustomAliases(); loadAlertConfig(); loadAlertDrift(); loadLicense() })

async function load() {
  loading.value = true
  loadError.value = null
  try {
    settings.value = await settingsApi.get()
    lastSaved = JSON.parse(JSON.stringify(settings.value))

  } catch (e: any) {
    loadError.value = e?.message ?? 'Failed to load settings'
  } finally {
    loading.value = false
  }
}

async function save() {
  saving.value = true
  saved.value = false
  try {
    // Omit the read-only `agent` field before sending
    const { agent: _agent, ...patch } = settings.value
    settings.value = await settingsApi.update(patch)
    lastSaved = JSON.parse(JSON.stringify(settings.value))
    saved.value = true
    message.success('Settings saved')
  } catch (e: any) {
    message.error(e?.message ?? 'Save failed')
  } finally {
    saving.value = false
  }
}

function discard() {
  settings.value = JSON.parse(JSON.stringify(lastSaved))
  saved.value = false
  message.info('Changes discarded')
}

// ── target sync toggle ────────────────────────────────────────────────────────

const targetSyncSaving = ref(false)

async function setTargetSync(enabled: boolean) {
  targetSyncSaving.value = true
  try {
    const { data } = await apiClient.patch('/v1/settings/target-sync', { enabled })
    settings.value = data.settings
    lastSaved = JSON.parse(JSON.stringify(settings.value))
    message.success(enabled ? 'Target sync enabled — agent will now pull cloud state' : 'Target sync disabled — agent reports only')
  } catch (e: any) {
    message.error(e?.message ?? 'Failed to update target sync')
  } finally {
    targetSyncSaving.value = false
  }
}

// ── provisioning ───────────────────────────────────────────────────────────────

const provisioning = ref(false)
const provisionForm = ref({ key: '', apiEndpoint: '', deviceName: '' })

async function provision() {
  if (!provisionForm.value.key.trim()) {
    message.error('Provisioning key is required')
    return
  }
  provisioning.value = true
  try {
    await settingsApi.provision({
      provisioningApiKey: provisionForm.value.key.trim(),
      ...(provisionForm.value.apiEndpoint.trim() ? { apiEndpoint: provisionForm.value.apiEndpoint.trim() } : {}),
      ...(provisionForm.value.deviceName.trim() ? { deviceName: provisionForm.value.deviceName.trim() } : {}),
    })
    message.success('Agent provisioned successfully')
    // Reload settings so Agent Info reflects the new provisioned state
    await load()
    provisionForm.value = { key: '', apiEndpoint: '', deviceName: '' }
  } catch (e: any) {
    message.error(e?.response?.data?.message ?? e?.message ?? 'Provisioning failed')
  } finally {
    provisioning.value = false
  }
}

// ── helpers ────────────────────────────────────────────────────────────────────

function msToHuman(ms: number | undefined): string {
  if (ms == null) return ''
  if (ms >= 86_400_000) return `${ms / 86_400_000}d`
  if (ms >= 3_600_000) return `${ms / 3_600_000}h`
  if (ms >= 60_000) return `${ms / 60_000}m`
  return `${ms / 1000}s`
}

function ensureLogging() {
  if (!settings.value.logging) settings.value.logging = {}
}
function ensureFeatures() {
  if (!settings.value.features) settings.value.features = {}
}
function ensureIntervals() {
  if (!settings.value.intervals) settings.value.intervals = {}
  if (!settings.value.intervals.agent) settings.value.intervals.agent = {}
}
function ensureRuntime() {
  if (!settings.value.runtime) settings.value.runtime = {}
  if (!settings.value.runtime.memory) settings.value.runtime.memory = {}
}

// ── Docker daemon config ──────────────────────────────────────────────────────

const dockerConfig = ref<DockerConfig>({ type: 'socket' })
const dockerLoading = ref(false)
const dockerSaving = ref(false)
const dockerTesting = ref(false)
const dockerTestResult = ref<{ version: string; containers: number } | null>(null)
const dockerTestError = ref<string | null>(null)

async function loadDockerConfig() {
  dockerLoading.value = true
  try {
    dockerConfig.value = await dockerConfigApi.get()
  } catch {
    // non-fatal — defaults to socket
  } finally {
    dockerLoading.value = false
  }
}

async function saveDockerConfig() {
  dockerSaving.value = true
  dockerTestResult.value = null
  dockerTestError.value = null
  try {
    await dockerConfigApi.save(dockerConfig.value)
    message.success('Docker configuration saved')
  } catch (e: any) {
    message.error(e?.message ?? 'Failed to save Docker config')
  } finally {
    dockerSaving.value = false
  }
}

async function testDockerConnection() {
  dockerTesting.value = true
  dockerTestResult.value = null
  dockerTestError.value = null
  try {
    dockerTestResult.value = await dockerConfigApi.test(dockerConfig.value)
  } catch (e: any) {
    dockerTestError.value = e?.response?.data?.error ?? e?.message ?? 'Connection failed'
  } finally {
    dockerTesting.value = false
  }
}

function onDockerTypeChange() {
  dockerTestResult.value = null
  dockerTestError.value = null
}

// ── Units: custom unit mappings ─────────────────────────────────────────────
// Admin-created unit aliases (the Dashboard's Normalization Health "Resolve"
// action) — view/edit only here, reusing that same backend infrastructure
// (custom_unit_aliases table, POST /v1/normalization-health/resolve-unit).
// No create/delete in v1 — creating happens via Resolve on the Dashboard.

const customAliasColumns: TableColumnType<CustomUnitAlias>[] = [
  { title: 'Alias', dataIndex: 'alias', key: 'alias', ellipsis: true },
  { title: 'Protocol / Source System', key: 'source_system', width: 180 },
  { title: 'Canonical Unit', dataIndex: 'canonical_unit', key: 'canonical_unit', width: 180 },
  { title: 'Actions', key: 'actions', width: 90 },
]

const customAliases = ref<CustomUnitAlias[]>([])
const customAliasesLoading = ref(false)

async function loadCustomAliases() {
  customAliasesLoading.value = true
  try {
    customAliases.value = await dashboardApi.getCustomUnitAliases()
  } catch (e: any) {
    message.error(e?.message ?? 'Failed to load custom unit mappings')
  } finally {
    customAliasesLoading.value = false
  }
}

const canonicalUnits = ref<CanonicalUnit[]>([])
const canonicalUnitsLoaded = ref(false)
const canonicalUnitOptions = computed(() =>
  canonicalUnits.value.map((u) => ({
    value: u.canonical_unit,
    label: u.symbol ? `${u.canonical_unit} (${u.symbol})` : u.canonical_unit,
  })),
)

function ensureCanonicalUnitsLoaded() {
  if (canonicalUnitsLoaded.value) return
  dashboardApi.getCanonicalUnits()
    .then((units) => {
      canonicalUnits.value = units
      canonicalUnitsLoaded.value = true
    })
    .catch(() => {
      /* the picker will just show no options; not fatal */
    })
}

const editAliasModalOpen = ref(false)
const editAliasTarget = ref<CustomUnitAlias | null>(null)
const editAliasCanonicalUnit = ref<string | undefined>(undefined)
const editAliasSaving = ref(false)

function openEditAlias(row: CustomUnitAlias) {
  ensureCanonicalUnitsLoaded()
  editAliasTarget.value = row
  editAliasCanonicalUnit.value = row.canonical_unit
  editAliasModalOpen.value = true
}

function closeEditAlias() {
  editAliasModalOpen.value = false
  editAliasTarget.value = null
}

async function submitEditAlias() {
  if (!editAliasTarget.value || !editAliasCanonicalUnit.value) return
  editAliasSaving.value = true
  try {
    await dashboardApi.resolveUnknownUnit(editAliasTarget.value.alias, editAliasTarget.value.source_system, editAliasCanonicalUnit.value)
    message.success(`"${editAliasTarget.value.alias}" now maps to ${editAliasCanonicalUnit.value}`)
    closeEditAlias()
    await loadCustomAliases()
  } catch (err: any) {
    message.error(err?.message ?? 'Failed to update mapping')
  } finally {
    editAliasSaving.value = false
  }
}

function setLogging<K extends keyof NonNullable<AgentSettings['logging']>>(
  key: K,
  val: NonNullable<AgentSettings['logging']>[K],
) {
  ensureLogging()
  settings.value.logging![key] = val
}
function setFeature<K extends keyof NonNullable<AgentSettings['features']>>(
  key: K,
  val: NonNullable<AgentSettings['features']>[K],
) {
  ensureFeatures()
  settings.value.features![key] = val
}
function setAgentInterval<K extends keyof NonNullable<NonNullable<AgentSettings['intervals']>['agent']>>(
  key: K,
  val: number,
) {
  ensureIntervals()
  settings.value.intervals!.agent![key] = val
}
function setMemory<K extends keyof NonNullable<NonNullable<AgentSettings['runtime']>['memory']>>(
  key: K,
  val: number,
) {
  ensureRuntime()
  settings.value.runtime!.memory![key] = val
}

// ── Alerts (anomaly detection + schema drift) config ─────────────────────────
const alertConfig = ref<AnomalyConfig | null>(null)
const alertConfigLoading = ref(false)
const alertConfigSaving = ref(false)
const alertMqttDestinations = ref<Destination[]>([])

async function loadAlertConfig() {
  alertConfigLoading.value = true
  try {
    const [cfg, dests] = await Promise.all([
      anomalyApi.getConfig(),
      destinationsApi.getAll(),
    ])
    alertConfig.value = cfg
    alertMqttDestinations.value = dests.filter((d) => d.type === 'mqtt')
  } catch {
    // non-fatal
  } finally {
    alertConfigLoading.value = false
  }
}

function resetAlertDetectionDefaults() {
  if (!alertConfig.value) return
  alertConfig.value.sensitivity = 5
  alertConfig.value.warmupPeriodMs = 900_000
  alertConfig.value.alerts.minConfidence = 0.7
  alertConfig.value.alerts.cooldownMs = 300_000
  alertConfig.value.alerts.maxQueueSize = 1000
}

// ── Schema Drift settings ────────────────────────────────────────────────────
const DRIFT_ALERT_TYPE_OPTIONS: { value: DriftAlertType; label: string; hint: string }[] = [
  { value: 'missing-field', label: 'Missing field', hint: 'A field stopped appearing — usually real breakage.' },
  { value: 'type-drift', label: 'Type drift', hint: "A field's value type changed unexpectedly — usually real breakage." },
  { value: 'new-field', label: 'New field', hint: 'A field appeared that wasn’t in the learned baseline — often just normal growth.' },
  { value: 'rename-candidate', label: 'Rename candidate', hint: 'A missing field and a new field look like they might be the same field renamed.' },
]
const DEFAULT_ALERT_DRIFT_TYPES: DriftAlertType[] = ['missing-field', 'type-drift']

const globalDrift = ref<DriftOptions>({})
const driftLoading = ref(false)


async function loadAlertDrift() {
  driftLoading.value = true
  try {
    const { outputs } = await anomalyApi.getProtocolOutputs()
    const withDrift = outputs.find((o) => o.drift_options)
    globalDrift.value = withDrift?.drift_options ?? {}
  } catch {
    // non-fatal
  } finally {
    driftLoading.value = false
  }
}

function setDrift<K extends keyof DriftOptions>(key: K, val: DriftOptions[K]) {
  globalDrift.value[key] = val
}

// ── Sensitivity presets ──────────────────────────────────────────────────────
type SensitivityLevel = 'low' | 'standard' | 'high'

type SensitivityFields = Required<Pick<DriftOptions,
  'consecutiveMissingThreshold' | 'minFieldPresenceRatio' | 'adaptivePromotionBatches' |
  'adaptivePromotionMinElapsedMs' | 'minTypeDominanceRatio'
>>

const SENSITIVITY_PRESETS: Record<SensitivityLevel, SensitivityFields> = {
  low: {
    consecutiveMissingThreshold: 30,
    minFieldPresenceRatio: 0.2,
    adaptivePromotionBatches: 20,
    adaptivePromotionMinElapsedMs: 300_000,
    minTypeDominanceRatio: 0.1,
  },
  standard: {
    consecutiveMissingThreshold: 10,
    minFieldPresenceRatio: 0.5,
    adaptivePromotionBatches: 50,
    adaptivePromotionMinElapsedMs: 600_000,
    minTypeDominanceRatio: 0.15,
  },
  high: {
    consecutiveMissingThreshold: 3,
    minFieldPresenceRatio: 0.8,
    adaptivePromotionBatches: 100,
    adaptivePromotionMinElapsedMs: 1_800_000,
    minTypeDominanceRatio: 0.25,
  },
}

const SENSITIVITY_LEVELS: SensitivityLevel[] = ['low', 'standard', 'high']

const selectedSensitivity = computed<SensitivityLevel | 'custom'>(() => {
  for (const level of SENSITIVITY_LEVELS) {
    const preset = SENSITIVITY_PRESETS[level]
    const matches = (Object.keys(preset) as Array<keyof SensitivityFields>).every(
      (key) => (globalDrift.value[key] ?? SENSITIVITY_PRESETS.standard[key]) === preset[key],
    )
    if (matches) return level
  }
  return 'custom'
})

function setSensitivityPreset(level: SensitivityLevel) {
  const preset = SENSITIVITY_PRESETS[level]
  for (const key of Object.keys(preset) as Array<keyof SensitivityFields>) {
    setDrift(key, preset[key])
  }
}


const ALERT_FREQUENCY_OPTIONS: { value: number; label: string }[] = [
  { value: 5 * 60_000, label: '5 minutes' },
  { value: 15 * 60_000, label: '15 minutes' },
  { value: 30 * 60_000, label: '30 minutes' },
  { value: 60 * 60_000, label: '1 hour' },
  { value: 6 * 60 * 60_000, label: '6 hours' },
  { value: 24 * 60 * 60_000, label: '24 hours' },
]

function fmtCustomCooldown(ms: number): string {
  const minutes = Math.round(ms / 60_000)
  return minutes < 60 ? `${minutes}m` : `${(minutes / 60).toFixed(minutes % 60 === 0 ? 0 : 1)}h`
}

const alertFrequencyOptions = computed(() => {
  const current = globalDrift.value.alertCooldownMs ?? 1_800_000
  if (ALERT_FREQUENCY_OPTIONS.some((o) => o.value === current)) return ALERT_FREQUENCY_OPTIONS
  return [...ALERT_FREQUENCY_OPTIONS, { value: current, label: `Custom (${fmtCustomCooldown(current)})` }]
})

// ── License ──────────────────────────────────────────────────────────────────

const licenseStatus = ref<LicenseStatus | null>(null)
const licenseLoading = ref(false)
const licenseActivating = ref(false)
const licenseKey = ref('')

async function loadLicense() {
  licenseLoading.value = true
  try {
    licenseStatus.value = await licenseApi.getStatus()
  } catch { /* non-fatal */ }
  finally { licenseLoading.value = false }
}

async function activatePaid() {
  const key = licenseKey.value.trim()
  if (!key) { message.error('Please enter a license key'); return }
  licenseActivating.value = true
  try {
    licenseStatus.value = await licenseApi.activatePaid(key)
    licenseKey.value = ''
    message.success('License activated')
  } catch (e: unknown) {
    message.error((e as any)?.response?.data?.message ?? (e as any)?.message ?? 'License activation failed')
  } finally { licenseActivating.value = false }
}

const licenseStateLabel = computed(() => {
  const map: Record<string, string> = {
    unlicensed: 'Unlicensed',
    trial: 'Trial',
    trial_expired: 'Trial Expired',
    paid: 'Licensed',
    paid_expired: 'License Expired',
  }
  return map[licenseStatus.value?.state ?? ''] ?? licenseStatus.value?.state ?? '—'
})

const licenseStateBadge = computed(() => {
  const map: Record<string, string> = {
    unlicensed: 'default',
    trial: 'processing',
    trial_expired: 'error',
    paid: 'success',
    paid_expired: 'warning',
  }
  return map[licenseStatus.value?.state ?? ''] ?? 'default'
})

function formatExpiryDate(ts?: number | null): string {
  if (ts === undefined || ts === null) return 'Never (perpetual)'
  return new Date(ts).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })
}

// ── Agent Update ────────────────────────────────────────────────────────────

const updateInfo = ref<UpdateCheckResult | null>(null)
const updateChecking = ref(false)
const updateTriggering = ref(false)

async function checkForUpdate(force = false) {
  updateChecking.value = true
  try {
    updateInfo.value = await updateApi.check(force)
    if (settings.value.agent) settings.value.agent.version = updateInfo.value.currentVersion
    window.dispatchEvent(new CustomEvent('iotistica:agent-version-updated', {
      detail: { version: updateInfo.value.currentVersion },
    }))
  } catch (e: unknown) {
    message.error((e as any)?.response?.data?.message ?? (e as any)?.message ?? 'Update check failed')
  } finally { updateChecking.value = false }
}

function confirmUpdate() {
  if (!updateInfo.value?.latestVersion) return
  const version = updateInfo.value.latestVersion
  Modal.confirm({
    title: 'Update Agent',
    icon: h(ExclamationCircleOutlined),
    content: `Update to v${version}? The agent will restart during the update.`,
    okText: 'Update Now',
    okType: 'primary',
    onOk: () => triggerUpdate(version),
  })
}

async function triggerUpdate(version: string) {
  updateTriggering.value = true
  try {
    await updateApi.trigger(version)
    message.success('Update started — the agent will restart shortly')
  } catch (e: unknown) {
    message.error((e as any)?.response?.data?.message ?? (e as any)?.message ?? 'Failed to trigger update')
  } finally { updateTriggering.value = false }
}

async function saveAllAlertConfig() {
  alertConfigSaving.value = true
  try {
    const tasks: Promise<unknown>[] = [
      anomalyApi.updateDrift(globalDrift.value),
    ]
    if (alertConfig.value) {
      tasks.push(anomalyApi.updateConfig(alertConfig.value).then((c) => { alertConfig.value = c }))
    }
    await Promise.all(tasks)
    message.success('Configuration saved')
  } catch (err: unknown) {
    const e = err as { message?: string }
    message.error(e?.message ?? 'Save failed')
  } finally {
    alertConfigSaving.value = false
  }
}

// ── Agent State ──────────────────────────────────────────────────────────────

const stateData = ref<{ current?: any; target?: any } | null>(null)
const stateLoading = ref(false)
const stateLoaded = ref(false)

async function loadState() {
  stateLoading.value = true
  try {
    const { data } = await apiClient.get('/v1/state')
    stateData.value = data
  } catch (e: any) {
    message.error(e?.message ?? 'Failed to load state')
  } finally {
    stateLoading.value = false
    stateLoaded.value = true
  }
}

watch(activeTab, (tab) => {
  if (tab === 'state' && !stateLoaded.value) loadState()
})
</script>

<template>
  <AppLayout title="Settings">
    <div class="heading">
      <p>Agent configuration — protocols, intervals, and integrations.</p>
    </div>

    <!-- Global alerts -->
    <a-alert
      v-if="saved"
      type="info"
      show-icon
      message="Settings saved — changes take effect on the next reconciliation cycle (~30 seconds)."
      closable
      style="margin-bottom: 16px"
      @close="saved = false"
    />
    <a-alert
      v-if="loadError"
      type="error"
      show-icon
      :message="loadError"
      style="margin-bottom: 16px"
    >
      <template #action>
        <a-button size="small" @click="load">
          <template #icon><ReloadOutlined /></template>
          Retry
        </a-button>
      </template>
    </a-alert>

    <a-spin :spinning="loading">
      <div class="settings-shell">
      <a-tabs v-model:active-key="activeTab" class="settings-tabs">

        <!-- ══ AGENT ══════════════════════════════════════════════════════════ -->
        <a-tab-pane key="agent" tab="Agent">
          <a-card size="small" class="settings-card">
            <a-descriptions :column="{ xs: 1, sm: 1, md: 2 }" size="small" bordered class="agent-descriptions">
              <a-descriptions-item label="UUID" :span="2">
                <a-typography-text copyable :content="settings.agent?.uuid ?? '—'">
                  {{ settings.agent?.uuid ?? '—' }}
                </a-typography-text>
              </a-descriptions-item>
              <a-descriptions-item label="Name">{{ settings.agent?.name ?? '—' }}</a-descriptions-item>
              <a-descriptions-item label="Type">{{ settings.agent?.type ?? '—' }}</a-descriptions-item>
              <a-descriptions-item label="Version">
                <a-tag v-if="settings.agent?.version" color="blue">v{{ settings.agent.version }}</a-tag>
                <span v-else>—</span>
              </a-descriptions-item>
              <a-descriptions-item label="Status">
                <a-badge
                  :status="settings.agent?.provisioned ? 'success' : 'default'"
                  :text="settings.agent?.provisioned ? 'Provisioned' : 'Not provisioned'"
                />
              </a-descriptions-item>
              <a-descriptions-item label="Tenant ID">{{ settings.agent?.tenantId ?? '—' }}</a-descriptions-item>
              <a-descriptions-item label="Registered at">
                {{ settings.agent?.registeredAt ? new Date(settings.agent.registeredAt).toLocaleString() : '—' }}
              </a-descriptions-item>
              <template v-if="settings.agent?.macAddress">
                <a-descriptions-item label="MAC address">{{ settings.agent.macAddress }}</a-descriptions-item>
              </template>
              <template v-if="settings.agent?.osVersion">
                <a-descriptions-item label="OS version">{{ settings.agent.osVersion }}</a-descriptions-item>
              </template>
              <template v-if="settings.agent?.provisioned">
                <a-descriptions-item label="API endpoint" :span="2">
                  <a-typography-text copyable :content="settings.agent.apiEndpoint ?? '—'">
                    {{ settings.agent.apiEndpoint ?? '—' }}
                  </a-typography-text>
                </a-descriptions-item>
                <a-descriptions-item label="MQTT broker" :span="2">
                  <a-typography-text copyable :content="settings.agent.mqttBrokerUrl ?? '—'">
                    {{ settings.agent.mqttBrokerUrl ?? '—' }}
                  </a-typography-text>
                </a-descriptions-item>
                <a-descriptions-item label="MQTT username">
                  <a-typography-text copyable :content="settings.agent.mqttUsername ?? '—'">
                    {{ settings.agent.mqttUsername ?? '—' }}
                  </a-typography-text>
                </a-descriptions-item>
                <a-descriptions-item label="MQTT TLS">
                  <a-badge
                    :status="settings.agent.mqttUseTls ? 'success' : 'default'"
                    :text="settings.agent.mqttUseTls === null ? '—' : settings.agent.mqttUseTls ? 'Enabled' : 'Disabled'"
                  />
                </a-descriptions-item>
                <a-descriptions-item label="MQTT client ID prefix" :span="2">
                  <a-typography-text copyable :content="settings.agent.mqttClientIdPrefix ?? '—'">
                    {{ settings.agent.mqttClientIdPrefix ?? '—' }}
                  </a-typography-text>
                </a-descriptions-item>
                <a-descriptions-item label="Cloud target sync" :span="2">
                  <div style="display: flex; align-items: center; gap: 12px">
                    <a-switch
                      :checked="settings.agent.targetSyncEnabled !== false"
                      :loading="targetSyncSaving"
                      @change="(v: boolean) => setTargetSync(v)"
                    />
                    <span style="font-size: 12px; color: var(--text-tertiary)">
                      {{ settings.agent.targetSyncEnabled !== false
                        ? 'Pulling target state from cloud'
                        : 'Report-only — cloud cannot push config changes' }}
                    </span>
                  </div>
                </a-descriptions-item>
              </template>
            </a-descriptions>

            <template v-if="!settings.agent?.provisioned">
              <a-divider style="margin: 16px 0 12px" />
              <p style="margin: 0 0 12px; font-size: 13px; font-weight: 600; color: var(--text-secondary)">
                Connect to Iotistica
              </p>
              <a-form layout="vertical" class="provision-form">
              <a-row :gutter="[16, 18]">
                <a-col :span="24">
                  <a-form-item label="Provisioning key" style="margin-bottom: 0" required>
                    <a-input-password
                      v-model:value="provisionForm.key"
                      placeholder="Paste your provisioning key"
                      :disabled="provisioning"
                    />
                  </a-form-item>
                </a-col>
                <a-col :xs="24" :sm="12">
                  <a-form-item label="API endpoint" style="margin-bottom: 0">
                    <a-input
                      v-model:value="provisionForm.apiEndpoint"
                      placeholder="https://api.iotistica.com (optional)"
                      :disabled="provisioning"
                    />
                  </a-form-item>
                </a-col>
                <a-col :xs="24" :sm="12">
                  <a-form-item label="Device name" style="margin-bottom: 0">
                    <a-input
                      v-model:value="provisionForm.deviceName"
                      placeholder="Optional override"
                      :disabled="provisioning"
                    />
                  </a-form-item>
                </a-col>
                <a-col :span="24" style="display: flex; justify-content: flex-end">
                  <a-button
                    type="primary"
                    :loading="provisioning"
                    :disabled="!provisionForm.key.trim()"
                    @click="provision"
                  >
                    <template #icon><LinkOutlined /></template>
                    {{ provisioning ? 'Connecting…' : 'Connect to Iotistica' }}
                  </a-button>
                </a-col>
              </a-row>
              </a-form>
            </template>
          </a-card>

          <a-card v-if="hasRole('admin')" size="small" class="settings-card" style="margin-top: 16px">
            <template #title>Agent Update</template>
            <template #extra>
              <a-button size="small" :loading="updateChecking" @click="checkForUpdate(true)">
                <template #icon><ReloadOutlined /></template>
                Check for Updates
              </a-button>
            </template>

            <a-descriptions v-if="updateInfo" :column="1" size="small" bordered>
              <a-descriptions-item label="Current version">
                <a-tag color="blue">v{{ updateInfo.currentVersion }}</a-tag>
              </a-descriptions-item>
              <a-descriptions-item label="Latest version">
                <template v-if="updateInfo.latestVersion">
                  <a-tag :color="updateInfo.updateAvailable ? 'orange' : 'green'">v{{ updateInfo.latestVersion }}</a-tag>
                </template>
                <span v-else style="color: var(--text-tertiary)">Unknown</span>
              </a-descriptions-item>
              <a-descriptions-item label="Status">
                <a-badge v-if="updateInfo.updateAvailable" status="warning" text="Update available" />
                <a-badge v-else-if="updateInfo.error" status="error" :text="updateInfo.error" />
                <a-badge v-else status="success" text="Up to date" />
              </a-descriptions-item>
              <a-descriptions-item v-if="updateInfo.releaseDate" label="Release date">
                {{ updateInfo.releaseDate }}
              </a-descriptions-item>
              <a-descriptions-item v-if="updateInfo.notes" label="Release notes">
                {{ updateInfo.notes }}
              </a-descriptions-item>
            </a-descriptions>

            <div v-if="updateInfo?.updateAvailable" style="margin-top: 16px">
              <a-button type="primary" :loading="updateTriggering" @click="confirmUpdate">
                <template #icon><CloudDownloadOutlined /></template>
                Update to v{{ updateInfo.latestVersion }}
              </a-button>
            </div>

            <div v-if="!updateInfo && !updateChecking" style="color: var(--text-tertiary); text-align: center; padding: 24px">
              Click "Check for Updates" to see if a newer version is available.
            </div>
          </a-card>
        </a-tab-pane>

        <!-- ══ FEATURES ═══════════════════════════════════════════════════════ -->
        <a-tab-pane key="features" tab="Features">
          <a-card size="small" class="settings-card">
            <a-space direction="vertical" style="width: 100%">
              <div class="toggle-row">
                <div>
                  <div class="toggle-label">Data Publishing</div>
                  <div class="toggle-desc">Automatically publish device data to MQTT broker</div>
                </div>
                <a-switch
                  :checked="settings.features?.enableDevicePublish ?? true"
                  @change="(v: boolean) => setFeature('enableDevicePublish', v)"
                />
              </div>
              <a-divider style="margin: 8px 0" />
              <div class="toggle-row">
                <div>
                  <div class="toggle-label">Anomaly Detection</div>
                  <div class="toggle-desc">Enable AI-powered anomaly detection for metrics</div>
                </div>
                <a-switch
                  :checked="settings.features?.enableAnomalyDetection ?? false"
                  @change="(v: boolean) => setFeature('enableAnomalyDetection', v)"
                />
              </div>
              <a-divider style="margin: 8px 0" />
              <div class="toggle-row">
                <div>
                  <div class="toggle-label">Remote Access</div>
                  <div class="toggle-desc">Allow remote terminal access to the agent</div>
                </div>
                <a-switch
                  :checked="settings.features?.enableDeviceRemoteAccess ?? true"
                  @change="(v: boolean) => setFeature('enableDeviceRemoteAccess', v)"
                />
              </div>
              <a-divider style="margin: 8px 0" />
              <div class="toggle-row">
                <div>
                  <div class="toggle-label">Device Jobs</div>
                  <div class="toggle-desc">Enable the job execution engine on the agent</div>
                </div>
                <a-switch
                  :checked="settings.features?.enableDeviceJobs ?? true"
                  @change="(v: boolean) => setFeature('enableDeviceJobs', v)"
                />
              </div>
              <a-divider style="margin: 8px 0" />
              <div class="toggle-row">
                <div>
                  <div class="toggle-label">Unit Normalization</div>
                  <div class="toggle-desc">Resolve raw unit strings to canonical units and track unknown units</div>
                </div>
                <a-switch
                  :checked="settings.features?.enableUnitNormalization ?? true"
                  @change="(v: boolean) => setFeature('enableUnitNormalization', v)"
                />
              </div>
              <a-divider style="margin: 8px 0" />
              <div class="toggle-row">
                <div>
                  <div class="toggle-label">Point-Name Normalization</div>
                  <div class="toggle-desc">Resolve raw point/tag names to canonical, deduplicated identities</div>
                </div>
                <a-switch
                  :checked="settings.features?.enablePointNameNormalization ?? true"
                  @change="(v: boolean) => setFeature('enablePointNameNormalization', v)"
                />
              </div>
            </a-space>
          </a-card>
          <div v-if="hasRole('operator')" class="save-bar">
            <a-button :disabled="saving" @click="discard">Discard</a-button>
            <a-button type="primary" :loading="saving" @click="save">
              <template #icon><SaveOutlined /></template>
              Save
            </a-button>
          </div>
        </a-tab-pane>

        <!-- ══ LOGGING ════════════════════════════════════════════════════════ -->
        <a-tab-pane key="logging" tab="Logging">
          <a-card size="small" class="settings-card">
            <a-row :gutter="[16, 16]">
              <a-col :xs="24" :sm="12" :lg="6">
                <a-form-item label="Log level" style="margin-bottom: 0">
                  <a-select
                    :value="settings.logging?.level ?? 'info'"
                    style="width: 100%"
                    @change="(v: string) => setLogging('level', v as any)"
                  >
                    <a-select-option value="debug">Debug</a-select-option>
                    <a-select-option value="info">Info</a-select-option>
                    <a-select-option value="warn">Warning</a-select-option>
                    <a-select-option value="error">Error</a-select-option>
                  </a-select>
                </a-form-item>
              </a-col>
              <a-col :xs="24" :sm="12" :lg="6">
                <a-form-item label="Max entries" style="margin-bottom: 0">
                  <a-input-number
                    :value="settings.logging?.maxLogs ?? 10000"
                    :min="100"
                    :max="100000"
                    style="width: 100%"
                    @change="(v: number) => setLogging('maxLogs', v)"
                  />
                </a-form-item>
              </a-col>
              <a-col :xs="24" :sm="12" :lg="6">
                <a-form-item style="margin-bottom: 0">
                  <template #label>
                    Max age (ms)
                    <a-typography-text type="secondary" style="font-size: 12px; margin-left: 6px">
                      {{ msToHuman(settings.logging?.logMaxAge) }}
                    </a-typography-text>
                  </template>
                  <a-input-number
                    :value="settings.logging?.logMaxAge ?? 86400000"
                    :min="60000"
                    style="width: 100%"
                    @change="(v: number) => setLogging('logMaxAge', v)"
                  />
                </a-form-item>
              </a-col>
              <a-col :xs="24" :sm="12" :lg="6">
                <a-form-item label="Max file (bytes)" style="margin-bottom: 0">
                  <a-input-number
                    :value="settings.logging?.maxLogFileSize ?? 52428800"
                    :min="1048576"
                    style="width: 100%"
                    @change="(v: number) => setLogging('maxLogFileSize', v)"
                  />
                </a-form-item>
              </a-col>
            </a-row>
            <a-divider style="margin: 16px 0 12px" />
            <a-space direction="vertical" style="width: 100%">
              <div class="toggle-row">
                <div>
                  <div class="toggle-label">Compression</div>
                  <div class="toggle-desc">Compress log files to save disk space</div>
                </div>
                <a-switch
                  :checked="settings.logging?.enableCompression ?? false"
                  @change="(v: boolean) => setLogging('enableCompression', v)"
                />
              </div>
              <a-divider style="margin: 8px 0" />
              <div class="toggle-row">
                <div>
                  <div class="toggle-label">Remote logging</div>
                  <div class="toggle-desc">Send logs to the cloud API for centralised monitoring</div>
                </div>
                <a-switch
                  :checked="settings.logging?.enableRemoteLogging ?? false"
                  @change="(v: boolean) => setLogging('enableRemoteLogging', v)"
                />
              </div>
              <a-divider style="margin: 8px 0" />
              <div class="toggle-row">
                <div>
                  <div class="toggle-label">File persistence</div>
                  <div class="toggle-desc">Persist logs to disk for local debugging</div>
                </div>
                <a-switch
                  :checked="settings.logging?.enableFilePersistence ?? false"
                  @change="(v: boolean) => setLogging('enableFilePersistence', v)"
                />
              </div>
            </a-space>
          </a-card>
          <div v-if="hasRole('operator')" class="save-bar">
            <a-button :disabled="saving" @click="discard">Discard</a-button>
            <a-button type="primary" :loading="saving" @click="save">
              <template #icon><SaveOutlined /></template>
              Save
            </a-button>
          </div>
        </a-tab-pane>

        <!-- ══ INTERVALS ══════════════════════════════════════════════════════ -->
        <a-tab-pane key="intervals" tab="Intervals">
          <a-card size="small" class="settings-card settings-card--spaced">
            <template #title>Agent communication</template>
            <a-row :gutter="[16, 16]">
              <a-col :xs="24" :sm="12" :lg="6">
                <a-form-item style="margin-bottom: 0">
                  <template #label>
                    Report (ms)
                    <a-typography-text type="secondary" style="font-size: 12px; margin-left: 4px">
                      {{ msToHuman(settings.intervals?.agent?.reportIntervalMs) }}
                    </a-typography-text>
                  </template>
                  <a-input-number
                    :value="settings.intervals?.agent?.reportIntervalMs ?? 60000"
                    :min="5000"
                    style="width: 100%"
                    @change="(v: number) => setAgentInterval('reportIntervalMs', v)"
                  />
                </a-form-item>
              </a-col>
              <a-col :xs="24" :sm="12" :lg="6">
                <a-form-item style="margin-bottom: 0">
                  <template #label>
                    Metrics (ms)
                    <a-typography-text type="secondary" style="font-size: 12px; margin-left: 4px">
                      {{ msToHuman(settings.intervals?.agent?.metricsIntervalMs) }}
                    </a-typography-text>
                  </template>
                  <a-input-number
                    :value="settings.intervals?.agent?.metricsIntervalMs ?? 60000"
                    :min="5000"
                    style="width: 100%"
                    @change="(v: number) => setAgentInterval('metricsIntervalMs', v)"
                  />
                </a-form-item>
              </a-col>
              <a-col :xs="24" :sm="12" :lg="6">
                <a-form-item style="margin-bottom: 0">
                  <template #label>
                    Reconciliation (ms)
                    <a-typography-text type="secondary" style="font-size: 12px; margin-left: 4px">
                      {{ msToHuman(settings.intervals?.agent?.reconciliationIntervalMs) }}
                    </a-typography-text>
                  </template>
                  <a-input-number
                    :value="settings.intervals?.agent?.reconciliationIntervalMs ?? 30000"
                    :min="5000"
                    style="width: 100%"
                    @change="(v: number) => setAgentInterval('reconciliationIntervalMs', v)"
                  />
                </a-form-item>
              </a-col>
              <a-col :xs="24" :sm="12" :lg="6">
                <a-form-item style="margin-bottom: 0">
                  <template #label>
                    Target state poll (ms)
                    <a-typography-text type="secondary" style="font-size: 12px; margin-left: 4px">
                      {{ msToHuman(settings.intervals?.agent?.targetStatePollIntervalMs) }}
                    </a-typography-text>
                  </template>
                  <a-input-number
                    :value="settings.intervals?.agent?.targetStatePollIntervalMs ?? 60000"
                    :min="5000"
                    style="width: 100%"
                    @change="(v: number) => setAgentInterval('targetStatePollIntervalMs', v)"
                  />
                </a-form-item>
              </a-col>
            </a-row>
          </a-card>

          <a-card size="small" class="settings-card">
            <template #title>Runtime &amp; Memory</template>
            <a-row :gutter="[16, 16]">
              <a-col :xs="24" :sm="12" :lg="6">
                <a-form-item label="Memory threshold (MB)" style="margin-bottom: 0">
                  <a-input-number
                    :value="settings.runtime?.memory?.thresholdMb ?? 30"
                    :min="10"
                    style="width: 100%"
                    @change="(v: number) => setMemory('thresholdMb', v)"
                  />
                </a-form-item>
              </a-col>
              <a-col :xs="24" :sm="12" :lg="6">
                <a-form-item style="margin-bottom: 0">
                  <template #label>
                    Check interval (ms)
                    <a-typography-text type="secondary" style="font-size: 12px; margin-left: 4px">
                      {{ msToHuman(settings.runtime?.memory?.checkIntervalMs) }}
                    </a-typography-text>
                  </template>
                  <a-input-number
                    :value="settings.runtime?.memory?.checkIntervalMs ?? 30000"
                    :min="5000"
                    style="width: 100%"
                    @change="(v: number) => setMemory('checkIntervalMs', v)"
                  />
                </a-form-item>
              </a-col>
            </a-row>
          </a-card>

          <div v-if="hasRole('operator')" class="save-bar">
            <a-button :disabled="saving" @click="discard">Discard</a-button>
            <a-button type="primary" :loading="saving" @click="save">
              <template #icon><SaveOutlined /></template>
              Save
            </a-button>
          </div>
        </a-tab-pane>

        <!-- ══ DOCKER ══════════════════════════════════════════════════════════ -->
        <a-tab-pane key="docker" tab="Applications">
          <a-spin :spinning="dockerLoading">
            <a-card size="small" class="settings-card" title="Daemon Connection">
              <a-form layout="vertical">

                <a-form-item label="Connection type">
                  <a-radio-group
                    v-model:value="dockerConfig.type"
                    button-style="solid"
                    @change="onDockerTypeChange"
                  >
                    <a-radio-button value="socket">Local socket</a-radio-button>
                    <a-radio-button value="tcp">Remote TCP</a-radio-button>
                    <a-radio-button value="tcp+tls">Remote TCP + TLS</a-radio-button>
                  </a-radio-group>
                  <div style="font-size: 12px; color: var(--text-tertiary); margin-top: 6px">
                    <template v-if="dockerConfig.type === 'socket'">
                      Connects to the Docker daemon on this device via a Unix socket or Windows named pipe.
                    </template>
                    <template v-else-if="dockerConfig.type === 'tcp'">
                      Connects to a remote Docker daemon over an unencrypted TCP connection. Only use on trusted networks.
                    </template>
                    <template v-else>
                      Connects to a remote Docker daemon over TLS. Requires CA certificate and client credentials.
                    </template>
                  </div>
                </a-form-item>

                <!-- Socket path -->
                <a-form-item v-if="dockerConfig.type === 'socket'" label="Socket path">
                  <a-input
                    v-model:value="dockerConfig.socketPath"
                    placeholder="/var/run/docker.sock  (Linux/Mac)   or   //./pipe/docker_engine  (Windows)"
                    style="font-family: monospace; font-size: 12px"
                  />
                  <div style="font-size: 12px; color: var(--text-tertiary); margin-top: 4px">
                    Leave blank to use the platform default.
                  </div>
                </a-form-item>

                <!-- TCP host + port -->
                <template v-if="dockerConfig.type === 'tcp' || dockerConfig.type === 'tcp+tls'">
                  <div style="display: grid; grid-template-columns: 1fr 140px; gap: 12px">
                    <a-form-item label="Host">
                      <a-input v-model:value="dockerConfig.host" placeholder="192.168.1.100" />
                    </a-form-item>
                    <a-form-item label="Port">
                      <a-input-number
                        v-model:value="dockerConfig.port"
                        :placeholder="dockerConfig.type === 'tcp+tls' ? '2376' : '2375'"
                        style="width: 100%"
                        :min="1"
                        :max="65535"
                      />
                    </a-form-item>
                  </div>
                </template>

                <!-- TLS certificates -->
                <template v-if="dockerConfig.type === 'tcp+tls'">
                  <a-form-item label="CA certificate (PEM)">
                    <a-textarea
                      v-model:value="dockerConfig.ca"
                      placeholder="-----BEGIN CERTIFICATE-----&#10;...&#10;-----END CERTIFICATE-----"
                      :rows="4"
                      style="font-family: monospace; font-size: 12px"
                    />
                  </a-form-item>
                  <a-form-item label="Client certificate (PEM)">
                    <a-textarea
                      v-model:value="dockerConfig.cert"
                      placeholder="-----BEGIN CERTIFICATE-----&#10;...&#10;-----END CERTIFICATE-----"
                      :rows="4"
                      style="font-family: monospace; font-size: 12px"
                    />
                  </a-form-item>
                  <a-form-item label="Client key (PEM)">
                    <a-textarea
                      v-model:value="dockerConfig.key"
                      placeholder="-----BEGIN PRIVATE KEY-----&#10;...&#10;-----END PRIVATE KEY-----"
                      :rows="4"
                      style="font-family: monospace; font-size: 12px"
                    />
                  </a-form-item>
                </template>

                <!-- Test result -->
                <a-alert
                  v-if="dockerTestResult"
                  type="success"
                  show-icon
                  style="margin-bottom: 12px"
                >
                  <template #icon><CheckCircleOutlined /></template>
                  <template #message>
                    Connected — Docker {{ dockerTestResult.version }},
                    {{ dockerTestResult.containers }} container{{ dockerTestResult.containers !== 1 ? 's' : '' }}
                  </template>
                </a-alert>
                <a-alert
                  v-if="dockerTestError"
                  type="error"
                  :message="dockerTestError"
                  show-icon
                  style="margin-bottom: 12px"
                />

              </a-form>
            </a-card>

            <div class="save-bar">
              <a-button :loading="dockerTesting" @click="testDockerConnection">
                <template #icon><LinkOutlined /></template>
                Test Connection
              </a-button>
              <a-button v-if="hasRole('admin')" type="primary" :loading="dockerSaving" @click="saveDockerConfig">
                <template #icon><SaveOutlined /></template>
                Save
              </a-button>
            </div>
          </a-spin>
        </a-tab-pane>

        <a-tab-pane key="units" tab="Units">
          <p class="settings-intro">
            Admin-created unit mappings — created via the "Resolve" action on the
            Dashboard's Normalization Health section when an incoming reading uses
            a unit the built-in catalog doesn't recognize. You can re-map an
            existing mapping to a different canonical unit here; to add a new one,
            resolve it from the Dashboard.
          </p>

          <a-card class="settings-card" size="small" title="Custom unit mappings">
          <a-table
            :columns="customAliasColumns"
            :data-source="customAliases"
            :loading="customAliasesLoading"
            :pagination="{ pageSize: 20, size: 'small' }"
            row-key="id"
            size="small"
          >
            <template #bodyCell="{ column, record }">
              <template v-if="column.key === 'source_system'">
                <span style="font-size: 13px; color: var(--text-secondary)">{{ record.source_system ?? '— (global)' }}</span>
              </template>
              <template v-else-if="column.key === 'actions'">
                <a-button size="small" @click="openEditAlias(record)">
                  <template #icon><EditOutlined /></template>
                </a-button>
              </template>
            </template>
            <template #emptyText>
              <div style="padding: 32px 0; text-align: center; color: var(--text-tertiary)">
                No custom unit mappings yet. Resolve an unknown unit from the Dashboard's
                Normalization Health section to create one.
              </div>
            </template>
          </a-table>
          </a-card>
        </a-tab-pane>

        <!-- ══ ALERTS ════════════════════════════════════════════════════════ -->
        <a-tab-pane key="alerts" tab="Analytics &amp; Alerts">
          <a-spin :spinning="alertConfigLoading">
            <template v-if="alertConfig">

              <!-- Anomaly Detection -->
              <a-card size="small" class="settings-card">
                <template #title>Anomaly Detection</template>
                <a-row :gutter="[16, 16]">
                  <a-col :xs="24" :sm="12" :lg="6">
                    <a-form-item label="Sensitivity" style="margin-bottom: 0">
                      <div style="display: flex; align-items: center; gap: 12px; max-width: 240px">
                        <a-slider v-model:value="alertConfig.sensitivity" :min="1" :max="10" style="flex: 1" />
                        <a-input-number v-model:value="alertConfig.sensitivity" :min="1" :max="10" style="width: 56px" size="small" />
                      </div>
                      <div style="display: flex; justify-content: space-between; font-size: 11px; color: var(--text-muted); max-width: 240px">
                        <span>Low</span><span>High</span>
                      </div>
                    </a-form-item>
                  </a-col>
                  <a-col :xs="24" :sm="12" :lg="6">
                    <a-form-item style="margin-bottom: 0">
                      <template #label>
                        Learning period
                        <a-typography-text type="secondary" style="font-size: 12px; margin-left: 4px">
                          {{ msToHuman(alertConfig.warmupPeriodMs) }}
                        </a-typography-text>
                      </template>
                      <a-input-number v-model:value="alertConfig.warmupPeriodMs" :min="0" :step="60000" placeholder="900000" style="width: 100%" :addon-after="'ms'" />
                    </a-form-item>
                  </a-col>
                  <a-col :xs="24" :sm="12" :lg="6">
                    <a-form-item style="margin-bottom: 0">
                      <template #label>
                        Cooldown
                        <a-typography-text type="secondary" style="font-size: 12px; margin-left: 4px">
                          {{ msToHuman(alertConfig.alerts.cooldownMs) }}
                        </a-typography-text>
                      </template>
                      <a-input-number v-model:value="alertConfig.alerts.cooldownMs" :min="0" :step="60000" style="width: 100%" :addon-after="'ms'" />
                    </a-form-item>
                  </a-col>
                  <a-col :xs="24" :sm="12" :lg="6">
                    <a-form-item label="Min confidence" style="margin-bottom: 0">
                      <a-input-number v-model:value="alertConfig.alerts.minConfidence" :min="0" :max="1" :step="0.05" style="width: 100%" />
                    </a-form-item>
                  </a-col>
                </a-row>
              </a-card>

              <!-- Schema Drift Detection -->
              <a-card size="small" class="settings-card">
                <template #title>
                  <div style="display: flex; align-items: center; justify-content: space-between; width: 100%">
                    Schema Drift
                    <div class="drift-enabled-toggle">
                      <span class="drift-enabled-toggle__label">Enabled</span>
                      <a-switch
                        :checked="globalDrift.enabled !== false"
                        size="small"
                        @change="(v: boolean) => setDrift('enabled', v)"
                      />
                    </div>
                  </div>
                </template>
                <a-spin :spinning="driftLoading">
                  <a-row :gutter="[16, 16]">
                    <a-col :xs="24" :sm="12" :lg="8">
                      <a-form-item label="Sensitivity" style="margin-bottom: 0">
                        <a-radio-group
                          button-style="solid"
                          :value="selectedSensitivity === 'custom' ? undefined : selectedSensitivity"
                          @change="(e: any) => setSensitivityPreset(e.target.value)"
                        >
                          <a-radio-button value="low">Low</a-radio-button>
                          <a-radio-button value="standard">Standard</a-radio-button>
                          <a-radio-button value="high">High</a-radio-button>
                        </a-radio-group>
                        <div v-if="selectedSensitivity === 'custom'" class="drift-sensitivity-custom">
                          Custom — settings differ from a preset
                        </div>
                      </a-form-item>
                    </a-col>
                    <a-col :xs="24" :sm="12" :lg="8">
                      <a-form-item label="Repeat alert interval" style="margin-bottom: 0">
                        <a-select
                          :value="globalDrift.alertCooldownMs ?? 1800000"
                          style="width: 100%"
                          @change="(v: number) => setDrift('alertCooldownMs', v)"
                        >
                          <a-select-option v-for="opt in alertFrequencyOptions" :key="opt.value" :value="opt.value">
                            {{ opt.label }}
                          </a-select-option>
                        </a-select>
                      </a-form-item>
                    </a-col>
                  </a-row>

                  <div class="drift-alert-on">
                    <div class="drift-alert-on__label">
                      Alert on
                      <a-tooltip title="Controls which drift types raise an alert — all types are always logged regardless.">
                        <QuestionCircleOutlined class="drift-alert-on__info" />
                      </a-tooltip>
                    </div>
                    <a-checkbox-group
                      :value="globalDrift.alertOnDriftTypes ?? DEFAULT_ALERT_DRIFT_TYPES"
                      class="drift-alert-on__group"
                      @change="(v: DriftAlertType[]) => setDrift('alertOnDriftTypes', v)"
                    >
                      <a-checkbox v-for="opt in DRIFT_ALERT_TYPE_OPTIONS" :key="opt.value" :value="opt.value">
                        {{ opt.label }}
                        <a-tooltip :title="opt.hint">
                          <QuestionCircleOutlined class="drift-alert-on__info drift-alert-on__info--sm" />
                        </a-tooltip>
                      </a-checkbox>
                    </a-checkbox-group>
                  </div>
                </a-spin>
              </a-card>

              <!-- Alert Delivery -->
              <a-card size="small" class="settings-card">
                <template #title>Alert Delivery</template>
                <a-row :gutter="[16, 16]">
                  <a-col :xs="24" :sm="8" :lg="6">
                    <a-form-item label="Publish to MQTT" style="margin-bottom: 0">
                      <a-switch v-model:checked="alertConfig.alerts.mqtt" />
                    </a-form-item>
                  </a-col>
                  <a-col :xs="24" :sm="8" :lg="6">
                    <a-form-item label="Destination" style="margin-bottom: 0">
                      <a-select
                        :value="alertConfig.alerts.alertDestinationId"
                        allow-clear
                        :disabled="!alertConfig.alerts.mqtt"
                        placeholder="Default (cloud)"
                        style="width: 100%"
                        @change="(v: number | null) => { alertConfig!.alerts.alertDestinationId = v ?? undefined }"
                      >
                        <a-select-option v-for="d in alertMqttDestinations" :key="d.id" :value="d.id">
                          {{ d.name }}
                        </a-select-option>
                      </a-select>
                    </a-form-item>
                  </a-col>
                  <a-col :xs="24" :sm="8" :lg="6">
                    <a-form-item label="Topic" style="margin-bottom: 0">
                      <a-input
                        :value="alertConfig.alerts.alertTopic ?? ''"
                        :disabled="!alertConfig.alerts.mqtt"
                        placeholder="iotistica/alerts/anomaly"
                        style="width: 100%"
                        @change="(e: Event) => { alertConfig!.alerts.alertTopic = (e.target as HTMLInputElement).value || undefined }"
                      />
                    </a-form-item>
                  </a-col>
                </a-row>
              </a-card>

              <!-- Data Retention -->
              <a-card size="small" class="settings-card">
                <template #title>Data Retention</template>
                <a-row :gutter="[16, 16]">
                  <a-col :xs="24" :sm="12" :lg="6">
                    <a-form-item label="Baseline retention (days)" style="margin-bottom: 0">
                      <a-input-number
                        :value="alertConfig.storage?.retention"
                        :min="1"
                        placeholder="30"
                        style="width: 100%"
                        @change="(v: number) => { if (!alertConfig!.storage) alertConfig!.storage = { retention: v }; else alertConfig!.storage.retention = v }"
                      />
                    </a-form-item>
                  </a-col>
                  <a-col :xs="24" :sm="12" :lg="6">
                    <a-form-item label="Event retention (days)" style="margin-bottom: 0">
                      <a-input-number
                        :value="alertConfig.storage?.eventRetentionDays"
                        :min="1"
                        :placeholder="String(alertConfig.storage?.retention ?? 30)"
                        style="width: 100%"
                        @change="(v: number) => { if (!alertConfig!.storage) alertConfig!.storage = { retention: 30, eventRetentionDays: v }; else alertConfig!.storage.eventRetentionDays = v }"
                      />
                    </a-form-item>
                  </a-col>
                  <a-col :xs="24" :sm="12" :lg="6">
                    <a-form-item label="Incident retention (days)" style="margin-bottom: 0">
                      <a-input-number
                        :value="alertConfig.storage?.incidentRetentionDays"
                        :min="1"
                        :placeholder="String(alertConfig.storage?.retention ?? 30)"
                        style="width: 100%"
                        @change="(v: number) => { if (!alertConfig!.storage) alertConfig!.storage = { retention: 30, incidentRetentionDays: v }; else alertConfig!.storage.incidentRetentionDays = v }"
                      />
                    </a-form-item>
                  </a-col>
                  <a-col :xs="24" :sm="12" :lg="6">
                    <a-form-item label="Alert retention (days)" style="margin-bottom: 0">
                      <a-input-number
                        :value="alertConfig.storage?.alertRetentionDays"
                        :min="1"
                        :placeholder="String(alertConfig.storage?.retention ?? 30)"
                        style="width: 100%"
                        @change="(v: number) => { if (!alertConfig!.storage) alertConfig!.storage = { retention: 30, alertRetentionDays: v }; else alertConfig!.storage.alertRetentionDays = v }"
                      />
                    </a-form-item>
                  </a-col>
                </a-row>
              </a-card>

              <div v-if="hasRole('operator')" class="save-bar">
                <a-button @click="resetAlertDetectionDefaults">Reset to default</a-button>
                <a-button type="primary" :loading="alertConfigSaving" @click="saveAllAlertConfig">
                  <template #icon><SaveOutlined /></template>
                  Save
                </a-button>
              </div>
            </template>

            <div v-else-if="!alertConfigLoading" style="color: var(--text-tertiary); padding: 48px 0; text-align: center">
              Configuration not available.
            </div>
          </a-spin>
        </a-tab-pane>

        <!-- ══ LICENSE ═══════════════════════════════════════════════════════ -->
        <a-tab-pane key="license" tab="License">
          <a-spin :spinning="licenseLoading">
            <a-card size="small" class="settings-card">
              <template #title>License Status</template>
              <template #extra>
                <a-button size="small" @click="loadLicense">
                  <template #icon><ReloadOutlined /></template>
                  Refresh
                </a-button>
              </template>

              <a-descriptions v-if="licenseStatus" :column="1" size="small" bordered>
                <a-descriptions-item label="Status">
                  <a-badge :status="licenseStateBadge as any" />
                  {{ licenseStateLabel }}
                </a-descriptions-item>
                <a-descriptions-item v-if="licenseStatus.licenseId" label="License ID">
                  <code>{{ licenseStatus.licenseId }}</code>
                </a-descriptions-item>
                <a-descriptions-item v-if="licenseStatus.tier" label="Tier">
                  {{ licenseStatus.tier === 'paid' ? 'Paid' : 'Trial' }}
                </a-descriptions-item>
                <a-descriptions-item v-if="licenseStatus.tier" label="Expires">
                  {{ formatExpiryDate(licenseStatus.expiresAt) }}
                </a-descriptions-item>
                <a-descriptions-item v-if="licenseStatus.daysRemaining !== undefined" label="Days remaining">
                  <span :style="{ color: (licenseStatus.daysRemaining ?? 0) <= 7 ? '#ff4d4f' : undefined, fontWeight: (licenseStatus.daysRemaining ?? 0) <= 7 ? 600 : undefined }">
                    {{ licenseStatus.daysRemaining }}
                  </span>
                </a-descriptions-item>
                <a-descriptions-item v-if="licenseStatus.invalidReason" label="Issue">
                  <span style="color: #ff4d4f">{{ licenseStatus.invalidReason }}</span>
                </a-descriptions-item>
              </a-descriptions>

              <div v-if="!licenseStatus" style="color: var(--text-tertiary); text-align: center; padding: 24px">
                Unable to load license status.
              </div>
            </a-card>

            <a-card v-if="licenseStatus && hasRole('admin') && licenseStatus.state !== 'paid'" size="small" class="settings-card" style="margin-top: 16px">
              <template #title>Activation</template>

              <div class="license-action">
                <p style="color: var(--text-secondary); margin-bottom: 12px">
                  Enter a license key to {{ licenseStatus.tier === 'trial' ? 'upgrade from trial' : 'activate' }}.
                </p>
                <div style="display: flex; gap: 8px; max-width: 480px">
                  <a-input
                    v-model:value="licenseKey"
                    placeholder="Enter license key"
                    :disabled="licenseActivating"
                    @press-enter="activatePaid"
                  />
                  <a-button type="primary" :loading="licenseActivating" :disabled="!licenseKey.trim()" @click="activatePaid">
                    Activate
                  </a-button>
                </div>
              </div>
            </a-card>
          </a-spin>
        </a-tab-pane>

        <!-- ══ STATE ═════════════════════════════════════════════════════════ -->
        <a-tab-pane key="state" tab="State">
          <a-spin :spinning="stateLoading">
            <a-card size="small" class="settings-card">
              <template #title>Current State</template>
              <template #extra>
                <a-button size="small" @click="loadState">
                  <template #icon><ReloadOutlined /></template>
                  Refresh
                </a-button>
              </template>
              <pre v-if="stateData?.current" class="state-json">{{ JSON.stringify(stateData.current, null, 2) }}</pre>
              <div v-else style="color: var(--text-tertiary); text-align: center; padding: 24px">
                No current state available.
              </div>
            </a-card>

            <a-card size="small" class="settings-card" style="margin-top: 16px">
              <template #title>Target State</template>
              <pre v-if="stateData?.target" class="state-json">{{ JSON.stringify(stateData.target, null, 2) }}</pre>
              <div v-else style="color: var(--text-tertiary); text-align: center; padding: 24px">
                No target state available.
              </div>
            </a-card>
          </a-spin>
        </a-tab-pane>

      </a-tabs>
      </div>
    </a-spin>

    <a-modal
      :open="editAliasModalOpen"
      title="Edit unit mapping"
      :confirm-loading="editAliasSaving"
      ok-text="Save mapping"
      :ok-button-props="{ disabled: !editAliasCanonicalUnit }"
      @ok="submitEditAlias"
      @cancel="closeEditAlias"
    >
      <p style="margin-bottom: 16px; color: var(--text-tertiary)">
        Re-map this alias to a different canonical unit. Future readings using it
        will normalize to the new unit immediately.
      </p>
      <div style="margin-bottom: 12px">
        <div style="font-size: 12px; color: var(--text-tertiary)">Alias</div>
        <div><code>{{ editAliasTarget?.alias }}</code></div>
      </div>
      <div style="margin-bottom: 16px">
        <div style="font-size: 12px; color: var(--text-tertiary)">Protocol / Source System</div>
        <div>{{ editAliasTarget?.source_system ?? '— (global)' }}</div>
      </div>
      <div>
        <div style="font-size: 12px; color: var(--text-tertiary); margin-bottom: 4px">Canonical unit</div>
        <a-select
          v-model:value="editAliasCanonicalUnit"
          show-search
          placeholder="Select a canonical unit"
          style="width: 100%"
          :options="canonicalUnitOptions"
          :filter-option="(input: string, option: any) => option.label.toLowerCase().includes(input.toLowerCase())"
        />
      </div>
    </a-modal>
  </AppLayout>
</template>

<style scoped>
.heading { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 16px; }
.heading p { color: var(--text-tertiary); margin: 0; }

.toggle-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 4px 0;
}
.toggle-label {
  font-size: 14px;
  font-weight: 500;
  color: var(--text-heading);
}
.toggle-desc {
  font-size: 12px;
  color: var(--text-tertiary);
  margin-top: 2px;
}
.save-bar {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  padding-top: 16px;
}



.drift-enabled-toggle {
  display: flex;
  align-items: center;
  gap: 8px;
}

.drift-enabled-toggle__label {
  font-size: 12.5px;
  color: var(--text-tertiary);
}


.drift-alert-on {
  margin-top: 20px;
}

.drift-alert-on__label {
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 8px;
}

.drift-alert-on__info {
  color: var(--text-muted);
  font-size: 12px;
  margin-left: 4px;
  cursor: help;
}

.drift-alert-on__info--sm {
  font-size: 11px;
}

.drift-alert-on__group {
  display: flex;
  flex-wrap: wrap;
  gap: 8px 24px;
}

.drift-alert-on__group :deep(.ant-checkbox-wrapper) {
  margin-inline-start: 0;
}

.drift-sensitivity-custom {
  font-size: 12px;
  color: #d4880c;
  margin-top: 6px;
}


/* Agent provisioning: explicit vertical labels to avoid Ant Form horizontal defaults */
.provision-form { width: 100%; }
.provision-form :deep(.ant-form-item) { display: block; width: 100%; }
.provision-form :deep(.ant-form-item-row) { display: flex; flex-direction: column; align-items: stretch; }
.provision-form :deep(.ant-form-item-label) { flex: none; width: 100%; max-width: 100%; text-align: left; padding: 0 0 6px; }
.provision-form :deep(.ant-form-item-control) { flex: none; width: 100%; max-width: 100%; }
.provision-form :deep(.ant-input),
.provision-form :deep(.ant-input-affix-wrapper) { width: 100%; }
/* Unified settings layout — consistent with Sources / Data */
.settings-shell { width: 100%; max-width: none; margin: 0; padding: 0 0 28px; min-width: 0; }
.settings-tabs { width: 100%; min-width: 0; }
.settings-tabs :deep(.ant-tabs-nav) { margin: 0 0 18px; }
.settings-tabs :deep(.ant-tabs-nav-wrap) { min-width: 0; }
.settings-tabs :deep(.ant-tabs-tab) { padding: 11px 4px; font-size: 13px; }
.settings-tabs :deep(.ant-tabs-content-holder),
.settings-tabs :deep(.ant-tabs-tabpane) { min-width: 0; }
.settings-card { border: 1px solid var(--border-color-card); border-radius: 10px; overflow: hidden; margin-bottom: 14px; }
.settings-card--spaced { margin-bottom: 14px; }
.settings-card :deep(.ant-card-head) { min-height: 49px; border-bottom: 1px solid var(--border-color); padding: 0 22px; }
.settings-card :deep(.ant-card-head-title) { font-size: 14px; font-weight: 650; }
.settings-card :deep(.ant-card-body) { padding: 22px; }
.settings-intro { margin: 0 0 16px; color: var(--text-tertiary); font-size: 13px; line-height: 1.65; max-width: 850px; }
.settings-shell :deep(.ant-form-item) { margin-bottom: 0; min-width: 0; }
.settings-shell :deep(.ant-form-item-label) { padding-bottom: 6px; }
.settings-shell :deep(.ant-form-item-label > label) { font-size: 12px; font-weight: 600; color: var(--text-secondary); height: auto; min-height: 20px; }
.settings-shell :deep(.ant-input),
.settings-shell :deep(.ant-input-number),
.settings-shell :deep(.ant-select-selector),
.settings-shell :deep(.ant-input-affix-wrapper) { border-radius: 6px; }
.settings-shell :deep(.ant-input-number),
.settings-shell :deep(.ant-select),
.settings-shell :deep(.ant-input-affix-wrapper) { max-width: 100%; }
.settings-shell :deep(.ant-row) { row-gap: 18px; }
.settings-shell :deep(.ant-col) { min-width: 0; }
.toggle-row { min-height: 58px; padding: 10px 0; }
.toggle-row > div:first-child { flex: 1; min-width: 0; padding-right: 12px; }
.toggle-row :deep(.ant-switch) { flex-shrink: 0; }
.toggle-label { font-size: 13px; font-weight: 650; color: var(--text-primary); }
.toggle-desc { font-size: 12px; line-height: 1.55; color: var(--text-tertiary); max-width: 780px; margin-top: 3px; }
.save-bar { position: relative; display: flex; justify-content: flex-end; align-items: center; gap: 10px; flex-wrap: wrap; padding: 16px 0 4px; margin-top: 0; border-top: 0; }
.agent-descriptions :deep(.ant-descriptions-item-label) { width: 165px; min-width: 125px; background: var(--bg-table-header); font-weight: 600; font-size: 12px; }
.agent-descriptions :deep(.ant-descriptions-item-content) { overflow-wrap: anywhere; font-size: 12px; }
.settings-shell :deep(.ant-table-thead > tr > th) { background: var(--bg-table-header); font-weight: 650; font-size: 12px; }
.settings-shell :deep(.ant-table-tbody > tr:hover > td) { background: var(--bg-table-hover); }
.drift-alert-on__group { row-gap: 12px; }
.state-json {
  margin: 0;
  padding: 12px;
  background: var(--bg-table-header);
  border-radius: 6px;
  font-size: 12px;
  line-height: 1.55;
  overflow-x: auto;
  max-height: 600px;
  white-space: pre;
  tab-size: 2;
}
@media (max-width: 767px) {
  .settings-shell { padding-bottom: 18px; }
  .settings-card :deep(.ant-card-body) { padding: 16px; }
  .settings-card :deep(.ant-card-head) { padding: 0 16px; }
  .agent-descriptions :deep(.ant-descriptions-item-label) { min-width: 105px; width: 115px; }
  .save-bar { justify-content: flex-start; }
  .settings-tabs :deep(.ant-tabs-nav) { margin-bottom: 14px; }
}

</style>
