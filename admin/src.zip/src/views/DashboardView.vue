<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import type { TableColumnType } from 'ant-design-vue'
import AppLayout from '@/components/layout/AppLayout.vue'
import SparklineChart from '@/components/SparklineChart.vue'
import NormalizationHealthDrawer from '@/components/dashboard/NormalizationHealthDrawer.vue'
import { dashboardApi, type DashboardStats, type NetworkBandwidth, type NormalizationHealth } from '@/api/dashboard'
import { anomalyApi } from '@/api/anomaly'
import { pipelineApi, type PipelineOverview } from '@/api/pipeline'
import { protocolLabel } from '@/utils/protocol'
import type { EdgeAnomalyAlert } from '@/types'

const router = useRouter()

const netColumns: TableColumnType<NetworkBandwidth>[] = [
  { title: 'Interface', dataIndex: 'iface', key: 'iface', width: 120 },
  { title: 'In (current)', key: 'rx_sec', width: 130 },
  { title: 'Out (current)', key: 'tx_sec', width: 130 },
  { title: 'Total In', key: 'rx_bytes', width: 110 },
  { title: 'Total Out', key: 'tx_bytes', width: 110 },
]

const alertColumns: TableColumnType<EdgeAnomalyAlert>[] = [
  { title: 'Severity', key: 'severity', width: 90 },
  { title: 'Metric', key: 'metric', width: 180, ellipsis: true },
  { title: 'Device', key: 'device_name', width: 130, ellipsis: true },
  { title: 'Message', key: 'message', ellipsis: true },
  { title: 'Score', key: 'score', width: 60, align: 'right' },
  { title: 'Time', key: 'time', width: 90, align: 'right' },
]

const HISTORY = 60   // number of samples kept (~3 min at 3s interval)
const POLL_MS = 3000

const stats = ref<DashboardStats | null>(null)
const loading = ref(true)
const error = ref(false)

const incidentStats = ref<{ open: number; active: number; resolved: number; total: number } | null>(null)
const recentAlerts  = ref<EdgeAnomalyAlert[]>([])
const alertsTotal   = ref(0)

const normalizationHealth = ref<NormalizationHealth | null>(null)
const normalizationDrawerOpen = ref(false)
const normalizationUnitColumns: TableColumnType<{ label: string; protocol: string | null; count: number; lastSeen: string }>[] = [
  { title: 'Unit', dataIndex: 'label', key: 'label', ellipsis: true },
  { title: 'Protocol', key: 'protocol', width: 100 },
  { title: 'Count', dataIndex: 'count', key: 'count', width: 70, align: 'right' },
]

async function loadNormalizationHealth() {
  try {
    normalizationHealth.value = await dashboardApi.getNormalizationHealth()
  } catch { /* non-fatal */ }
}

const SEVERITY_TAG_COLOR: Record<string, string> = { critical: 'red', warning: 'orange', info: 'blue' }
const GUID_ANYWHERE = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}_/gi
function stripGuids(s: string): string { return s ? s.replace(GUID_ANYWHERE, '') : s }

const UUID_RE = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}_/gi

function deviceLabel(record: EdgeAnomalyAlert): string {
  // Extract metric name from message (may still have UUID prefix), then strip it
  const msgMatch = record.message?.match(/Anomaly in "([^"]+)"/)
  const rawName = msgMatch ? msgMatch[1] : null
  const metricName = rawName ? rawName.replace(UUID_RE, '') : null

  if (metricName) {
    if (metricName.startsWith('system_')) return 'System'
    const parts = metricName.split('_')
    if (parts.length > 2) {
      const label = parts.slice(0, parts.length - 2).map(p => p.charAt(0).toUpperCase() + p.slice(1)).join(' ')
      if (label) return label
    }
  }
  const dn = record.device_name
  if (!dn || dn === 'unknown') return '—'
  if (dn === 'system' || dn === 'Agent System') return 'System'
  if (dn.startsWith('agent-') || /^[0-9a-f]{8}-/i.test(dn)) return '—'
  return dn
}

function alertRowProps(_record: EdgeAnomalyAlert) {
  return { onClick: () => router.push('/anomaly') }
}

function fmtRelTime(ms: number): string {
  const diff = Date.now() - ms
  const m = Math.floor(diff / 60000)
  const h = Math.floor(m / 60)
  const d = Math.floor(h / 24)
  if (d > 0) return `${d}d ago`
  if (h > 0) return `${h}h ago`
  if (m > 0) return `${m}m ago`
  return 'just now'
}

async function loadAlerts() {
  try {
    const r = await anomalyApi.getEdgeAlerts({ limit: 50 })
    recentAlerts.value = r.alerts
    alertsTotal.value = r.total
  } catch { /* non-fatal */ }
}

// Rolling history buffers
const cpuHistory    = ref<number[]>([])
const memHistory    = ref<number[]>([])
const rxHistory     = ref<number[]>([])
const txHistory     = ref<number[]>([])

function push(buf: number[], val: number) {
  buf.push(val)
  if (buf.length > HISTORY) buf.shift()
}

// Data flow by protocol — points/sec sparklines. The backend only exposes a
// monotonic cumulative counter per protocol (activityMonitor.getThroughputCounters()),
// same as CPU/network here derive history from repeated snapshots rather than a
// server-tracked time series — diff two polls and divide by the elapsed time.
const PROTOCOL_ORDER = ['modbus', 'opcua', 'bacnet', 'mqtt']
const PROTOCOL_HEX: Record<string, string> = { modbus: '#1677ff', opcua: '#722ed1', bacnet: '#fa8c16', mqtt: '#52c41a' }
const protocolHistory  = ref<Record<string, number[]>>(Object.fromEntries(PROTOCOL_ORDER.map(p => [p, []])))
const protocolRate     = ref<Record<string, number>>({})
let previousThroughput: Record<string, number> | null = null
let previousThroughputAt: number | null = null

// Headline rates (the big number on each protocol card, and the combined
// Data Overview Throughput tile) are smoothed over a 60s trailing window
// instead of the raw 3s poll-to-poll diff above. Protocols that publish in
// bursts (e.g. Modbus/BACnet batching ~30s apart) land on exactly 0 most
// 3s samples even while genuinely active — confirmed live: raw cumulative
// counters climbing steadily (modbus/bacnet both incrementing every ~30s)
// while the instantaneous per-poll rate read 0.0/s almost all the time.
// Keeps one shared (timestamp, counters-snapshot) history and looks back to
// the oldest sample still within the window (or the oldest available, if
// the page hasn't been open that long) — same diff-two-snapshots approach,
// just over a longer window shared by every protocol plus the combined
// total. The sparkline history above is intentionally left on the raw
// instantaneous diff — it's what actually shows the bursty texture; only
// the headline numbers needed smoothing.
const THROUGHPUT_WINDOW_MS = 60_000
const THROUGHPUT_HISTORY_MS = 75_000
const throughputCounterHistory: { t: number; counters: Record<string, number> }[] = []
const totalThroughputRate = ref(0)

// Data Overview — Active Points / Active Devices / Good Quality, polled
// alongside throughput (see pollOverview()).
const overview = ref<PipelineOverview | null>(null)

async function pollThroughput() {
  try {
    const counters = await pipelineApi.getThroughput()
    const now = Date.now()

    // Sparkline history: raw instantaneous per-poll rate, unchanged.
    if (previousThroughput && previousThroughputAt) {
      const deltaSec = (now - previousThroughputAt) / 1000
      for (const protocol of PROTOCOL_ORDER) {
        const prev = previousThroughput[protocol] ?? 0
        const curr = counters[protocol] ?? 0
        // A drop (curr < prev) means the agent restarted and the counter reset —
        // treat that tick as 0 rather than a negative rate.
        const rate = deltaSec > 0 && curr >= prev ? (curr - prev) / deltaSec : 0
        push(protocolHistory.value[protocol], rate)
      }
    }

    // Headline rates: 60s-windowed diff, shared base sample for every
    // protocol and the combined total.
    throughputCounterHistory.push({ t: now, counters })
    while (throughputCounterHistory.length > 1 && now - throughputCounterHistory[0].t > THROUGHPUT_HISTORY_MS) {
      throughputCounterHistory.shift()
    }
    const cutoff = now - THROUGHPUT_WINDOW_MS
    let base = throughputCounterHistory[0]
    for (const sample of throughputCounterHistory) {
      if (sample.t <= cutoff) base = sample
      else break
    }
    const baseDeltaSec = (now - base.t) / 1000

    for (const protocol of PROTOCOL_ORDER) {
      const baseCount = base.counters[protocol] ?? 0
      const currCount = counters[protocol] ?? 0
      protocolRate.value[protocol] = baseDeltaSec > 0 && currCount >= baseCount ? (currCount - baseCount) / baseDeltaSec : 0
    }

    const total = PROTOCOL_ORDER.reduce((sum, p) => sum + (counters[p] ?? 0), 0)
    const baseTotal = PROTOCOL_ORDER.reduce((sum, p) => sum + (base.counters[p] ?? 0), 0)
    totalThroughputRate.value = baseDeltaSec > 0 && total >= baseTotal ? (total - baseTotal) / baseDeltaSec : 0

    previousThroughput = counters
    previousThroughputAt = now
  } catch { /* non-fatal — keep showing last known history */ }
}

async function pollOverview() {
  try {
    overview.value = await pipelineApi.getOverview()
  } catch { /* non-fatal */ }
}

// Pick the busiest non-loopback interface
function primaryNet(network: NetworkBandwidth[]): NetworkBandwidth | null {
  const candidates = network.filter((n) => !n.iface.startsWith('lo'))
  if (!candidates.length) return null
  return candidates.reduce((a, b) => (a.rx_sec + a.tx_sec >= b.rx_sec + b.tx_sec ? a : b))
}

async function poll() {
  try {
    const data = await dashboardApi.getStats()
    stats.value = data
    error.value = false
    loading.value = false

    push(cpuHistory.value, data.cpu_usage)
    push(memHistory.value, data.memory_percent)

    const net = primaryNet(data.network)
    push(rxHistory.value, net ? net.rx_sec / 1024 : 0)   // KB/s
    push(txHistory.value, net ? net.tx_sec / 1024 : 0)
  } catch {
    error.value = true
    loading.value = false
  }
  await pollThroughput()
  await pollOverview()
}

let timer: ReturnType<typeof setInterval> | null = null
let alertTimer: ReturnType<typeof setInterval> | null = null
let normalizationHealthTimer: ReturnType<typeof setInterval> | null = null
onMounted(() => {
  poll()
  timer = setInterval(poll, POLL_MS)
  anomalyApi.getEdgeIncidentStats().then((s) => { incidentStats.value = s }).catch(() => {})
  loadAlerts()
  alertTimer = setInterval(loadAlerts, 30_000)
  loadNormalizationHealth()
  normalizationHealthTimer = setInterval(loadNormalizationHealth, 30_000)
})
onUnmounted(() => {
  if (timer) clearInterval(timer)
  if (alertTimer) clearInterval(alertTimer)
  if (normalizationHealthTimer) clearInterval(normalizationHealthTimer)
})

// ── Formatters ────────────────────────────────────────────────────────────────

function fmtUptime(s: number): string {
  const d = Math.floor(s / 86400)
  const h = Math.floor((s % 86400) / 3600)
  const m = Math.floor((s % 3600) / 60)
  const parts = []
  if (d) parts.push(`${d}d`)
  if (h) parts.push(`${h}h`)
  if (m || !parts.length) parts.push(`${m}m`)
  return parts.join(' ')
}

function fmtBytes(kb: number): string {
  if (kb >= 1024) return `${(kb / 1024).toFixed(1)} MB/s`
  return `${kb.toFixed(1)} KB/s`
}

function fmtMb(mb: number): string {
  if (mb >= 1024) return `${(mb / 1024).toFixed(1)} GB`
  return `${mb.toFixed(0)} MB`
}

// Format raw bytes into a human-readable size string
function fmtBytesTotal(bytes: number): string {
  if (bytes >= 1024 ** 3) return `${(bytes / 1024 ** 3).toFixed(2)} GB`
  if (bytes >= 1024 ** 2) return `${(bytes / 1024 ** 2).toFixed(1)} MB`
  if (bytes >= 1024)      return `${(bytes / 1024).toFixed(0)} KB`
  return `${bytes} B`
}

function fmtRate(v: number): string {
  return v >= 10 ? `${v.toFixed(0)}/s` : `${v.toFixed(1)}/s`
}

// Compact large counts for the Data Overview row (e.g. 1240 -> "1.24k"). No
// existing formatter in this app does k/M suffixes (only toLocaleString()
// thousands-separators and date formatting) — this is new but intentionally tiny.
function fmtCompact(v: number): string {
  if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(2)}M`
  if (v >= 1_000) return `${(v / 1_000).toFixed(2)}k`
  return v >= 10 ? v.toFixed(0) : v.toFixed(1)
}

function fmtThroughput(v: number): string {
  return `${fmtCompact(v)}/s`
}

function cpuColor(v: number) { return v >= 90 ? '#cf1322' : v >= 70 ? '#fa8c16' : '#52c41a' }
function memColor(v: number) { return v >= 90 ? '#cf1322' : v >= 75 ? '#fa8c16' : '#1677ff' }

const rxCurrent  = computed(() => rxHistory.value[rxHistory.value.length - 1] ?? 0)
const txCurrent  = computed(() => txHistory.value[txHistory.value.length - 1] ?? 0)
const netIface   = computed(() => stats.value ? (primaryNet(stats.value.network)?.iface ?? '—') : '—')
</script>

<template>
  <AppLayout title="Dashboard">
    <a-spin :spinning="loading">

      <a-alert v-if="error" type="warning" message="Could not reach agent — retrying…" show-icon style="margin-bottom:16px" />

      <!-- ── Anomaly incidents summary ──────────────────────────────────────── -->
      <template v-if="incidentStats">
        <div class="section-label">
          Anomaly Incidents
          <span class="section-link" @click="router.push('/anomaly')">View all →</span>
        </div>
        <a-row :gutter="16" style="margin-bottom:16px">
          <a-col :xs="12" :sm="6">
            <div class="widget widget-clickable" @click="router.push('/anomaly')">
              <div class="widget-title">Open</div>
              <div class="widget-value" :style="{ color: incidentStats.open > 0 ? '#fa8c16' : '#52c41a' }">
                {{ incidentStats.open }}
              </div>
              <div class="widget-sub">awaiting action</div>
            </div>
          </a-col>
          <a-col :xs="12" :sm="6">
            <div class="widget widget-clickable" @click="router.push('/anomaly')">
              <div class="widget-title">Active</div>
              <div class="widget-value" :style="{ color: incidentStats.active > 0 ? '#cf1322' : '#52c41a' }">
                {{ incidentStats.active }}
              </div>
              <div class="widget-sub">currently firing</div>
            </div>
          </a-col>
          <a-col :xs="12" :sm="6">
            <div class="widget widget-clickable" @click="router.push('/anomaly')">
              <div class="widget-title">Resolved</div>
              <div class="widget-value" style="color:var(--text-tertiary)">{{ incidentStats.resolved }}</div>
              <div class="widget-sub">closed incidents</div>
            </div>
          </a-col>
          <a-col :xs="12" :sm="6">
            <div class="widget widget-clickable" @click="router.push('/anomaly')">
              <div class="widget-title">Total</div>
              <div class="widget-value">{{ incidentStats.total }}</div>
              <div class="widget-sub">all time</div>
            </div>
          </a-col>
        </a-row>
      </template>

      <!-- ── Anomaly alerts ────────────────────────────────────────────────────── -->
      <template v-if="recentAlerts.length > 0">
        <div class="section-label">
          Recent Alerts
          <span class="section-link" @click="router.push('/anomaly')">View all →</span>
        </div>
        <div class="widget" style="margin-bottom:16px; padding:0; overflow:hidden">
          <a-table
            :columns="alertColumns"
            :data-source="recentAlerts"
            :pagination="{ pageSize: 5, size: 'small', showSizeChanger: false, hideOnSinglePage: true, showTotal: (total: number) => `${total} alerts` }"
            row-key="alert_id"
            size="small"
            :custom-row="alertRowProps"
            class="alerts-table"
          >
            <template #bodyCell="{ column, record }">
              <template v-if="column.key === 'severity'">
                <a-tag
                  :color="SEVERITY_TAG_COLOR[record.severity]"
                  :class="record.severity === 'critical' ? 'severity-critical' : ''"
                  style="font-size:11px; margin:0"
                >{{ record.severity }}</a-tag>
              </template>
              <template v-else-if="column.key === 'metric'">
                <span :title="record.metric" style="font-size:13px">{{ stripGuids(record.metric) }}</span>
              </template>
              <template v-else-if="column.key === 'device_name'">
                <span style="font-size:13px">{{ deviceLabel(record) }}</span>
              </template>
              <template v-else-if="column.key === 'message'">
                <span style="font-size:12px; color:var(--text-secondary)" :title="record.message">{{ stripGuids(record.message) }}</span>
              </template>
              <template v-else-if="column.key === 'score'">
                <span style="font-variant-numeric:tabular-nums; font-size:12px; color:var(--text-secondary)">{{ record.max_anomaly_score.toFixed(2) }}</span>
              </template>
              <template v-else-if="column.key === 'time'">
                <span style="font-size:11px; color:var(--text-tertiary)">{{ fmtRelTime(record.created_at) }}</span>
              </template>
            </template>
          </a-table>
        </div>
      </template>

      <!-- ── Normalization health ─────────────────────────────────────────────── -->
      <template v-if="normalizationHealth">
        <div class="section-label">
          Normalization Health
          <span class="section-link" @click="normalizationDrawerOpen = true">View details →</span>
        </div>
        <a-row :gutter="16" style="margin-bottom:12px">
          <a-col :xs="12" :sm="6">
            <div class="widget">
              <div class="widget-title">Unknown Units</div>
              <div class="widget-value" :style="{ color: normalizationHealth.unknownUnits.count > 0 ? '#fa8c16' : '#52c41a' }">
                {{ normalizationHealth.unknownUnits.count }}
              </div>
              <div class="widget-sub">distinct units not recognized</div>
            </div>
          </a-col>
          <a-col :xs="12" :sm="6">
            <div class="widget">
              <div class="widget-title">Conversion Failures</div>
              <div class="widget-value" :style="{ color: normalizationHealth.conversionFailures.count > 0 ? '#fa8c16' : '#52c41a' }">
                {{ normalizationHealth.conversionFailures.count }}
              </div>
              <div class="widget-sub">distinct unsupported conversions</div>
            </div>
          </a-col>
        </a-row>
        <div v-if="normalizationHealth.unknownUnits.items.length > 0" class="widget" style="margin-bottom:16px; padding:0; overflow:hidden">
          <a-table
            :columns="normalizationUnitColumns"
            :data-source="normalizationHealth.unknownUnits.items.slice(0, 5)"
            :pagination="false"
            row-key="label"
            size="small"
          >
            <template #bodyCell="{ column, record }">
              <template v-if="column.key === 'label'">
                <span :title="record.label" style="font-size:13px">{{ record.label }}</span>
              </template>
              <template v-else-if="column.key === 'protocol'">
                <span style="font-size:12px; color:var(--text-tertiary)">{{ record.protocol ?? '—' }}</span>
              </template>
            </template>
          </a-table>
        </div>
      </template>

      <template v-if="stats">

        <!-- ── Row 1: Network ──────────────────────────────────────────────── -->
        <div class="section-label">Network · {{ netIface }}</div>
        <a-row :gutter="16" style="margin-bottom:16px">

          <a-col :xs="24" :sm="12" :lg="6">
            <div class="widget">
              <div class="widget-title">Bandwidth In</div>
              <div class="widget-value" style="color:#1677ff">{{ fmtBytes(rxCurrent) }}</div>
              <SparklineChart :data="rxHistory" color="#1677ff" fill-color="rgba(22,119,255,0.12)" />
              <div class="widget-sub">last {{ rxHistory.length * 3 }}s</div>
            </div>
          </a-col>

          <a-col :xs="24" :sm="12" :lg="6">
            <div class="widget">
              <div class="widget-title">Bandwidth Out</div>
              <div class="widget-value" style="color:#722ed1">{{ fmtBytes(txCurrent) }}</div>
              <SparklineChart :data="txHistory" color="#722ed1" fill-color="rgba(114,46,209,0.1)" />
              <div class="widget-sub">last {{ txHistory.length * 3 }}s</div>
            </div>
          </a-col>

          <a-col :xs="24" :sm="12" :lg="6">
            <div class="widget">
              <div class="widget-title">Total Received</div>
              <div class="widget-value">
                {{ stats.network.length ? fmtBytesTotal(primaryNet(stats.network)?.rx_bytes ?? 0) : '—' }}
              </div>
              <div class="widget-sub">since last restart</div>
            </div>
          </a-col>

          <a-col :xs="24" :sm="12" :lg="6">
            <div class="widget">
              <div class="widget-title">Total Sent</div>
              <div class="widget-value">
                {{ stats.network.length ? fmtBytesTotal(primaryNet(stats.network)?.tx_bytes ?? 0) : '—' }}
              </div>
              <div class="widget-sub">since last restart</div>
            </div>
          </a-col>

        </a-row>

        <!-- ── Row 2: Performance charts ─────────────────────────────────── -->
        <div class="section-label">Performance History · last {{ cpuHistory.length * 3 }}s</div>
        <a-row :gutter="16" style="margin-bottom:16px">

          <a-col :xs="24" :lg="12">
            <div class="widget chart-widget">
              <div class="chart-header">
                <span class="widget-title">CPU Usage</span>
                <span class="chart-current" :style="{ color: cpuColor(stats.cpu_usage) }">{{ stats.cpu_usage }}%</span>
              </div>
              <div class="chart-body">
                <SparklineChart
                  :data="cpuHistory"
                  :color="cpuColor(stats.cpu_usage)"
                  :fill-color="`${cpuColor(stats.cpu_usage)}22`"
                  :max-value="100"
                  :height="90"
                  full-width
                />
              </div>
              <a-progress
                :percent="stats.cpu_usage"
                :stroke-color="cpuColor(stats.cpu_usage)"
                :show-info="false"
                size="small"
                style="margin-top:8px"
              />
            </div>
          </a-col>

          <a-col :xs="24" :lg="12">
            <div class="widget chart-widget">
              <div class="chart-header">
                <span class="widget-title">Memory Usage</span>
                <span class="chart-current" :style="{ color: memColor(stats.memory_percent) }">
                  {{ stats.memory_percent }}%
                  <span class="chart-sub">{{ fmtMb(stats.memory_used) }} / {{ fmtMb(stats.memory_total) }}</span>
                </span>
              </div>
              <div class="chart-body">
                <SparklineChart
                  :data="memHistory"
                  :color="memColor(stats.memory_percent)"
                  :fill-color="`${memColor(stats.memory_percent)}22`"
                  :max-value="100"
                  :height="90"
                  full-width
                />
              </div>
              <a-progress
                :percent="stats.memory_percent"
                :stroke-color="memColor(stats.memory_percent)"
                :show-info="false"
                size="small"
                style="margin-top:8px"
              />
            </div>
          </a-col>

        </a-row>

        <!-- ── Row 2a: Data overview ───────────────────────────────────────── -->
        <div class="section-label">Data Overview</div>
        <a-row :gutter="16" style="margin-bottom:16px">
          <a-col :xs="12" :sm="6">
            <div class="widget">
              <div class="widget-title">Throughput</div>
              <div class="widget-value">{{ fmtThroughput(totalThroughputRate) }}</div>
              <div class="widget-sub">last 60s</div>
            </div>
          </a-col>
          <a-col :xs="12" :sm="6">
            <div class="widget">
              <div class="widget-title">Active Points</div>
              <div class="widget-value">{{ overview ? overview.activePoints.toLocaleString() : '—' }}</div>
              <div class="widget-sub">last 5m</div>
            </div>
          </a-col>
          <a-col :xs="12" :sm="6">
            <div class="widget">
              <div class="widget-title">Active Devices</div>
              <div class="widget-value">{{ overview ? overview.activeDevices.toLocaleString() : '—' }}</div>
              <div class="widget-sub">last 5m</div>
            </div>
          </a-col>
          <a-col :xs="12" :sm="6">
            <div class="widget">
              <div class="widget-title">Good Quality</div>
              <div class="widget-value">
                {{ overview?.goodQualityPct != null ? `${overview.goodQualityPct.toFixed(1)}%` : '—' }}
              </div>
              <div class="widget-sub">last 5m</div>
            </div>
          </a-col>
        </a-row>

        <!-- ── Row 2b: Data flow by protocol ─────────────────────────────── -->
        <div class="section-label">
          Data Flow by Protocol
          <span class="section-link" @click="router.push('/data-flow')">View details →</span>
        </div>
        <a-row :gutter="16" style="margin-bottom:16px">
          <a-col v-for="protocol in PROTOCOL_ORDER" :key="protocol" :xs="24" :sm="12" :lg="6">
            <div class="widget chart-widget">
              <div class="chart-header">
                <span class="widget-title">{{ protocolLabel(protocol) }}</span>
                <span class="chart-current" :style="{ color: PROTOCOL_HEX[protocol] }">
                  {{ fmtRate(protocolRate[protocol] ?? 0) }}
                </span>
              </div>
              <div class="chart-body">
                <SparklineChart
                  :data="protocolHistory[protocol]"
                  :color="PROTOCOL_HEX[protocol]"
                  :fill-color="`${PROTOCOL_HEX[protocol]}22`"
                  :height="60"
                  full-width
                />
              </div>
              <div class="widget-sub">points/sec · 60s avg</div>
            </div>
          </a-col>
        </a-row>

        <!-- ── Row 3: System ───────────────────────────────────────────────── -->
        <div class="section-label">System · {{ stats.hostname }}</div>
        <a-row :gutter="16" style="margin-bottom:16px">

          <a-col :xs="24" :sm="12" :lg="6">
            <div class="widget">
              <div class="widget-title">CPU Usage</div>
              <div class="widget-value" :style="{ color: cpuColor(stats.cpu_usage) }">
                {{ stats.cpu_usage }}%
              </div>
              <SparklineChart
                :data="cpuHistory"
                :color="cpuColor(stats.cpu_usage)"
                :fill-color="`${cpuColor(stats.cpu_usage)}22`"
              />
              <a-progress
                :percent="stats.cpu_usage"
                :stroke-color="cpuColor(stats.cpu_usage)"
                :show-info="false"
                size="small"
                style="margin-top:6px"
              />
            </div>
          </a-col>

          <a-col :xs="24" :sm="12" :lg="6">
            <div class="widget">
              <div class="widget-title">Memory</div>
              <div class="widget-value" :style="{ color: memColor(stats.memory_percent) }">
                {{ stats.memory_percent }}%
              </div>
              <SparklineChart
                :data="memHistory"
                :color="memColor(stats.memory_percent)"
                :fill-color="`${memColor(stats.memory_percent)}22`"
              />
              <div class="widget-sub">{{ fmtMb(stats.memory_used) }} / {{ fmtMb(stats.memory_total) }}</div>
            </div>
          </a-col>

          <a-col :xs="24" :sm="12" :lg="6">
            <div class="widget">
              <div class="widget-title">Storage</div>
              <template v-if="stats.storage_percent != null">
                <div class="widget-value">{{ stats.storage_percent }}%</div>
                <a-progress
                  :percent="stats.storage_percent"
                  :stroke-color="stats.storage_percent >= 90 ? '#cf1322' : '#52c41a'"
                  :show-info="false"
                  size="small"
                  style="margin-top:16px"
                />
                <div class="widget-sub">
                  {{ fmtMb(stats.storage_used!) }} / {{ fmtMb(stats.storage_total!) }}
                </div>
              </template>
              <div v-else class="widget-value" style="color:var(--text-tertiary)">—</div>
            </div>
          </a-col>

          <a-col :xs="24" :sm="12" :lg="6">
            <div class="widget">
              <div class="widget-title">Uptime</div>
              <div class="widget-value" style="font-size:22px">{{ fmtUptime(stats.uptime) }}</div>
              <div class="widget-sub" style="margin-top:8px">{{ stats.hostname }}</div>
            </div>
          </a-col>

        </a-row>

        <!-- ── Row 3: Interfaces table ─────────────────────────────────────── -->
        <div class="section-label">Network Interfaces</div>
        <a-table
          :data-source="stats.network.filter(n => !n.iface.startsWith('lo'))"
          :columns="netColumns"
          :pagination="false"
          row-key="iface"
          size="small"
        >
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'rx_sec'">
              <span style="color:#1677ff">{{ fmtBytes(record.rx_sec / 1024) }}</span>
            </template>
            <template v-else-if="column.key === 'tx_sec'">
              <span style="color:#722ed1">{{ fmtBytes(record.tx_sec / 1024) }}</span>
            </template>
            <template v-else-if="column.key === 'rx_bytes'">
              <span style="color:var(--text-tertiary); font-size:12px">{{ fmtBytesTotal(record.rx_bytes) }}</span>
            </template>
            <template v-else-if="column.key === 'tx_bytes'">
              <span style="color:var(--text-tertiary); font-size:12px">{{ fmtBytesTotal(record.tx_bytes) }}</span>
            </template>
          </template>
        </a-table>

      </template>
    </a-spin>

    <NormalizationHealthDrawer v-model:open="normalizationDrawerOpen" :data="normalizationHealth" @resolved="loadNormalizationHealth" />
  </AppLayout>
</template>


<style scoped>
.section-label {
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--text-tertiary);
  margin-bottom: 10px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.section-link {
  font-size: 11px;
  font-weight: 500;
  color: #1677ff;
  cursor: pointer;
  text-transform: none;
  letter-spacing: 0;
  margin-left: auto;
}

.section-link:hover {
  color: #4096ff;
}

.widget-clickable {
  cursor: pointer;
  transition: border-color 0.15s, box-shadow 0.15s;
}

.widget-clickable:hover {
  border-color: var(--border-color-strong);
  box-shadow: var(--shadow-card-hover);
}

.widget {
  background: var(--bg-subtle);
  border: 1px solid var(--border-color);
  border-radius: 8px;
  padding: 16px 18px 12px;
  height: 100%;
}

.widget-title {
  font-size: 12px;
  color: var(--text-tertiary);
  margin-bottom: 6px;
  font-weight: 500;
}

.widget-value {
  font-size: 28px;
  font-weight: 700;
  line-height: 1.1;
  margin-bottom: 10px;
  font-variant-numeric: tabular-nums;
}

.widget-sub {
  font-size: 11px;
  color: var(--text-tertiary);
  margin-top: 6px;
}

.chart-widget {
  padding-bottom: 14px;
}

.chart-header {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  margin-bottom: 10px;
}

.chart-current {
  font-size: 22px;
  font-weight: 700;
  line-height: 1;
  font-variant-numeric: tabular-nums;
}

.chart-sub {
  font-size: 11px;
  color: var(--text-tertiary);
  font-weight: 400;
  margin-left: 6px;
}

.chart-body {
  line-height: 0;
}

.alerts-table :deep(.ant-table-row) {
  cursor: pointer;
}

@keyframes severity-pulse {
  0%, 100% { opacity: 1; box-shadow: 0 0 7px 2px rgba(255, 77, 79, 0.75); }
  50%       { opacity: 0;   box-shadow: none; }
}

.severity-critical {
  animation: severity-pulse 0.75s ease-in-out infinite;
}
</style>
