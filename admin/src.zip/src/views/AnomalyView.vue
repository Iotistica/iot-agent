<script setup lang="ts">
import { ref, computed, watch, onMounted, onUnmounted } from 'vue'
import { message } from 'ant-design-vue'
import {
  DeleteOutlined,
  PlusOutlined,
  ReloadOutlined,
  SearchOutlined,
} from '@ant-design/icons-vue'
import type { TableColumnType } from 'ant-design-vue'
import AppLayout from '@/components/layout/AppLayout.vue'
import { useProStatus } from '@/composables/useProStatus'

const { proInstalled } = useProStatus()
import { anomalyApi, driftRulesApi, RESOLUTION_REASON_LABELS, type BadActor, type ResolutionReason } from '@/api/anomaly'
import { client as apiClient } from '@/api/client'
import { sourcesApi } from '@/api/sources'
import { BUILTIN_ANOMALY_TEMPLATES, type BuiltinAnomalyTemplate } from '@/data/anomalyTemplates'
import type {
  AnomalyBaseline,
  AnomalyConfig,
  AnomalyMetricConfig,
  AnomalyRuleTemplate,
  DetectionMethod,
  EdgeAnomalyEvent,
  EdgeAnomalyIncident,
  EdgeAnomalyAlert,
  DriftRuleConfig,
  MetricScope,
} from '@/types'
import DriftRuleDrawer, { DRIFT_TYPE_LABELS, DRIFT_TYPE_TAG_COLORS } from '@/components/DriftRuleDrawer.vue'
import PointPickerModal from '@/components/PointPickerModal.vue'
import type { PointCatalogEntry } from '@/api/point-catalog'
import { PROTOCOL_LABELS, protocolLabel, protocolColor } from '@/utils/protocol'

// ── Shared ────────────────────────────────────────────────────────────────────
const activeTab = ref('incidents')

const SEVERITY_TAG_COLOR: Record<string, string> = {
  critical: 'red',
  warning: 'orange',
  info: 'blue',
}
const SEVERITY_ORDER = ['info', 'warning', 'critical']

// Strips every embedded "<uuid>_" occurrence from free-text strings (e.g. alert messages).
const GUID_ANYWHERE = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}_/gi
function stripGuids(text: string): string {
  return text ? text.replace(GUID_ANYWHERE, '') : text
}

function fmtTs(ms: number | string): string {
  if (!ms) return '—'
  return new Date(ms).toLocaleString()
}

function fmtNum(n: number | null | undefined, decimals = 3): string {
  if (n == null || isNaN(n)) return '—'
  return n.toFixed(decimals)
}

// Generic debounce keyed by name, so independent debounced actions (one per
// tab's live-filter) don't clobber each other's pending timers.
const debounceTimers = new Map<string, ReturnType<typeof setTimeout>>()
function debounce(key: string, fn: () => void, delayMs = 300) {
  const existing = debounceTimers.get(key)
  if (existing) clearTimeout(existing)
  debounceTimers.set(key, setTimeout(fn, delayMs))
}

// Only one tab is visible at a time, so a single shared interval covers
// "auto-refresh whichever tab is active" — this replaces manual reload buttons.
let tabRefreshTimer: ReturnType<typeof setInterval> | null = null
function startTabAutoRefresh(loadFn: () => void, loadingRef: { value: boolean }, intervalMs = 5000) {
  stopTabAutoRefresh()
  tabRefreshTimer = setInterval(() => {
    if (!loadingRef.value) loadFn()
  }, intervalMs)
}
function stopTabAutoRefresh() {
  if (tabRefreshTimer) {
    clearInterval(tabRefreshTimer)
    tabRefreshTimer = null
  }
}

// ── Warm-up countdown ────────────────────────────────────────────────────────
// Global, agent-uptime-relative alert suppression (default 15 min after agent
// start) — independent of any single metric's baseline/buffer state, so it
// needs its own indicator rather than piggybacking on the Baselines tab.
// Fetched once (absolute end time), then ticks locally every second so the
// countdown is smooth without re-polling the server every second.
const warmupRemainingMs = ref<number | null>(null)
let warmupEndsAt: number | null = null
let warmupTimer: ReturnType<typeof setInterval> | null = null

const warmupCountdownLabel = computed(() => {
  if (!warmupRemainingMs.value) return ''
  const totalSeconds = Math.ceil(warmupRemainingMs.value / 1000)
  const m = Math.floor(totalSeconds / 60)
  const s = totalSeconds % 60
  return `${m}:${String(s).padStart(2, '0')}`
})

function stopWarmupCountdown() {
  if (warmupTimer) {
    clearInterval(warmupTimer)
    warmupTimer = null
  }
}

async function loadWarmupStatus() {
  try {
    const { stats } = await anomalyApi.getStats()
    const remaining = stats.warmupRemainingMs ?? 0
    if (remaining <= 0) {
      warmupRemainingMs.value = null
      stopWarmupCountdown()
      return
    }
    warmupEndsAt = Date.now() + remaining
    warmupRemainingMs.value = remaining
    stopWarmupCountdown()
    warmupTimer = setInterval(() => {
      const left = Math.max(0, (warmupEndsAt ?? 0) - Date.now())
      warmupRemainingMs.value = left > 0 ? left : null
      if (left <= 0) stopWarmupCountdown()
    }, 1000)
  } catch {
    // non-fatal — banner just won't show
  }
}

// ── Edge: Events ──────────────────────────────────────────────────────────────
const edgeEvents = ref<EdgeAnomalyEvent[]>([])
const edgeEventsTotal = ref(0)
const edgeEventsLoading = ref(false)
const edgeEventsSeverity = ref('')
const edgeEventsPage = ref(1)
const PAGE_SIZE = 50

const edgeEventColumns = [
  { title: 'Severity', key: 'severity', width: 100, sorter: (a: EdgeAnomalyEvent, b: EdgeAnomalyEvent) => SEVERITY_ORDER.indexOf(a.severity) - SEVERITY_ORDER.indexOf(b.severity) },
  { title: 'Device', key: 'device_name', width: 160, ellipsis: true, sorter: (a: EdgeAnomalyEvent, b: EdgeAnomalyEvent) => a.device_name.localeCompare(b.device_name) },
  { title: 'Point', key: 'metric', ellipsis: true, sorter: (a: EdgeAnomalyEvent, b: EdgeAnomalyEvent) => a.metric.localeCompare(b.metric) },
  { title: 'Value', key: 'value', width: 90, sorter: (a: EdgeAnomalyEvent, b: EdgeAnomalyEvent) => (a.observed_value ?? 0) - (b.observed_value ?? 0) },
  { title: 'Score', key: 'score', width: 80, sorter: (a: EdgeAnomalyEvent, b: EdgeAnomalyEvent) => a.anomaly_score - b.anomaly_score },
  { title: 'Conf', key: 'conf', width: 75, sorter: (a: EdgeAnomalyEvent, b: EdgeAnomalyEvent) => a.confidence - b.confidence },
  { title: 'Consecutive', key: 'consec', width: 90, sorter: (a: EdgeAnomalyEvent, b: EdgeAnomalyEvent) => a.consecutive_count - b.consecutive_count },
  { title: 'Time', key: 'time', width: 160, sorter: (a: EdgeAnomalyEvent, b: EdgeAnomalyEvent) => a.timestamp_ms - b.timestamp_ms },
]

async function loadEdgeEvents() {
  edgeEventsLoading.value = true
  try {
    const [r] = await Promise.all([
      anomalyApi.getEdgeEvents({
        severity: edgeEventsSeverity.value || undefined,
        limit: PAGE_SIZE,
        offset: (edgeEventsPage.value - 1) * PAGE_SIZE,
      }),
      ensureEndpointMaps(),
    ])
    edgeEvents.value = r.events
    edgeEventsTotal.value = r.total
  } catch { /* non-fatal */ } finally {
    edgeEventsLoading.value = false
  }
}

// ── Edge: Incidents ───────────────────────────────────────────────────────────
const edgeIncidents = ref<EdgeAnomalyIncident[]>([])
const edgeIncidentsTotal = ref(0)
const edgeIncidentsLoading = ref(false)
const edgeIncidentsStatus = ref('')
const edgeIncidentsPage = ref(1)
const resolvingId = ref<string | null>(null)

const edgeIncidentColumns = [
  { title: 'Severity', key: 'severity', width: 95, sorter: (a: EdgeAnomalyIncident, b: EdgeAnomalyIncident) => SEVERITY_ORDER.indexOf(a.severity) - SEVERITY_ORDER.indexOf(b.severity) },
  { title: 'Point', key: 'metric', ellipsis: true, sorter: (a: EdgeAnomalyIncident, b: EdgeAnomalyIncident) => a.metric.localeCompare(b.metric) },
  { title: 'Device', key: 'device_name', width: 160, ellipsis: true, sorter: (a: EdgeAnomalyIncident, b: EdgeAnomalyIncident) => a.device_name.localeCompare(b.device_name) },
  { title: 'Status', key: 'status', width: 90, sorter: (a: EdgeAnomalyIncident, b: EdgeAnomalyIncident) => a.status.localeCompare(b.status) },
  { title: 'Events', dataIndex: 'event_count', key: 'event_count', width: 70, sorter: (a: EdgeAnomalyIncident, b: EdgeAnomalyIncident) => a.event_count - b.event_count },
  { title: 'Score', key: 'score', width: 80, sorter: (a: EdgeAnomalyIncident, b: EdgeAnomalyIncident) => a.max_anomaly_score - b.max_anomaly_score },
  { title: 'First seen', key: 'first_seen', width: 155, sorter: (a: EdgeAnomalyIncident, b: EdgeAnomalyIncident) => a.first_seen - b.first_seen },
  { title: 'Last seen', key: 'last_seen', width: 155, sorter: (a: EdgeAnomalyIncident, b: EdgeAnomalyIncident) => a.last_seen - b.last_seen },
  { title: '', key: 'actions', width: 90, fixed: 'right' },
]

const INCIDENT_STATUS_COLOR: Record<string, string> = { open: 'orange', active: 'red', resolved: 'green' }

async function loadEdgeIncidents() {
  edgeIncidentsLoading.value = true
  try {
    const [r] = await Promise.all([
      anomalyApi.getEdgeIncidents({
        status: edgeIncidentsStatus.value || undefined,
        limit: PAGE_SIZE,
        offset: (edgeIncidentsPage.value - 1) * PAGE_SIZE,
      }),
      ensureEndpointMaps(),
    ])
    edgeIncidents.value = r.incidents
    edgeIncidentsTotal.value = r.total
  } catch { /* non-fatal */ } finally {
    edgeIncidentsLoading.value = false
  }
}

// Reason is captured (not just a bare confirm) so noisy rules can eventually
// be found by false-positive rate, not just raw incident count — see the
// Bad Actors panel on the Rules tab. Kept to a single required dropdown plus
// optional free-text notes, not a full form, so resolving stays low-friction.
const resolveModalOpen = ref(false)
const resolveModalIncident = ref<EdgeAnomalyIncident | null>(null)
const resolveModalReason = ref<ResolutionReason | undefined>(undefined)
const resolveModalNotes = ref('')

function openResolveModal(incident: EdgeAnomalyIncident) {
  resolveModalIncident.value = incident
  resolveModalReason.value = undefined
  resolveModalNotes.value = ''
  resolveModalOpen.value = true
}

async function confirmResolve() {
  const incident = resolveModalIncident.value
  if (!incident || !resolveModalReason.value) return
  resolvingId.value = incident.incident_id
  try {
    await anomalyApi.resolveIncident(incident.incident_id, resolveModalReason.value, resolveModalNotes.value.trim() || undefined)
    message.success('Incident resolved')
    resolveModalOpen.value = false
    loadEdgeIncidents()
  } catch (err: unknown) {
    message.error((err as { message?: string })?.message ?? 'Failed to resolve')
  } finally {
    resolvingId.value = null
  }
}

// ── Edge: Alerts ──────────────────────────────────────────────────────────────
const edgeAlerts = ref<EdgeAnomalyAlert[]>([])
const edgeAlertsTotal = ref(0)
const edgeAlertsLoading = ref(false)
const edgeAlertsPage = ref(1)

const edgeAlertColumns = [
  { title: 'Severity', key: 'severity', width: 100, sorter: (a: EdgeAnomalyAlert, b: EdgeAnomalyAlert) => SEVERITY_ORDER.indexOf(a.severity) - SEVERITY_ORDER.indexOf(b.severity) },
  { title: 'Point', key: 'metric', ellipsis: true, sorter: (a: EdgeAnomalyAlert, b: EdgeAnomalyAlert) => a.metric.localeCompare(b.metric) },
  { title: 'Device', key: 'device_name', width: 160, ellipsis: true, sorter: (a: EdgeAnomalyAlert, b: EdgeAnomalyAlert) => a.device_name.localeCompare(b.device_name) },
  { title: 'Score', key: 'score', width: 80, sorter: (a: EdgeAnomalyAlert, b: EdgeAnomalyAlert) => a.max_anomaly_score - b.max_anomaly_score },
  { title: 'Message', dataIndex: 'message', key: 'message', width: 500 },
  { title: 'Time', key: 'time', width: 160, sorter: (a: EdgeAnomalyAlert, b: EdgeAnomalyAlert) => a.created_at - b.created_at },
]

async function loadEdgeAlerts() {
  edgeAlertsLoading.value = true
  try {
    const [r] = await Promise.all([
      anomalyApi.getEdgeAlerts({ limit: PAGE_SIZE, offset: (edgeAlertsPage.value - 1) * PAGE_SIZE }),
      ensureEndpointMaps(),
    ])
    edgeAlerts.value = r.alerts
    edgeAlertsTotal.value = r.total
  } catch { /* non-fatal */ } finally {
    edgeAlertsLoading.value = false
  }
}

// ── Baselines tab ──────────────────────────────────────────────────────────────
// pendingWindowSize is set whenever a metric's buffer hasn't yet filled to its
// configured windowSize — on synthesized placeholder rows (no real baseline saved
// yet) AND on real baseline rows (saveBaselines() persists as soon as
// buffer.size >= minSamples, which is far below windowSize, so a "real" row can
// still be actively collecting). isSynthetic distinguishes the two: only true for
// placeholder rows with no calculated_at/time_slot of their own.
type BaselineRow = AnomalyBaseline & { pendingWindowSize?: number; isSynthetic?: boolean; isGroupRule?: boolean; groupMetricCount?: number; groupReadyCount?: number }
const baselines = ref<BaselineRow[]>([])
const baselinesTotal = ref(0)
const baselinesLoading = ref(false)
const baselinesMetric = ref('')
const baselinesPage = ref(1)

// Group rule detail modal
const groupDetailVisible = ref(false)
const groupDetailRule = ref<BaselineRow | null>(null)
const latestGroupProgress = ref<import('@/api/anomaly').BaselineProgress[]>([])
const groupDetailMetrics = computed(() => {
  if (!groupDetailRule.value) return []
  return latestGroupProgress.value.filter((p) => p.configName === groupDetailRule.value!.metric)
})
function openGroupDetail(record: BaselineRow) {
  groupDetailRule.value = record
  groupDetailVisible.value = true
}

// Live-filter as you type instead of requiring Enter/a manual reload button —
// debounced so every keystroke doesn't fire its own request.
watch(baselinesMetric, () => {
  debounce('baselines-filter', () => {
    baselinesPage.value = 1
    loadBaselines()
  })
})

const baselineColumns = [
  { title: 'Point', key: 'metric', ellipsis: true, sorter: (a: BaselineRow, b: BaselineRow) => a.metric.localeCompare(b.metric) },
  { title: 'Device', key: 'device_id', width: 160, ellipsis: true, sorter: (a: BaselineRow, b: BaselineRow) => a.device_id.localeCompare(b.device_id) },
  { title: 'Status', dataIndex: 'device_state', key: 'device_state', width: 100, sorter: (a: BaselineRow, b: BaselineRow) => a.device_state.localeCompare(b.device_state) },
  { title: 'Slot', dataIndex: 'time_slot', key: 'time_slot', width: 55, sorter: (a: BaselineRow, b: BaselineRow) => a.time_slot - b.time_slot },
  { title: 'Mean', key: 'mean', width: 90, sorter: (a: BaselineRow, b: BaselineRow) => (a.mean ?? 0) - (b.mean ?? 0) },
  { title: 'Std dev', key: 'std_dev', width: 90, sorter: (a: BaselineRow, b: BaselineRow) => (a.std_dev ?? 0) - (b.std_dev ?? 0) },
  { title: 'Median', key: 'median', width: 90, sorter: (a: BaselineRow, b: BaselineRow) => (a.median ?? 0) - (b.median ?? 0) },
  { title: 'MAD', key: 'mad', width: 90, sorter: (a: BaselineRow, b: BaselineRow) => (a.mad ?? 0) - (b.mad ?? 0) },
  { title: 'Samples', dataIndex: 'sample_count', key: 'sample_count', width: 80, sorter: (a: BaselineRow, b: BaselineRow) => a.sample_count - b.sample_count },
  { title: 'Calculated', key: 'calculated_at', width: 160, sorter: (a: BaselineRow, b: BaselineRow) => a.calculated_at - b.calculated_at },
]

// Maps endpoint UUID → display name (for events/incidents/alerts/baselines metric prefix lookup)
const endpointsByUuid = ref<Map<string, string>>(new Map())
// Maps an endpoint's raw/sanitized config name (e.g. "rtu_1_controller_1001")
// → the same nice display name endpointsByUuid resolves — events/incidents/
// alerts record a reading's raw adapter-reported deviceName tag, not its
// uuid, so this is the lookup deviceDisplayName() needs for those.
const displayNameByRawName = ref<Map<string, string>>(new Map())
// Maps "endpointUuid::sanitizedPointName" → the raw protocol-native point name
// (BACnet objectName / OPC-UA browseName, e.g. "Space-Temp") as reported by the
// device, for tables that show the point name and would otherwise only have the
// sanitized identifier (lowercased, punctuation stripped) to display.
const pointRawNameByKey = ref<Map<string, string>>(new Map())
// Maps a bare sanitized point name (e.g. "ahu_1_rf_speed") → its owning
// device's display name. Anomaly rules are often saved using this bare,
// already-device-prefixed point name with no separate deviceName recorded on
// the rule itself, so this is how the Rules table recovers "which device is
// this rule actually for" without guessing from the name's word count.
const pointNameToDevice = ref<Map<string, string>>(new Map())

let _endpointMapsPromise: Promise<void> | null = null
async function ensureEndpointMaps() {
  if (endpointsByUuid.value.size > 0) return
  if (_endpointMapsPromise) return _endpointMapsPromise
  _endpointMapsPromise = _loadEndpointMaps()
  try { await _endpointMapsPromise } finally { _endpointMapsPromise = null }
}
async function _loadEndpointMaps() {
  try {
    const [eps, devResult] = await Promise.all([
      sourcesApi.getAll(),
      apiClient.get<{ devices: Array<{ uuid: string; name: string }> }>('/v1/devices').catch(() => ({ data: { devices: [] } })),
    ])
    const byUuid = new Map<string, string>()
    const byRawName = new Map<string, string>()
    const rawNameByKey = new Map<string, string>()
    const deviceByPointName = new Map<string, string>()
    for (const ep of eps) {
      const displayName = (ep.metadata?.objectName as string | undefined) || ep.name
      byUuid.set(ep.uuid, displayName)
      byRawName.set(ep.name, displayName)

      for (const dp of (ep.data_points ?? []) as Array<Record<string, unknown>>) {
        const sanitizedName = dp?.name
        const rawName = (dp?.objectName ?? dp?.browseName) as string | undefined
        if (typeof sanitizedName === 'string' && typeof rawName === 'string' && rawName) {
          rawNameByKey.set(`${ep.uuid}::${sanitizedName}`, rawName)
        }
        if (typeof sanitizedName === 'string') {
          deviceByPointName.set(sanitizedName, displayName)
        }
      }
    }

    for (const dev of devResult.data.devices ?? []) {
      if (!byUuid.has(dev.uuid)) byUuid.set(dev.uuid, dev.name)
    }

    endpointsByUuid.value = byUuid
    displayNameByRawName.value = byRawName
    pointRawNameByKey.value = rawNameByKey
    pointNameToDevice.value = deviceByPointName
  } catch { /* non-fatal */ }
}

// Reformats a bare field-name leaf for display as hyphenated lowercase —
// "rf_speed" -> "rf-speed" — matching Data View/Schema Drift's convention.
// Kept in sync by hand with drift-labels.ts's prettifyDriftFieldName /
// device-identity's prettifyFieldName (frontend can't import either).
function hyphenateField(field: string): string {
  return field.replace(/_/g, '-')
}

// Given a metric's raw stored name and its optionally-explicit device name,
// resolves which device it belongs to (the explicit deviceName field, or a
// fallback lookup by bare point name — see pointNameToDevice above) and the
// metric's own leaf name with that device's prefix stripped off the front —
// the same "field carries the device prefix baked in" pattern schema drift
// has (see stripFieldDevicePrefix on the backend). This is the one shared
// implementation for both the Rules grid and the "Add rule" autocomplete —
// don't reimplement this splitting logic a second time; both need the exact
// same device/field resolution to display consistently with each other.
function resolveDeviceAndLeaf(name: string, explicitDeviceName?: string): { device?: string; leaf: string } {
  const device = explicitDeviceName || pointNameToDevice.value.get(name)
  if (!device) return { leaf: hyphenateField(name) }

  const prefix = `${device.toLowerCase().replace(/[\s-]+/g, '_')}_`
  const leaf = name.toLowerCase().startsWith(prefix) ? name.slice(prefix.length) : name
  return { device, leaf: hyphenateField(leaf) }
}

// The agent's own self-monitoring metrics — the only two system-sourced
// (device-less) rules the product ships today (src/system/metrics.ts /
// iot-agent-pro's anomaly defaults). Rules for these never carry a
// deviceName (there's no endpoint/device to attach one to), which the
// grid used to show as a bare "—" — indistinguishable from a genuinely
// unresolved device — instead of "System", the same sentinel
// Events/Incidents/Alerts/Baselines already show for them.
const SYSTEM_METRIC_NAMES = new Set(['cpu_usage', 'memory_percent'])

// The rule's device, either explicitly recorded (record.deviceName),
// recovered via the bare-point-name lookup above, or "System" for a known
// system-sourced metric with no device to attach.
function ruleDeviceName(record: AnomalyMetricConfig): string | undefined {
  const device = resolveDeviceAndLeaf(record.name, record.deviceName).device
  if (device) return device
  return SYSTEM_METRIC_NAMES.has(record.name) ? 'System' : undefined
}

function ruleScopeLabel(record: AnomalyMetricConfig): string {
  if (record.scope === 'source') return record.sourcePattern ?? '—'
  if (record.scope === 'protocol') return protocolLabel(record.protocolPattern ?? '')
  return ruleDeviceName(record) ?? '—'
}

// Schema-drift device identifiers (e.g. "bms_gateway_5000_bc814573") carry a
// "_{instance}_{8-hex-id}" suffix appended for fleet-wide uniqueness (see the
// Pro schema-drift detector) — metricLeaf() below still needs to strip this
// when comparing a field name against its device base name.
const DRIFT_DEVICE_SUFFIX_RE = /_\d+_[0-9a-f]{8}$/i

// Resolves a device identity (either a real UUID, as anomaly baselines record
// it, or a raw/sanitized adapter config name, as anomaly events/incidents/
// alerts record it — see AnomalyFeed's tags.deviceName) to the nice,
// discovery-captured display name (e.g. "RTU-1 Controller"). Both
// endpointsByUuid and displayNameByRawName come from the same
// ensureEndpointMaps() call, so this never needs to guess at a
// reconstruction — just look the value up directly, or fall back to it
// unchanged if it's something we don't have a name on file for.
function deviceDisplayName(idOrName: string | undefined): string {
  if (!idOrName || idOrName === 'unknown') return '—'
  // System/agent-level metrics (cpu_usage, memory_percent — collected via a
  // separate path this session's AnomalyFeed/normalization work never
  // touched) report a sentinel device identity rather than a real endpoint —
  // seen as "system-endpoint" and "Agent System" depending on call site; "startsWith"
  // rather than an exact match so any of these variants still resolve.
  if (idOrName.toLowerCase().startsWith('system')) return 'System'
  return endpointsByUuid.value.get(idOrName)
    ?? displayNameByRawName.value.get(idOrName)
    ?? idOrName
}

// Tag color for a baseline row's canonical device state (CanonicalDeviceState
// The metric's own device UUID segment: metrics are named
// "{agentUuid}_{deviceUuid}_{bare_metric}" — the LAST UUID segment is the
// device's own endpoint UUID (the first is the agent-wide UUID, constant
// across every metric and never a useful lookup key on its own). Only
// metricLeaf() below still needs this — live metrics no longer carry an
// embedded UUID (see deviceDisplayName()'s own comment), but this function
// otherwise only serves the hidden ("Noisy Metrics" / Bad Actors) table.
function extractDeviceUuid(metric: string): string | undefined {
  const uuidMatches = [...metric.matchAll(/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})_/gi)]
  return uuidMatches.at(-1)?.[1]
}

// Schema-drift-originated metrics carry the detector's internal
// "reading:"/"key:" namespace tag (see SchemaDriftDetector.extractSchema)
// instead of a UUID prefix — also used directly by the Schema Drift grid's
// own Field column, not just metricLeaf() below.
const DRIFT_FIELD_PREFIX_RE = /^(reading|key):/

// Used only by the hidden ("Noisy Metrics" / Bad Actors) table in the Rules
// tab (v-if="false" — "device/metric name resolution needs more work
// first"). Every other tab shows the metric name verbatim now (see
// deviceDisplayName() above) — this leaf-stripping/hyphenating heuristic
// predates that and is left as-is here since this table isn't user-visible.
function metricLeaf(metric: string, deviceName?: string): string {
  const driftStripped = metric.replace(DRIFT_FIELD_PREFIX_RE, '')
  if (driftStripped !== metric) {
    // BACnet (and possibly other protocols) build each reading's field name as
    // "{device}_{object}" before schema drift ever sees it — the device is
    // baked into the field, not tracked separately the way anomaly metrics
    // track it via a UUID key. Since Device already shows in its own column,
    // strip that same device base name from the front of the field here too.
    const deviceBase = deviceName?.replace(DRIFT_DEVICE_SUFFIX_RE, '').toLowerCase()
    if (deviceBase && deviceBase !== deviceName?.toLowerCase() && driftStripped.toLowerCase().startsWith(`${deviceBase}_`)) {
      return hyphenateField(driftStripped.slice(deviceBase.length + 1))
    }
    return hyphenateField(driftStripped)
  }

  const bare = friendlyLabel(metric)
  if (bare === metric) return bare // no UUID prefix — not a device-scoped metric (e.g. a system metric like cpu_usage): leave underscored, there's no device-point convention to match here

  const parts = bare.split('_')
  const leaf = parts.length > 2 ? parts.slice(-2).join('_') : bare

  // Prefer the true protocol-native point name (e.g. "Space-Temp") over the
  // sanitized leaf, when we have it on file for this exact device+point —
  // it's already in its authentic native format, don't reformat it further.
  const deviceUuid = extractDeviceUuid(metric)
  const rawName = deviceUuid ? pointRawNameByKey.value.get(`${deviceUuid}::${leaf}`) : undefined
  return rawName || hyphenateField(leaf)
}

async function loadBaselines() {
  baselinesLoading.value = true
  try {
    const filterText = baselinesMetric.value.trim().toLowerCase()
    const [r, progress, cfg] = await Promise.all([
      anomalyApi.getBaselines({ metric: baselinesMetric.value.trim() || undefined, limit: PAGE_SIZE }),
      // Only meaningful on page 1 — prepending in-progress rows to an arbitrary
      // later page would be confusing, so skip fetching/merging past page 1.
      baselinesPage.value === 1 ? anomalyApi.getBaselineProgress() : Promise.resolve([]),
      // Needed to list rules that haven't produced a single sample yet (see
      // notStartedRows below) — reuse the cached config if the Rules/Config tab
      // already loaded it, otherwise fetch it just for this.
      baselinesPage.value === 1 && !config.value ? anomalyApi.getConfig() : Promise.resolve(config.value),
      ensureEndpointMaps(),
    ])
    if (cfg) config.value = cfg

    const progressByKey = new Map(
      progress.map((p) => [`${p.metricName}::${p.deviceId}::${p.deviceState}`, p]),
    )

    // Metrics covered by source/protocol rules are shown only in the group
    // summary row + detail modal — hide them from the individual rows.
    const groupRules = (config.value?.metrics ?? []).filter(
      (m) => m.enabled && m.scope && m.scope !== 'point',
    )
    const groupRuleNames = new Set(groupRules.map((m) => m.name))
    const isGroupedMetric = (p: { configName?: string }) => p.configName && groupRuleNames.has(p.configName)
    const groupedMetricKeys = new Set(
      progress.filter((p) => isGroupedMetric(p)).map((p) => `${p.metricName}::${p.deviceId}::${p.deviceState}`),
    )

    // Device UUIDs covered by source-scoped group rules — stale DB baselines
    // from a previous config (before the group rule existed) carry a device_id
    // UUID that has no live progress entry, so groupedMetricKeys misses them.
    // Reverse-map sourcePattern → UUID via the endpoint/device name maps.
    const groupedDeviceUuids = new Set<string>()
    for (const rule of groupRules) {
      if (rule.scope === 'source' && rule.sourcePattern) {
        for (const [uuid, name] of endpointsByUuid.value) {
          if (name === rule.sourcePattern) groupedDeviceUuids.add(uuid)
        }
      }
    }

    const annotatedBaselines: BaselineRow[] = r.baselines
      .filter((b) => !groupedMetricKeys.has(`${b.metric}::${b.device_id}::${b.device_state}`))
      .filter((b) => !groupedDeviceUuids.has(b.device_id))
      .map((b) => {
        const key = `${b.metric}::${b.device_id}::${b.device_state}`
        const p = progressByKey.get(key)
        if (!p || p.bufferSize >= p.windowSize) return b
        return { ...b, sample_count: p.bufferSize, pendingWindowSize: p.windowSize }
      })

    const existingKeys = new Set(r.baselines.map((b) => `${b.metric}::${b.device_id}::${b.device_state}`))
    const pendingRows: BaselineRow[] = progress
      .filter((p) => !isGroupedMetric(p))
      // <= not < : once the buffer fills, it stays visible ("ready, waiting to
      // save") until a real baseline row appears and dedupes it away, rather
      // than vanishing for the gap between filling up and the next periodic save.
      .filter((p) => p.bufferSize <= p.windowSize)
      .filter((p) => !existingKeys.has(`${p.metricName}::${p.deviceId}::${p.deviceState}`))
      .filter((p) => !filterText || p.metricName.toLowerCase().includes(filterText))
      .map((p) => ({
        metric: p.metricName,
        device_id: p.deviceId,
        device_state: p.deviceState,
        time_slot: -1,
        mean: null,
        std_dev: null,
        median: null,
        mad: null,
        sample_count: p.bufferSize,
        calculated_at: 0,
        pendingWindowSize: p.windowSize,
        isSynthetic: true,
      }))

    const metricNamesWithData = new Set([
      ...r.baselines.map((b) => canonicalBareMetricName(b.metric)),
      ...progress.map((p) => canonicalBareMetricName(p.metricName)),
    ])

    // Point-scoped rules that haven't received data yet — synthetic placeholder rows.
    const notStartedRows: BaselineRow[] = (config.value?.metrics ?? [])
      .filter((m) => m.enabled && (!m.scope || m.scope === 'point'))
      .filter((m) => !metricNamesWithData.has(m.name))
      .filter((m) => !filterText || m.name.toLowerCase().includes(filterText))
      .map((m) => ({
        metric: m.name,
        device_id: m.deviceName ?? '',
        device_state: 'unknown',
        time_slot: -1,
        mean: null,
        std_dev: null,
        median: null,
        mad: null,
        sample_count: 0,
        calculated_at: 0,
        pendingWindowSize: m.windowSize,
        isSynthetic: true,
      }))

    // Source/protocol-scoped rules — one summary row per rule, aggregating
    // all individual metric buffers matched by that rule via configName.
    latestGroupProgress.value = progress
    const groupRows: BaselineRow[] = groupRules
      .filter((m) => !filterText || m.name.toLowerCase().includes(filterText))
      .map((m) => {
        const matched = progress.filter((p) => p.configName === m.name)
        const readyCount = matched.filter((p) => p.bufferSize >= p.windowSize).length
        const totalCount = matched.length
        const allReady = totalCount > 0 && readyCount === totalCount
        return {
          metric: m.name,
          device_id: m.scope === 'source' ? (m.sourcePattern ?? '') : '',
          device_state: m.scope === 'protocol' ? (m.protocolPattern ?? '') : '',
          time_slot: -1,
          mean: null,
          std_dev: null,
          median: null,
          mad: null,
          sample_count: readyCount,
          calculated_at: 0,
          pendingWindowSize: allReady ? undefined : m.windowSize,
          isSynthetic: true,
          isGroupRule: true,
          groupMetricCount: totalCount,
          groupReadyCount: readyCount,
        }
      })

    baselines.value = [...notStartedRows, ...groupRows, ...pendingRows, ...annotatedBaselines]
    baselinesTotal.value = r.total + pendingRows.length + notStartedRows.length + groupRows.length
  } catch { /* non-fatal */ } finally {
    baselinesLoading.value = false
  }
}

const clearingBaselines = ref(false)
const resetBaselinesModalOpen = ref(false)

async function clearAllBaselines() {
  clearingBaselines.value = true
  try {
    const { deleted } = await anomalyApi.clearBaselines()
    message.success(`Cleared ${deleted} baseline${deleted !== 1 ? 's' : ''}`)
    baselines.value = []
    baselinesTotal.value = 0
    resetBaselinesModalOpen.value = false
  } catch (err: unknown) {
    message.error((err as { message?: string })?.message ?? 'Clear failed')
  } finally {
    clearingBaselines.value = false
  }
}

// ── Schema Drift tab ─────────────────────────────────────────────────────────
// ── Schema Drift Rules ────────────────────────────────────────────────────────
const driftRules = ref<DriftRuleConfig[]>([])
const driftRulesLoading = ref(false)
const driftRuleDrawerOpen = ref(false)
const editingDriftRule = ref<DriftRuleConfig | null>(null)
const driftRulePrefill = ref<{ fieldPattern?: string; devicePattern?: string; endpointPattern?: string } | undefined>(undefined)

async function loadDriftRules() {
  driftRulesLoading.value = true
  try {
    driftRules.value = await driftRulesApi.getRules()
  } catch { /* silent */ } finally {
    driftRulesLoading.value = false
  }
}

function openNewDriftRule(prefill?: { fieldPattern?: string; devicePattern?: string; endpointPattern?: string }) {
  editingDriftRule.value = null
  driftRulePrefill.value = prefill
  driftRuleDrawerOpen.value = true
}

function editDriftRule(rule: DriftRuleConfig) {
  editingDriftRule.value = rule
  driftRulePrefill.value = undefined
  driftRuleDrawerOpen.value = true
}

async function deleteDriftRule(rule: DriftRuleConfig) {
  if (!rule.id) return
  try {
    await driftRulesApi.deleteRule(rule.id)
    message.success('Rule deleted')
    loadDriftRules()
  } catch (err: any) {
    message.error(err?.message ?? 'Delete failed')
  }
}

function driftRuleScopeLabel(rule: DriftRuleConfig): string {
  const hasDev = !!rule.devicePattern
  const hasEp = !!rule.endpointPattern
  const hasField = !!rule.fieldPattern

  if (hasDev && rule.devicePattern === '*' && !hasEp && !hasField) return 'All devices'

  if (hasDev && rule.devicePattern !== '*' && !hasEp) return rule.devicePattern!

  if (hasEp && !hasDev) {
    const m = rule.endpointPattern!.match(/^\*(\w+)\*$/)
    if (m && m[1] in PROTOCOL_LABELS) return protocolLabel(m[1])
  }

  const parts: string[] = []
  if (hasField) parts.push(`field: ${rule.fieldPattern}`)
  if (hasDev) parts.push(`device: ${rule.devicePattern}`)
  if (hasEp) parts.push(`endpoint: ${rule.endpointPattern}`)
  return parts.join(', ') || '—'
}

function driftRuleSeverityLabel(rule: DriftRuleConfig): string {
  if (!rule.severityOverrides) return '—'
  const vals = [...new Set(Object.values(rule.severityOverrides))]
  if (vals.length === 0) return '—'
  if (vals.length === 1) return vals[0].charAt(0).toUpperCase() + vals[0].slice(1)
  return 'Mixed'
}

function driftRuleDriftTypeTags(rule: DriftRuleConfig): Array<{ label: string; color: string }> {
  const types = [...new Set([...(rule.alertOnDriftTypes ?? []), ...(rule.suppressDriftTypes ?? [])])]
  return types.map(t => ({ label: DRIFT_TYPE_LABELS[t] ?? t, color: DRIFT_TYPE_TAG_COLORS[t] ?? 'default' }))
}

async function toggleDriftRuleEnabled(rule: DriftRuleConfig) {
  if (!rule.id) return
  try {
    await driftRulesApi.updateRule(rule.id, { enabled: !rule.enabled })
    rule.enabled = !rule.enabled
  } catch (err: any) {
    message.error(err?.message ?? 'Failed to toggle rule')
  }
}

const driftRuleColumns: TableColumnType<DriftRuleConfig>[] = [
  { title: 'Rule name', dataIndex: 'name', key: 'name', ellipsis: true, sorter: (a: DriftRuleConfig, b: DriftRuleConfig) => (a.name ?? '').localeCompare(b.name ?? '') },
  { title: 'Applies to', key: 'scope', width: 160, ellipsis: true },
  { title: 'Detection Type', key: 'driftType' },
  { title: 'Severity', key: 'severity', width: 100, sorter: (a: DriftRuleConfig, b: DriftRuleConfig) => driftRuleSeverityLabel(a).localeCompare(driftRuleSeverityLabel(b)) },
  { title: 'Enabled', key: 'enabled', width: 80, sorter: (a: DriftRuleConfig, b: DriftRuleConfig) => Number(a.enabled) - Number(b.enabled) },
  { title: '', key: 'actions', width: 100, align: 'right' as const },
]

// ── Config tab ─────────────────────────────────────────────────────────────────
const config = ref<AnomalyConfig | null>(null)
const configLoading = ref(false)
const configSaving = ref(false)

const metricDrawerOpen = ref(false)
const editingMetricIdx = ref<number | null>(null)
const metricForm = ref<AnomalyMetricConfig>(blankMetric())
const expectedMin = ref<number | null>(null)
const expectedMax = ref<number | null>(null)
const pointPickerOpen = ref(false)
const selectedPointLabel = ref('')
const selectedSourceLabel = ref('')

const scopeMode = ref<MetricScope>('point')
const selectedSource = ref<string | undefined>(undefined)
const selectedProtocol = ref<string | undefined>(undefined)

const scopeDevices = ref<Array<{ name: string; protocol: string }>>([])
const scopeDevicesLoaded = ref(false)

async function ensureScopeDevices() {
  if (scopeDevicesLoaded.value) return
  try {
    const { data } = await apiClient.get<{ sourceDevices?: Array<{ name: string; protocol: string }> }>('/v1/anomaly/points')
    scopeDevices.value = data.sourceDevices ?? []
    scopeDevicesLoaded.value = true
  } catch { /* non-fatal */ }
}

const uniqueSources = computed(() => scopeDevices.value)

const uniqueProtocols = computed(() => {
  const set = new Set<string>()
  for (const d of scopeDevices.value) {
    if (d.protocol) set.add(d.protocol.toLowerCase())
  }
  return [...set].sort()
})

function filterSourceOption(input: string, option: { label?: string }): boolean {
  return (option?.label ?? '').toLowerCase().includes(input.toLowerCase())
}

function onPointSelected(point: PointCatalogEntry, deviceName: string) {
	metricForm.value.name = point.normalizedName
	metricForm.value.deviceName = deviceName
	selectedPointLabel.value = point.normalizedName
	selectedSourceLabel.value = deviceName
}

// expected_range is a no-op detector without bounds — surface that before save, not just on submit.
const expectedRangeMissingBounds = computed(() =>
  metricForm.value.methods.includes('expected_range')
  && (expectedMin.value == null || expectedMax.value == null),
)

// ── Rule templates (built-in presets + custom saved templates) ─────────────────
const templateLibraryOpen = ref(false)
const customTemplates = ref<AnomalyRuleTemplate[]>([])
const customTemplatesLoaded = ref(false)
const templatesLoading = ref(false)
const templateSearch = ref('')
const saveTemplateModalOpen = ref(false)
const saveTemplateName = ref('')
const saveTemplateSaving = ref(false)

type TemplateListItem =
  | (BuiltinAnomalyTemplate & { builtin: true })
  | (AnomalyRuleTemplate & { builtin: false; category: 'My templates' })

async function loadTemplates() {
  templatesLoading.value = true
  try {
    customTemplates.value = await anomalyApi.getTemplates()
    customTemplatesLoaded.value = true
  } catch {
    // non-fatal
  } finally {
    templatesLoading.value = false
  }
}

const templateLibrary = computed<TemplateListItem[]>(() => {
  const builtins: TemplateListItem[] = BUILTIN_ANOMALY_TEMPLATES.map((t) => ({ ...t, builtin: true }))
  const custom: TemplateListItem[] = customTemplates.value.map((t) => ({
    ...t,
    builtin: false,
    category: 'My templates',
  }))
  return [...custom, ...builtins]
})

const templatesByCategory = computed(() => {
  const q = templateSearch.value.trim().toLowerCase()
  const filtered = q
    ? templateLibrary.value.filter((t) =>
        t.name.toLowerCase().includes(q) || (t.purpose ?? '').toLowerCase().includes(q),
      )
    : templateLibrary.value

  const groups = new Map<string, TemplateListItem[]>()
  for (const t of filtered) {
    const key = t.category ?? 'Other'
    if (!groups.has(key)) groups.set(key, [])
    groups.get(key)!.push(t)
  }
  return groups
})

function openTemplateLibrary() {
  templateSearch.value = ''
  templateLibraryOpen.value = true
  if (!customTemplatesLoaded.value) loadTemplates()
}

function applyTemplate(template: TemplateListItem) {
  metricForm.value.methods = [...template.methods]
  metricForm.value.threshold = template.threshold

  if (template.builtin) {
    metricForm.value.windowSize = template.windowSize
    metricForm.value.minConfidence = template.minConfidence
    metricForm.value.cooldownMs = template.cooldownMs
    metricForm.value.seasonality = template.seasonality
    expectedMin.value = null
    expectedMax.value = null
  } else {
    metricForm.value.windowSize = template.window_size
    metricForm.value.minConfidence = template.min_confidence ?? 0.7
    metricForm.value.cooldownMs = template.cooldown_ms ?? 300_000
    metricForm.value.seasonality = template.seasonality ?? 'none'
    expectedMin.value = template.expected_range?.[0] ?? null
    expectedMax.value = template.expected_range?.[1] ?? null
    if (expectedMin.value != null && expectedMax.value != null && !metricForm.value.methods.includes('expected_range')) {
      metricForm.value.methods.push('expected_range')
    }
  }

  templateLibraryOpen.value = false
  message.success(`Applied template "${template.name}"`)
}

function openSaveTemplateModal() {
  saveTemplateName.value = ''
  saveTemplateModalOpen.value = true
}

async function saveAsTemplate() {
  if (!saveTemplateName.value.trim()) {
    message.error('Template name is required')
    return
  }
  saveTemplateSaving.value = true
  try {
    await anomalyApi.createTemplate({
      name: saveTemplateName.value.trim(),
      category: null,
      purpose: null,
      methods: metricForm.value.methods,
      threshold: metricForm.value.threshold,
      window_size: metricForm.value.windowSize,
      min_confidence: metricForm.value.minConfidence ?? null,
      cooldown_ms: metricForm.value.cooldownMs ?? null,
      seasonality: metricForm.value.seasonality ?? null,
      expected_range: expectedMin.value != null && expectedMax.value != null
        ? [expectedMin.value, expectedMax.value]
        : null,
    })
    message.success('Template saved')
    saveTemplateModalOpen.value = false
    customTemplatesLoaded.value = false
    await loadTemplates()
  } catch (err: unknown) {
    message.error((err as { message?: string })?.message ?? 'Failed to save template')
  } finally {
    saveTemplateSaving.value = false
  }
}

async function deleteTemplate(uuid: string) {
  try {
    await anomalyApi.deleteTemplate(uuid)
    message.success('Template deleted')
    customTemplatesLoaded.value = false
    await loadTemplates()
  } catch (err: unknown) {
    message.error((err as { message?: string })?.message ?? 'Failed to delete template')
  }
}

const SEASONALITY_OPTIONS = ['none', 'day-night', 'hourly', 'weekly']

const DETECTION_CATEGORIES = [
  {
    key: 'unusual',
    title: 'Unusual Values',
    description: 'Detect readings that are unusually high or low compared to normal behavior.',
    defaultMethod: 'mad' as DetectionMethod,
    methods: ['mad', 'zscore', 'iqr'] as DetectionMethod[],
  },
  {
    key: 'sudden',
    title: 'Sudden Changes',
    description: 'Detect unexpected rapid increases or decreases in sensor readings.',
    defaultMethod: 'rate_change' as DetectionMethod,
    methods: ['rate_change'] as DetectionMethod[],
  },
  {
    key: 'gradual',
    title: 'Gradual Changes',
    description: 'Detect slow drift or sustained changes in sensor behavior over time.',
    defaultMethod: 'ewma' as DetectionMethod,
    methods: ['ewma', 'cusum'] as DetectionMethod[],
  },
  {
    key: 'limits',
    title: 'Operating Limits',
    description: 'Alert immediately when a reading falls outside a fixed min/max range.',
    defaultMethod: 'expected_range' as DetectionMethod,
    methods: ['expected_range'] as DetectionMethod[],
  },
]

const activeCategories = computed(() => {
  const active = new Set<string>()
  for (const cat of DETECTION_CATEGORIES) {
    if (cat.methods.some(m => metricForm.value.methods.includes(m)))
      active.add(cat.key)
  }
  return active
})

function toggleCategory(cat: typeof DETECTION_CATEGORIES[number]) {
  if (activeCategories.value.has(cat.key)) {
    metricForm.value.methods = metricForm.value.methods.filter(
      m => !(cat.methods as DetectionMethod[]).includes(m)
    )
    if (cat.key === 'limits') {
      expectedMin.value = null
      expectedMax.value = null
    }
  } else {
    metricForm.value.methods.push(cat.defaultMethod)
  }
}

const hasLegacyFusion = computed(() => metricForm.value.methods.includes('fusion'))

function methodCategoryLabel(method: DetectionMethod): string {
  for (const cat of DETECTION_CATEGORIES) {
    if ((cat.methods as DetectionMethod[]).includes(method)) return cat.title
  }
  if (method === 'expected_range') return 'Operating Limits'
  if (method === 'fusion') return 'Fusion (legacy)'
  return method
}

function uniqueCategoryLabels(methods: DetectionMethod[]): string[] {
  const seen = new Set<string>()
  const labels: string[] = []
  for (const m of methods) {
    const label = methodCategoryLabel(m)
    if (!seen.has(label)) { seen.add(label); labels.push(label) }
  }
  return labels
}

function ruleDetectionLabels(record: AnomalyMetricConfig): string[] {
  const labels = uniqueCategoryLabels(record.methods)
  if (record.expectedRange && !labels.includes('Operating Limits')) {
    labels.unshift('Operating Limits')
  }
  return labels
}

const CATEGORY_COLORS: Record<string, string> = {
  'Unusual Values': 'purple',
  'Sudden Changes': 'gold',
  'Gradual Changes': 'cyan',
  'Operating Limits': 'volcano',
  'Fusion (legacy)': 'magenta',
}

function categoryLabelColor(label: string): string {
  return CATEGORY_COLORS[label] ?? 'default'
}

type SensitivityLevel = 'low' | 'medium' | 'high'

const SENSITIVITY_THRESHOLDS: Record<string, Record<SensitivityLevel, number>> = {
  mad:         { low: 4.0, medium: 3.0, high: 2.0 },
  zscore:      { low: 4.0, medium: 3.0, high: 2.0 },
  iqr:         { low: 2.5, medium: 1.5, high: 1.0 },
  rate_change: { low: 25.0, medium: 10.0, high: 5.0 },
  ewma:        { low: 3.0, medium: 2.0, high: 1.5 },
  cusum:       { low: 8.0, medium: 5.0, high: 3.0 },
}

const primaryMethod = computed(() => {
  for (const cat of DETECTION_CATEGORIES) {
    if (cat.key === 'limits') continue
    if (activeCategories.value.has(cat.key)) return cat.defaultMethod
  }
  return 'mad' as DetectionMethod
})

const currentSensitivity = computed((): SensitivityLevel | 'custom' => {
  const mapping = SENSITIVITY_THRESHOLDS[primaryMethod.value]
  if (!mapping) return 'custom'
  for (const [level, val] of Object.entries(mapping)) {
    if (metricForm.value.threshold === val) return level as SensitivityLevel
  }
  return 'custom'
})

function setSensitivity(level: SensitivityLevel) {
  const mapping = SENSITIVITY_THRESHOLDS[primaryMethod.value]
  if (mapping) metricForm.value.threshold = mapping[level]
}

function tableSensitivityLabel(record: AnomalyMetricConfig): string {
  for (const cat of DETECTION_CATEGORIES) {
    if (cat.methods.some(m => record.methods.includes(m))) {
      const mapping = SENSITIVITY_THRESHOLDS[cat.defaultMethod]
      if (mapping) {
        for (const [level, val] of Object.entries(mapping)) {
          if (record.threshold === val) return level.charAt(0).toUpperCase() + level.slice(1)
        }
      }
      break
    }
  }
  return 'Custom'
}

const confidencePercent = computed({
  get: () => Math.round((metricForm.value.minConfidence ?? 0.7) * 100),
  set: (v: number) => { metricForm.value.minConfidence = v / 100 },
})

const cooldownMinutes = computed({
  get: () => Math.round((metricForm.value.cooldownMs ?? 300000) / 60000),
  set: (v: number) => { metricForm.value.cooldownMs = v * 60000 },
})

const advancedOpen = ref<string[]>([])

const selectedMethodCount = computed(() => metricForm.value.methods.length)
const hasStatisticalDetector = computed(() =>
  DETECTION_CATEGORIES.some(cat => cat.key !== 'limits' && activeCategories.value.has(cat.key))
)


// ── Available metric suggestions ───────────────────────────────────────────
// Strip all leading UUID prefixes from canonical metric names so they display readably.
// e.g. "UUID1_UUID2_pioneer_gold_1_coil_temp" → "pioneer_gold_1_coil_temp"
const UUID_PREFIX_RE = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}_/gi
function friendlyLabel(name: string | undefined | null): string {
  if (!name) return ''
  return name.replace(UUID_PREFIX_RE, '')
}

// Mirrors selectMetricConfig()'s fallback matching in the backend's metric-router.ts:
// a system metric's canonical key is "{agentUuid}_system_{name}" (e.g.
// "UUID_system_memory_percent"), a distinct pattern from the plain
// "{agentUuid}_{endpointUuid}_{name}" case friendlyLabel() already handles — it has an
// extra "system_" segment friendlyLabel leaves behind. Used only for matching a rule's
// bare config name against real baseline/progress keys (not for display — friendlyLabel
// stays the display-facing one), or a system-scoped rule's placeholder never dedupes
// away once real data exists, the same way ahu_1_rf_speed's rule name once didn't.
function canonicalBareMetricName(name: string): string {
  const systemMatch = name.match(/^[0-9a-f-]{36}_system_(.+)$/i)
  if (systemMatch) return systemMatch[1]
  return friendlyLabel(name)
}

function blankMetric(): AnomalyMetricConfig {
  return {
    name: '',
    enabled: true,
    methods: ['mad'],
    threshold: 3.0,
    windowSize: 120,
    minConfidence: 0.7,
    cooldownMs: 300_000,
    seasonality: 'none',
    scope: 'point',
  }
}

const metricColumns: TableColumnType<AnomalyMetricConfig>[] = [
  { title: 'Point name', key: 'name', ellipsis: true, sorter: (a: AnomalyMetricConfig, b: AnomalyMetricConfig) => a.name.localeCompare(b.name) },
  { title: 'Applies to', key: 'scope', width: 180, ellipsis: true, sorter: (a: AnomalyMetricConfig, b: AnomalyMetricConfig) => ruleScopeLabel(a).localeCompare(ruleScopeLabel(b)) },
  { title: 'Detection Type', key: 'methods', ellipsis: true },
  { title: 'Sensitivity', key: 'sensitivity', width: 100, sorter: (a: AnomalyMetricConfig, b: AnomalyMetricConfig) => a.threshold - b.threshold },
  { title: 'Seasonality', key: 'seasonality', width: 110, sorter: (a: AnomalyMetricConfig, b: AnomalyMetricConfig) => (a.seasonality ?? '').localeCompare(b.seasonality ?? '') },
  { title: 'Enabled', key: 'enabled', width: 80, sorter: (a: AnomalyMetricConfig, b: AnomalyMetricConfig) => Number(a.enabled) - Number(b.enabled) },
  { title: '', key: 'actions', width: 100, fixed: 'right' },
]

async function loadConfig() {
  configLoading.value = true
  try {
    config.value = await anomalyApi.getConfig()
  } catch {
    // non-fatal
  } finally {
    configLoading.value = false
  }
}

async function saveConfig() {
  if (!config.value) return
  configSaving.value = true
  try {
    config.value = await anomalyApi.updateConfig(config.value)
    message.success('Configuration saved')
  } catch (err: unknown) {
    const e = err as { message?: string }
    message.error(e?.message ?? 'Save failed')
  } finally {
    configSaving.value = false
  }
}

function openAddMetric() {
  editingMetricIdx.value = null
  metricForm.value = blankMetric()
  expectedMin.value = null
  expectedMax.value = null
  advancedOpen.value = []
  selectedPointLabel.value = ''
  selectedSourceLabel.value = ''
  scopeMode.value = 'point'
  selectedSource.value = undefined
  selectedProtocol.value = undefined
  metricDrawerOpen.value = true
  ensureScopeDevices()
}

function openEditMetric(metric: AnomalyMetricConfig, idx: number) {
  editingMetricIdx.value = idx
  const methods = [...metric.methods]
  if (metric.expectedRange && !methods.includes('expected_range')) {
    methods.push('expected_range')
  }
  metricForm.value = { ...metric, name: friendlyLabel(metric.name), methods }
  expectedMin.value = metric.expectedRange?.[0] ?? null
  expectedMax.value = metric.expectedRange?.[1] ?? null
  scopeMode.value = metric.scope ?? 'point'
  selectedSource.value = metric.sourcePattern
  selectedProtocol.value = metric.protocolPattern
  if (metric.scope === 'source') {
    selectedPointLabel.value = ''
    selectedSourceLabel.value = ''
  } else if (metric.scope === 'protocol') {
    selectedPointLabel.value = ''
    selectedSourceLabel.value = ''
  } else {
    selectedPointLabel.value = friendlyLabel(metric.name)
    selectedSourceLabel.value = metric.deviceName ?? ''
  }
  const pm = DETECTION_CATEGORIES.find(c => c.methods.some(m => metric.methods.includes(m)))?.defaultMethod ?? 'mad'
  const mapping = SENSITIVITY_THRESHOLDS[pm]
  const isCustom = !mapping || !Object.values(mapping).includes(metric.threshold)
  advancedOpen.value = isCustom ? ['advanced'] : []
  metricDrawerOpen.value = true
  ensureScopeDevices()
}

async function saveMetric() {
  if (!config.value) return

  if (scopeMode.value === 'point') {
    if (!metricForm.value.name.trim()) {
      message.error('Point is required — use the picker to select one')
      return
    }
  } else if (scopeMode.value === 'source') {
    if (!selectedSource.value) {
      message.error('Select a source endpoint')
      return
    }
  } else if (scopeMode.value === 'protocol') {
    if (!selectedProtocol.value) {
      message.error('Select a protocol')
      return
    }
  }

  if (metricForm.value.methods.length === 0) {
    message.error('Select at least one detection method')
    return
  }
  if (metricForm.value.methods.includes('expected_range')) {
    if (expectedMin.value == null || expectedMax.value == null) {
      message.error('Operating Limits requires both min and max bounds')
      return
    }
    if (expectedMin.value >= expectedMax.value) {
      message.error('Operating Limits min must be less than max')
      return
    }
  }
  const entry: AnomalyMetricConfig = {
    ...metricForm.value,
    scope: scopeMode.value,
    expectedRange:
      expectedMin.value != null && expectedMax.value != null
        ? [expectedMin.value, expectedMax.value]
        : undefined,
  }
  if (scopeMode.value === 'source') {
    entry.name = entry.name || `All points from ${selectedSource.value}`
    entry.sourcePattern = selectedSource.value
    entry.protocolPattern = undefined
    entry.deviceName = undefined
  } else if (scopeMode.value === 'protocol') {
    entry.name = entry.name || `All ${protocolLabel(selectedProtocol.value!)} points`
    entry.protocolPattern = selectedProtocol.value
    entry.sourcePattern = undefined
    entry.deviceName = undefined
  } else {
    entry.sourcePattern = undefined
    entry.protocolPattern = undefined
  }
  if (editingMetricIdx.value !== null) {
    config.value.metrics[editingMetricIdx.value] = entry
  } else {
    config.value.metrics.push(entry)
  }
  metricDrawerOpen.value = false
  await saveConfig()
}

async function removeMetric(idx: number) {
  if (!config.value) return
  config.value.metrics.splice(idx, 1)
  await saveConfig()
}

async function toggleMetricEnabled(idx: number) {
  if (!config.value) return
  config.value.metrics[idx].enabled = !config.value.metrics[idx].enabled
  await saveConfig()
}

// ── Bad actors (ISA-18.2-style ranking of noisiest metrics by incident frequency) ──
const badActors = ref<BadActor[]>([])
const badActorsLoading = ref(false)
const badActorsWindowDays = ref(30)

// null = no classified resolutions yet to compute a rate from (distinct from a genuine 0%)
function fpRate(record: BadActor): number | null {
  const classified = record.false_positive_count + record.true_positive_count + record.expected_count + record.accepted_count
  if (classified === 0) return null
  return Math.round((record.false_positive_count / classified) * 100)
}

async function loadBadActors() {
  badActorsLoading.value = true
  try {
    const result = await anomalyApi.getBadActors({ windowDays: badActorsWindowDays.value, limit: 20 })
    badActors.value = result.badActors
  } catch {
    // non-fatal
  } finally {
    badActorsLoading.value = false
  }
}

// ── Tab switching ──────────────────────────────────────────────────────────────
function onTabChange(tab: string) {
  activeTab.value = tab
  stopTabAutoRefresh()
  if (tab === 'events') { loadEdgeEvents(); startTabAutoRefresh(loadEdgeEvents, edgeEventsLoading) }
  else if (tab === 'incidents') { loadEdgeIncidents(); startTabAutoRefresh(loadEdgeIncidents, edgeIncidentsLoading) }
  else if (tab === 'alerts') { loadEdgeAlerts(); startTabAutoRefresh(loadEdgeAlerts, edgeAlertsLoading) }
  else if (tab === 'baselines') { loadBaselines(); startTabAutoRefresh(loadBaselines, baselinesLoading) }
  else if (tab === 'schema-drift') { loadDriftRules() }
  else if (tab === 'rules') { loadConfig(); loadBadActors(); ensureEndpointMaps() }
}

onMounted(() => {
  ensureEndpointMaps()
  loadEdgeIncidents()
  startTabAutoRefresh(loadEdgeIncidents, edgeIncidentsLoading)
})
// proInstalled is fetched asynchronously by AppLayout and may not have resolved
// yet when this view mounts (e.g. a direct page load on the Anomalies tab) — a
// one-shot `if (proInstalled.value)` check here can run before that fetch lands
// and never fire again. Watch instead so warmup status loads as soon as the
// pro-installed flag actually becomes true, whenever that happens.
watch(proInstalled, (installed) => {
  if (installed) loadWarmupStatus()
}, { immediate: true })
onUnmounted(() => {
  stopTabAutoRefresh()
  stopWarmupCountdown()
})
</script>

<template>
  <AppLayout title="Analytics">
    <div class="heading">
      <p>On-device anomaly detection, incident tracking, and baseline management.</p>
    </div>

    <a-alert v-if="!proInstalled" type="info" show-icon style="margin-bottom: 16px">
      <template #message>Catch anomalies before they become failures</template>
      <template #description>
        <div style="margin-top: 4px">
          An active license enables on-device ML anomaly detection — baseline tracking,
          per-metric alert rules, and trend forecasting that runs entirely on the device with no cloud
          round-trip required. Get notified the moment a sensor drifts outside its normal range.
        </div>
        <div style="margin-top: 12px">
          <a-button
            type="primary"
            size="small"
            href="https://iotistica.com/solutions.html"
            target="_blank"
            rel="noopener"
          >Activate License →</a-button>
          <a
            href="https://iotistica.com/solutions.html"
            target="_blank"
            rel="noopener"
            style="margin-left: 16px; font-size: 12px"
          >Compare plans</a>
        </div>
      </template>
    </a-alert>
    <a-tabs :active-key="activeTab" @change="onTabChange">

      <!-- ══ EVENTS ═════════════════════════════════════════════════════════ -->
      <a-tab-pane key="events" tab="Events">
        <a-card size="small" class="list-card">
        <div class="toolbar-info" style="display: flex; justify-content: space-between; align-items: center">
          <span>{{ edgeEventsTotal }} total · auto-refresh 5s</span>
        </div>
        <div class="filters" style="margin-bottom: 8px">
          <a-select
            v-model:value="edgeEventsSeverity"
            placeholder="All severities"
            allow-clear
            class="filter"
            @change="() => { edgeEventsPage = 1; loadEdgeEvents() }"
          >
            <a-select-option value="critical">Critical</a-select-option>
            <a-select-option value="warning">Warning</a-select-option>
            <a-select-option value="info">Info</a-select-option>
          </a-select>
        </div>
        <a-table
          :columns="edgeEventColumns"
          :data-source="edgeEvents"
          :loading="edgeEventsLoading && edgeEvents.length === 0"
          :pagination="{ current: edgeEventsPage, pageSize: PAGE_SIZE, total: edgeEventsTotal, showSizeChanger: false, onChange: (p: number) => { edgeEventsPage = p; loadEdgeEvents() } }"
          row-key="id"
          size="small"
          :scroll="{ x: true }"
        >
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'severity'">
              <a-tag :color="SEVERITY_TAG_COLOR[record.severity]" :class="record.severity === 'critical' && record.status !== 'resolved' ? 'severity-critical' : ''" style="margin: 0">{{ record.severity }}</a-tag>
            </template>
            <template v-else-if="column.key === 'metric'">
              <span :title="record.metric">{{ friendlyLabel(record.metric) }}</span>
            </template>
            <template v-else-if="column.key === 'device_name'">
              {{ deviceDisplayName(record.device_name) }}
            </template>
            <template v-else-if="column.key === 'value'">
              <span style="font-variant-numeric: tabular-nums">{{ fmtNum(record.observed_value, 3) }}</span>
            </template>
            <template v-else-if="column.key === 'score'">
              <span style="font-variant-numeric: tabular-nums">{{ fmtNum(record.anomaly_score, 3) }}</span>
            </template>
            <template v-else-if="column.key === 'conf'">
              {{ Math.round(record.confidence * 100) }}%
            </template>
            <template v-else-if="column.key === 'consec'">
              <span style="color: var(--text-tertiary)">{{ record.consecutive_count }}×</span>
            </template>
            <template v-else-if="column.key === 'time'">
              <span style="color: var(--text-tertiary)">{{ fmtTs(record.timestamp_ms) }}</span>
            </template>
          </template>
          <template #emptyText>
            <div style="padding: 24px 0; text-align: center; color: var(--text-muted); font-size: 13px">
              No anomaly events yet. Events are recorded when the anomaly detection engine triggers.
            </div>
          </template>
        </a-table>
        </a-card>
      </a-tab-pane>

      <!-- ══ INCIDENTS ══════════════════════════════════════════════════════ -->
      <a-tab-pane key="incidents" tab="Incidents">
        <a-card size="small" class="list-card">
        <div class="toolbar-info" style="display: flex; justify-content: space-between; align-items: center">
          <span>{{ edgeIncidentsTotal }} total · auto-refresh 5s</span>
        </div>
        <div class="filters" style="margin-bottom: 8px">
          <a-select
            v-model:value="edgeIncidentsStatus"
            placeholder="All statuses"
            allow-clear
            class="filter"
            @change="() => { edgeIncidentsPage = 1; loadEdgeIncidents() }"
          >
            <a-select-option value="open">Open</a-select-option>
            <a-select-option value="active">Active</a-select-option>
            <a-select-option value="resolved">Resolved</a-select-option>
          </a-select>
        </div>
        <a-table
          :columns="edgeIncidentColumns"
          :data-source="edgeIncidents"
          :loading="edgeIncidentsLoading && edgeIncidents.length === 0"
          :pagination="{ current: edgeIncidentsPage, pageSize: PAGE_SIZE, total: edgeIncidentsTotal, showSizeChanger: false, onChange: (p: number) => { edgeIncidentsPage = p; loadEdgeIncidents() } }"
          row-key="incident_id"
          size="small"
          :scroll="{ x: true }"
        >
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'severity'">
              <a-tag :color="SEVERITY_TAG_COLOR[record.severity]" :class="record.severity === 'critical' && record.status !== 'resolved' ? 'severity-critical' : ''" style="margin: 0">{{ record.severity }}</a-tag>
            </template>
            <template v-else-if="column.key === 'metric'">
              <span :title="record.metric">{{ friendlyLabel(record.metric) }}</span>
            </template>
            <template v-else-if="column.key === 'device_name'">
              {{ deviceDisplayName(record.device_name) }}
            </template>
            <template v-else-if="column.key === 'status'">
              <a-tag :color="INCIDENT_STATUS_COLOR[record.status]" style="margin: 0">{{ record.status }}</a-tag>
            </template>
            <template v-else-if="column.key === 'score'">
              <span style="font-variant-numeric: tabular-nums">{{ fmtNum(record.max_anomaly_score, 3) }}</span>
            </template>
            <template v-else-if="column.key === 'first_seen'">
              <span style="color: var(--text-tertiary)">{{ fmtTs(record.first_seen) }}</span>
            </template>
            <template v-else-if="column.key === 'last_seen'">
              <span style="color: var(--text-tertiary)">{{ fmtTs(record.last_seen) }}</span>
            </template>
            <template v-else-if="column.key === 'actions'">
              <a-button
                v-if="record.status !== 'resolved'"
                size="small"
                :loading="resolvingId === record.incident_id"
                @click="openResolveModal(record)"
              >Resolve</a-button>
              <span v-else style="color: var(--text-tertiary)">—</span>
            </template>
          </template>
          <template #emptyText>
            <div style="padding: 24px 0; text-align: center; color: var(--text-muted); font-size: 13px">
              No incidents yet. Incidents are created when multiple anomaly events share the same fingerprint.
            </div>
          </template>
        </a-table>
        </a-card>
      </a-tab-pane>

      <!-- ══ ALERTS (edge) ══════════════════════════════════════════════════ -->
      <a-tab-pane key="alerts" tab="Alerts">
        <a-card size="small" class="list-card">
        <div class="toolbar-info" style="display: flex; justify-content: space-between; align-items: center">
          <span>{{ edgeAlertsTotal }} total · auto-refresh 5s</span>
        </div>
        <a-table
          :columns="edgeAlertColumns"
          :data-source="edgeAlerts"
          :loading="edgeAlertsLoading && edgeAlerts.length === 0"
          :pagination="{ current: edgeAlertsPage, pageSize: PAGE_SIZE, total: edgeAlertsTotal, showSizeChanger: false, onChange: (p: number) => { edgeAlertsPage = p; loadEdgeAlerts() } }"
          row-key="alert_id"
          size="small"
          :scroll="{ x: true }"
        >
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'severity'">
              <a-tag :color="SEVERITY_TAG_COLOR[record.severity]" :class="record.severity === 'critical' && record.status !== 'resolved' ? 'severity-critical' : ''" style="margin: 0">{{ record.severity }}</a-tag>
            </template>
            <template v-else-if="column.key === 'metric'">
              <span :title="record.metric">{{ friendlyLabel(record.metric) }}</span>
            </template>
            <template v-else-if="column.key === 'device_name'">
              {{ deviceDisplayName(record.device_name) }}
            </template>
            <template v-else-if="column.key === 'score'">
              <span style="font-variant-numeric: tabular-nums">{{ fmtNum(record.max_anomaly_score, 3) }}</span>
            </template>
            <template v-else-if="column.key === 'message'">
              <span :title="record.message" style="white-space: normal; word-break: break-word">{{ stripGuids(record.message) }}</span>
            </template>
            <template v-else-if="column.key === 'time'">
              <span style="color: var(--text-tertiary)">{{ fmtTs(record.created_at) }}</span>
            </template>
          </template>
          <template #emptyText>
            <div style="padding: 24px 0; text-align: center; color: var(--text-muted); font-size: 13px">
              No alerts promoted yet. Alerts are raised when an incident accumulates enough events (critical: 1, warning: 3, info: 5).
            </div>
          </template>
        </a-table>
        </a-card>
      </a-tab-pane>

      <!-- ══ BASELINES ══════════════════════════════════════════════════════ -->
      <a-tab-pane key="baselines" tab="Baselines">
        <a-card size="small" class="list-card">
        <div class="toolbar-info" style="display: flex; justify-content: space-between; align-items: center">
          <span>{{ baselinesTotal }} total · auto-refresh 5s</span>
          <a-space>
            <a-button :loading="baselinesLoading" @click="loadBaselines"><ReloadOutlined /> Refresh</a-button>
            <a-button danger :loading="clearingBaselines" @click="resetBaselinesModalOpen = true"><DeleteOutlined /> Reset</a-button>
          </a-space>
        </div>
        <div class="filters" style="margin-bottom: 8px">
          <a-input
            v-model:value="baselinesMetric"
            placeholder="Search by metric…"
            allow-clear
            class="search"
          >
            <template #prefix><SearchOutlined style="color: var(--text-placeholder)" /></template>
          </a-input>
        </div>
        <a-table
          :columns="baselineColumns"
          :data-source="baselines"
          :loading="baselinesLoading && baselines.length === 0"
          :pagination="{ current: baselinesPage, pageSize: PAGE_SIZE, total: baselinesTotal, showSizeChanger: false, onChange: (p: number) => { baselinesPage = p; loadBaselines() } }"
          :row-key="(record: BaselineRow) => `${record.isSynthetic ? 'pending' : 'done'}::${record.metric}::${record.device_id}::${record.device_state}`"
          size="small"
          :scroll="{ x: true }"
        >
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'metric'">
              <a v-if="record.isGroupRule" @click="openGroupDetail(record)" style="cursor: pointer">{{ friendlyLabel(record.metric) }}</a>
              <span v-else :title="record.metric">{{ friendlyLabel(record.metric) }}</span>
            </template>
            <template v-else-if="column.key === 'device_id'">
              <span :title="record.device_id">{{ deviceDisplayName(record.device_id) }}</span>
            </template>
            <template v-else-if="column.key === 'device_state'">
              <a-tooltip
                v-if="warmupRemainingMs && record.pendingWindowSize"
                :title="`Alerts are paused during warmup (${warmupCountdownLabel} left). Baseline collection will begin shortly.`"
              >
                <a-tag color="orange">warming up</a-tag>
              </a-tooltip>
              <a-tag v-else-if="record.pendingWindowSize" color="blue">collecting</a-tag>
              <a-tag v-else color="green">ready</a-tag>
            </template>
            <template v-else-if="column.key === 'time_slot'">
              {{ record.isSynthetic ? '—' : record.time_slot }}
            </template>
            <template v-else-if="column.key === 'sample_count'">
              <span style="font-variant-numeric: tabular-nums">
                <template v-if="record.isGroupRule">
                  {{ record.groupMetricCount ? `${record.groupReadyCount} of ${record.groupMetricCount} ready` : '—' }}
                </template>
                <template v-else>
                  {{ warmupRemainingMs && record.pendingWindowSize ? '—' : record.pendingWindowSize ? `${record.sample_count} / ${record.pendingWindowSize}` : record.sample_count }}
                </template>
              </span>
            </template>
            <template v-else-if="column.key === 'mean'">
              <span style="font-variant-numeric: tabular-nums">{{ fmtNum(record.mean, 3) }}</span>
            </template>
            <template v-else-if="column.key === 'std_dev'">
              <span style="font-variant-numeric: tabular-nums">{{ fmtNum(record.std_dev, 3) }}</span>
            </template>
            <template v-else-if="column.key === 'median'">
              <span style="font-variant-numeric: tabular-nums">{{ fmtNum(record.median, 3) }}</span>
            </template>
            <template v-else-if="column.key === 'mad'">
              <span style="font-variant-numeric: tabular-nums">{{ fmtNum(record.mad, 3) }}</span>
            </template>
            <template v-else-if="column.key === 'calculated_at'">
              <span style="color: var(--text-tertiary)">{{ record.isSynthetic ? '—' : fmtTs(record.calculated_at) }}</span>
            </template>
          </template>
          <template #emptyText>
            <div style="padding: 24px 0; text-align: center; color: var(--text-muted); font-size: 13px">
              No baselines yet — baselines are built up as metric data flows through the anomaly detection engine.
            </div>
          </template>
        </a-table>
        </a-card>
      </a-tab-pane>

      <!-- ══ SCHEMA DRIFT ═══════════════════════════════════════════════════ -->
      <a-tab-pane key="schema-drift" tab="Schema Drift">
        <a-alert
          v-if="!proInstalled"
          type="info"
          show-icon
          message="Schema drift detection requires an active license"
          style="margin-bottom: 12px"
        />
        <a-card size="small" class="list-card">
          <div class="toolbar-info" style="display: flex; justify-content: space-between; align-items: center">
            <span>{{ driftRules.length }} rule{{ driftRules.length !== 1 ? 's' : '' }}</span>
            <a-button type="primary" @click="openNewDriftRule()"><PlusOutlined /> Add rule</a-button>
          </div>
          <div style="font-size: 12px; color: var(--text-tertiary); margin-bottom: 8px">
            Alerts fire only for devices and types covered by a rule.
          </div>

          <a-table
            :columns="driftRuleColumns"
            :data-source="driftRules"
            :loading="driftRulesLoading"
            :pagination="{ pageSize: 20, showSizeChanger: true, pageSizeOptions: ['10', '20', '50'] }"
            :row-key="(r: DriftRuleConfig) => r.id ?? ''"
            size="small"
          >
            <template #bodyCell="{ column, record }">
              <template v-if="column.key === 'name'">
                <span style="cursor: pointer" @click="editDriftRule(record as DriftRuleConfig)">
                  {{ (record as DriftRuleConfig).name || '(unnamed)' }}
                </span>
              </template>
              <template v-else-if="column.key === 'scope'">
                <span style="color: var(--text-tertiary)">{{ driftRuleScopeLabel(record as DriftRuleConfig) }}</span>
              </template>
              <template v-else-if="column.key === 'driftType'">
                <a-tag
                  v-for="tag of driftRuleDriftTypeTags(record as DriftRuleConfig)"
                  :key="tag.label"
                  :color="tag.color"
                  style="margin: 1px"
                >{{ tag.label }}</a-tag>
                <span v-if="driftRuleDriftTypeTags(record as DriftRuleConfig).length === 0" style="color: var(--text-muted)">—</span>
              </template>
              <template v-else-if="column.key === 'severity'">
                {{ driftRuleSeverityLabel(record as DriftRuleConfig) }}
              </template>
              <template v-else-if="column.key === 'enabled'">
                <a-switch
                  :checked="(record as DriftRuleConfig).enabled"
                  size="small"
                  @change="toggleDriftRuleEnabled(record as DriftRuleConfig)"
                />
              </template>
              <template v-else-if="column.key === 'actions'">
                <a-space>
                  <a-button size="small" @click="editDriftRule(record as DriftRuleConfig)">Edit</a-button>
                  <a-popconfirm title="Delete this rule?" @confirm="deleteDriftRule(record as DriftRuleConfig)">
                    <a-button size="small" danger>
                      <template #icon><DeleteOutlined /></template>
                    </a-button>
                  </a-popconfirm>
                </a-space>
              </template>
            </template>
            <template #emptyText>
              <div style="padding: 24px 0; text-align: center; color: var(--text-muted); font-size: 13px">
                No schema drift alert rules configured. Add a rule to receive alerts when device schemas change.
              </div>
            </template>
          </a-table>
        </a-card>

        <DriftRuleDrawer
          :open="driftRuleDrawerOpen"
          :editing-rule="editingDriftRule"
          :prefill="driftRulePrefill"
          @update:open="driftRuleDrawerOpen = $event"
          @saved="loadDriftRules()"
        />
      </a-tab-pane>

      <!-- ══ RULES ══════════════════════════════════════════════════════════ -->
      <a-tab-pane key="rules" tab="Anomaly Rules">
        <!-- Hidden for now (device/metric name resolution needs more work first) — v-if="false", not deleted. -->
        <a-card v-if="false" size="small" class="list-card" style="margin-bottom: 16px">
          <div class="toolbar">
            <span style="color: var(--text-tertiary); font-size: 13px">
              <strong>Noisy Metrics (Bad Actors)</strong> — Metrics ranked by incident frequency, regardless of incident validity.
              Frequently firing metrics are candidates for tuning under ISA-18.2 alarm rationalization principles.
            </span>
            <a-select v-model:value="badActorsWindowDays" size="small" style="width: 110px" @change="loadBadActors">
              <a-select-option :value="7">Last 7 days</a-select-option>
              <a-select-option :value="30">Last 30 days</a-select-option>
              <a-select-option :value="90">Last 90 days</a-select-option>
            </a-select>
          </div>
          <a-table
            :data-source="badActors"
            :loading="badActorsLoading"
            :pagination="false"
            row-key="metric"
            size="small"
          >
            <a-table-column key="metric" title="Metric" data-index="metric">
              <template #default="{ record }">{{ metricLeaf(record.metric, record.device_name) }}</template>
            </a-table-column>
            <a-table-column key="device_name" title="Device" data-index="device_name">
              <template #default="{ record }">{{ deviceDisplayName(record.device_name) }}</template>
            </a-table-column>
            <a-table-column key="incident_count" title="Incidents" data-index="incident_count" :width="90" />
            <a-table-column key="total_events" title="Total Events" data-index="total_events" :width="110" />
            <a-table-column key="severity" title="Severity">
              <template #default="{ record }">
                <a-tag v-if="record.critical_count" color="red">{{ record.critical_count }} critical</a-tag>
                <a-tag v-if="record.warning_count" color="orange">{{ record.warning_count }} warning</a-tag>
                <a-tag v-if="record.info_count" color="blue">{{ record.info_count }} info</a-tag>
              </template>
            </a-table-column>
            <a-table-column key="status" title="Open / Resolved">
              <template #default="{ record }">{{ record.open_count }} open · {{ record.resolved_count }} resolved</template>
            </a-table-column>
            <a-table-column key="fpRate" title="False Positive Rate">
              <template #default="{ record }">
                <span v-if="fpRate(record) === null" style="color: var(--text-placeholder)">— no reasons recorded yet</span>
                <a-tag v-else :color="fpRate(record)! >= 50 ? 'red' : fpRate(record)! >= 20 ? 'orange' : 'green'">
                  {{ fpRate(record) }}%
                </a-tag>
              </template>
            </a-table-column>
            <a-table-column key="last_seen" title="Last Seen">
              <template #default="{ record }">{{ fmtTs(record.last_seen) }}</template>
            </a-table-column>
            <template #emptyText>
              <div style="padding: 24px 0; text-align: center; color: var(--text-muted); font-size: 13px">
                No incidents in this window — nothing to rank yet.
              </div>
            </template>
          </a-table>
        </a-card>

        <a-spin :spinning="configLoading">
          <template v-if="config">
            <a-card size="small" class="list-card">
            <div class="toolbar-info" style="display: flex; justify-content: space-between; align-items: center">
              <span>{{ config.metrics.length }} rule{{ config.metrics.length !== 1 ? 's' : '' }}</span>
              <a-button type="primary" @click="openAddMetric"><PlusOutlined /> Add rule</a-button>
            </div>

            <a-table
              :columns="metricColumns"
              :data-source="config.metrics"
              :pagination="{ pageSize: 20, showSizeChanger: true, pageSizeOptions: ['10', '20', '50'] }"
              row-key="name"
              size="small"
            >
              <template #bodyCell="{ column, record, index }">
                <template v-if="column.key === 'name'">
                  <span :title="record.name">{{ friendlyLabel(record.name) }}</span>
                </template>
                <template v-else-if="column.key === 'scope'">
                  <template v-if="record.scope === 'protocol'">
                    <a-tag :color="protocolColor(record.protocolPattern ?? '')" style="margin: 0">{{ protocolLabel(record.protocolPattern ?? '') }}</a-tag>
                  </template>
                  <template v-else-if="record.scope === 'source'">
                    <span :title="record.sourcePattern">{{ record.sourcePattern }}</span>
                  </template>
                  <template v-else>
                    {{ ruleDeviceName(record) || '—' }}
                  </template>
                </template>
                <template v-else-if="column.key === 'enabled'">
                  <a-switch
                    :checked="record.enabled"
                    size="small"
                    @change="toggleMetricEnabled(index)"
                  />
                </template>

                <template v-else-if="column.key === 'methods'">
                  <a-tag
                    v-for="label in ruleDetectionLabels(record)"
                    :key="label"
                    :color="categoryLabelColor(label)"
                    style="margin: 1px"
                  >{{ label }}</a-tag>
                </template>

                <template v-else-if="column.key === 'sensitivity'">
                  {{ tableSensitivityLabel(record) }}
                </template>

                <template v-else-if="column.key === 'seasonality'">
                  <span style="color: var(--text-tertiary)">{{ record.seasonality || 'none' }}</span>
                </template>

                <template v-else-if="column.key === 'actions'">
                  <a-space>
                    <a-button size="small" @click="openEditMetric(record, index)">Edit</a-button>
                    <a-button size="small" danger @click="removeMetric(index)">
                      <template #icon><DeleteOutlined /></template>
                    </a-button>
                  </a-space>
                </template>
              </template>
              <template #emptyText>
                <div style="padding: 24px 0; text-align: center; color: var(--text-muted); font-size: 13px">
                  No metric rules yet — click "Add rule" to define anomaly detection for a metric.
                </div>
              </template>
            </a-table>
            </a-card>
          </template>

          <div v-else-if="!configLoading" style="padding: 48px 0; text-align: center; color: var(--text-muted); font-size: 13px">
            No configuration loaded — check the agent connection.
          </div>
        </a-spin>
      </a-tab-pane>

    </a-tabs>

    <!-- ── Group rule detail modal ─────────────────────────────────────────── -->
    <a-modal
      v-model:open="groupDetailVisible"
      :title="groupDetailRule ? friendlyLabel(groupDetailRule.metric) : ''"
      :footer="null"
      width="720px"
    >
      <a-table
        :columns="[
          { title: 'Point', key: 'metric', ellipsis: true },
          { title: 'Device', dataIndex: 'deviceId', key: 'deviceId', width: 140, ellipsis: true },
          { title: 'State', dataIndex: 'deviceState', key: 'deviceState', width: 90 },
          { title: 'Status', key: 'status', width: 100 },
          { title: 'Samples', key: 'samples', width: 100 },
        ]"
        :data-source="groupDetailMetrics"
        :row-key="(r: any) => `${r.metricName}::${r.deviceId}::${r.deviceState}`"
        :pagination="false"
        size="small"
      >
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'metric'">
            <span :title="record.metricName">{{ friendlyLabel(record.metricName) }}</span>
          </template>
          <template v-else-if="column.key === 'deviceId'">
            <span :title="record.deviceId">{{ deviceDisplayName(record.deviceId) }}</span>
          </template>
          <template v-else-if="column.key === 'status'">
            <a-tag v-if="record.bufferSize >= record.windowSize" color="green">ready</a-tag>
            <a-tag v-else color="blue">collecting</a-tag>
          </template>
          <template v-else-if="column.key === 'samples'">
            <span style="font-variant-numeric: tabular-nums">{{ record.bufferSize }} / {{ record.windowSize }}</span>
          </template>
        </template>
        <template #emptyText>
          <div style="padding: 16px 0; text-align: center; color: var(--text-muted); font-size: 13px">
            No data points matched this rule yet.
          </div>
        </template>
      </a-table>
    </a-modal>

    <!-- ── Resolve incident modal ───────────────────────────────────────────── -->
    <a-modal
      :open="resolveModalOpen"
      title="Resolve incident"
      ok-text="Resolve"
      :confirm-loading="!!resolvingId"
      :ok-button-props="{ disabled: !resolveModalReason }"
      @ok="confirmResolve"
      @cancel="resolveModalOpen = false"
    >
      <p v-if="resolveModalIncident" style="margin-bottom: 16px">
        Mark "{{ friendlyLabel(resolveModalIncident.metric) }}" on
        {{ deviceDisplayName(resolveModalIncident.device_name) }} as resolved.
      </p>
      <a-form layout="vertical">
        <a-form-item label="Reason" required>
          <a-select v-model:value="resolveModalReason" placeholder="Why is this being resolved?" style="width: 100%">
            <a-select-option v-for="(label, value) in RESOLUTION_REASON_LABELS" :key="value" :value="value">
              {{ label }}
            </a-select-option>
          </a-select>
          <div style="font-size: 12px; color: var(--text-tertiary); margin-top: 4px">
            Used to spot noisy rules later (see Bad Actors on the Rules tab) — not shown anywhere else right now.
          </div>
        </a-form-item>
        <a-form-item label="Notes" style="margin-bottom: 0">
          <a-textarea v-model:value="resolveModalNotes" placeholder="Optional" :rows="2" />
        </a-form-item>
      </a-form>
    </a-modal>

    <!-- ── Reset baselines modal ────────────────────────────────────────────── -->
    <a-modal
      :open="resetBaselinesModalOpen"
      title="Reset all baselines?"
      ok-text="Reset"
      ok-type="danger"
      :confirm-loading="clearingBaselines"
      @ok="clearAllBaselines"
      @cancel="resetBaselinesModalOpen = false"
    >
      <p>Deletes saved baselines and clears live buffers — the detection engine relearns from scratch.</p>
    </a-modal>


    <!-- ── Metric config drawer ─────────────────────────────────────────────── -->
    <a-drawer
      :open="metricDrawerOpen"
      :title="editingMetricIdx !== null ? 'Edit rule' : 'Add rule'"
      width="480"
      @close="metricDrawerOpen = false"
    >
      <template #extra>
        <a-button @click="openTemplateLibrary">Use a template</a-button>
      </template>

      <a-form layout="vertical">
        <a-form-item label="Apply to">
          <a-segmented
            :value="scopeMode"
            :options="[
              { label: 'Specific point', value: 'point' },
              { label: 'Source', value: 'source' },
              { label: 'Protocol', value: 'protocol' },
            ]"
            @change="scopeMode = $event as MetricScope"
          />
        </a-form-item>

        <!-- Point scope: existing point picker -->
        <a-form-item v-if="scopeMode === 'point'" label="Point" required>
          <div
            class="point-picker-trigger"
            :class="{ 'point-picker-trigger--empty': !selectedPointLabel }"
            @click="pointPickerOpen = true"
          >
            <template v-if="selectedPointLabel">
              <div style="flex: 1; min-width: 0">
                <div style="font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">{{ selectedPointLabel }}</div>
                <div v-if="selectedSourceLabel" style="font-size: 12px; color: var(--text-tertiary)">{{ selectedSourceLabel }}</div>
              </div>
              <a-button size="small" @click.stop="pointPickerOpen = true">Change</a-button>
            </template>
            <template v-else>
              <span style="color: var(--text-placeholder)">Click to select a point…</span>
            </template>
          </div>
        </a-form-item>

        <PointPickerModal
          v-if="scopeMode === 'point'"
          :open="pointPickerOpen"
          mode="single"
          @update:open="pointPickerOpen = $event"
          @select="onPointSelected"
        />

        <!-- Source scope: endpoint selector -->
        <a-form-item v-if="scopeMode === 'source'" label="Source" required>
          <a-select
            v-model:value="selectedSource"
            placeholder="Select an endpoint…"
            show-search
            :filter-option="filterSourceOption"
            style="width: 100%"
          >
            <a-select-option v-for="src in uniqueSources" :key="src.name" :value="src.name" :label="src.name">
              <div style="display: flex; align-items: center; gap: 8px">
                <a-tag v-if="src.protocol" :color="protocolColor(src.protocol)" style="margin: 0">{{ protocolLabel(src.protocol) }}</a-tag>
                <span style="overflow: hidden; text-overflow: ellipsis">{{ src.name }}</span>
              </div>
            </a-select-option>
          </a-select>
          <div style="margin-top: 4px; font-size: 12px; color: var(--text-tertiary)">
            Applies detection to all points from this endpoint.
          </div>
        </a-form-item>

        <!-- Protocol scope: protocol selector -->
        <a-form-item v-if="scopeMode === 'protocol'" label="Protocol" required>
          <a-select
            v-model:value="selectedProtocol"
            placeholder="Select a protocol…"
            style="width: 100%"
          >
            <a-select-option v-for="proto in uniqueProtocols" :key="proto" :value="proto">
              <a-tag :color="protocolColor(proto)" style="margin: 0">{{ protocolLabel(proto) }}</a-tag>
            </a-select-option>
          </a-select>
          <div style="margin-top: 4px; font-size: 12px; color: var(--text-tertiary)">
            Applies detection to all points using this protocol.
          </div>
        </a-form-item>

        <a-form-item label="Detection type">
          <div class="detection-category-cards" role="group" aria-label="Detection type">
            <label
              v-for="cat in DETECTION_CATEGORIES"
              :key="cat.key"
              class="detection-category-card"
              :class="{ 'detection-category-card--active': activeCategories.has(cat.key) }"
            >
              <a-checkbox
                :checked="activeCategories.has(cat.key)"
                @change="toggleCategory(cat)"
              />
              <div class="detection-category-card__content">
                <div class="detection-category-card__title">{{ cat.title }}</div>
                <div class="detection-category-card__desc">{{ cat.description }}</div>
              </div>
            </label>
          </div>
          <div v-if="activeCategories.has('limits')" class="limits-inputs">
            <a-row :gutter="8">
              <a-col :span="12">
                <a-input-number
                  v-model:value="expectedMin"
                  placeholder="Min"
                  style="width: 100%"
                />
              </a-col>
              <a-col :span="12">
                <a-input-number
                  v-model:value="expectedMax"
                  placeholder="Max"
                  style="width: 100%"
                />
              </a-col>
            </a-row>
            <div v-if="expectedRangeMissingBounds" class="detection-method-warning">
              Both min and max bounds are required.
            </div>
          </div>
          <div v-if="selectedMethodCount === 0" class="detection-method-warning">
            Select at least one detection type.
          </div>
          <div v-if="[...activeCategories].filter(k => k !== 'limits').length > 1" class="multi-category-note">
            Multiple detection types enabled. Shared settings may affect each type differently.
          </div>
          <a-alert
            v-if="hasLegacyFusion"
            type="info"
            show-icon
            style="margin-top: 8px"
            message="This rule uses the legacy Fusion method. It will continue to work, but Fusion cannot be added to new rules."
          />
        </a-form-item>

        <a-form-item v-if="hasStatisticalDetector" label="Sensitivity">
          <a-segmented
            :value="currentSensitivity === 'custom' ? undefined : currentSensitivity"
            :options="[
              { label: 'Low', value: 'low' },
              { label: 'Medium', value: 'medium' },
              { label: 'High', value: 'high' },
            ]"
            @change="setSensitivity($event as SensitivityLevel)"
          />
          <div class="sensitivity-description">
            <span v-if="currentSensitivity === 'low'">Fewer anomaly alerts. Focus on larger deviations.</span>
            <span v-else-if="currentSensitivity === 'high'">Detect smaller deviations. May generate more alerts.</span>
            <span v-else-if="currentSensitivity === 'medium'">Balanced anomaly detection.</span>
            <span v-else>Custom threshold — adjust in Advanced Settings below.</span>
          </div>
        </a-form-item>


        <a-collapse
          v-model:activeKey="advancedOpen"
          ghost
          class="advanced-settings-collapse"
        >
          <a-collapse-panel key="advanced" header="Advanced Settings (Optional)">
            <a-row :gutter="12">
              <a-col :span="12">
                <a-form-item label="Detection threshold">
                  <a-input-number
                    v-model:value="metricForm.threshold"
                    :min="0.1"
                    :step="0.5"
                    style="width: 100%"
                  />
                </a-form-item>
              </a-col>
              <a-col :span="12">
                <a-form-item label="Window size (samples)">
                  <a-input-number
                    v-model:value="metricForm.windowSize"
                    :min="5"
                    :step="10"
                    style="width: 100%"
                  />
                </a-form-item>
              </a-col>
            </a-row>
            <a-row :gutter="12">
              <a-col :span="12">
                <a-form-item label="Minimum confidence (%)">
                  <a-input-number
                    v-model:value="confidencePercent"
                    :min="0"
                    :max="100"
                    :step="5"
                    style="width: 100%"
                    :formatter="(v: number) => `${v}%`"
                    :parser="(v: string) => Number(v.replace('%', ''))"
                  />
                </a-form-item>
              </a-col>
              <a-col :span="12">
                <a-form-item label="Alert cooldown (minutes)">
                  <a-input-number
                    v-model:value="cooldownMinutes"
                    :min="0"
                    :step="1"
                    style="width: 100%"
                  />
                  <div class="advanced-setting-help">Minimum time between repeated alerts for this rule.</div>
                </a-form-item>
              </a-col>
            </a-row>
            <a-form-item label="Seasonality">
              <a-select v-model:value="metricForm.seasonality" style="width: 160px">
                <a-select-option v-for="s in SEASONALITY_OPTIONS" :key="s" :value="s">
                  {{ s }}
                </a-select-option>
              </a-select>
            </a-form-item>
          </a-collapse-panel>
        </a-collapse>

      </a-form>

      <template #footer>
        <a-space style="display: flex; justify-content: space-between; width: 100%">
          <a-button @click="openSaveTemplateModal">Save as template</a-button>
          <a-space>
            <a-button @click="metricDrawerOpen = false">Cancel</a-button>
            <a-button type="primary" @click="saveMetric">
              {{ editingMetricIdx !== null ? 'Update' : 'Add' }}
            </a-button>
          </a-space>
        </a-space>
      </template>
    </a-drawer>

    <!-- ── Template library picker ──────────────────────────────────────────── -->
    <a-drawer
      :open="templateLibraryOpen"
      title="Choose a template"
      width="480"
      @close="templateLibraryOpen = false"
    >
      <a-input
        v-model:value="templateSearch"
        placeholder="Search templates…"
        allow-clear
        style="margin-bottom: 16px"
      >
        <template #prefix><SearchOutlined /></template>
      </a-input>

      <a-spin v-if="templatesLoading" />
      <template v-else>
        <div v-for="[category, templates] in templatesByCategory" :key="category" style="margin-bottom: 20px">
          <div style="font-weight: 600; font-size: 12px; color: var(--text-tertiary); text-transform: uppercase; margin-bottom: 8px">
            {{ category }}
          </div>
          <div
            v-for="t in templates"
            :key="t.builtin ? t.id : t.uuid"
            style="border: 1px solid var(--border-color); border-radius: 6px; padding: 10px 12px; margin-bottom: 8px; cursor: pointer"
            @click="applyTemplate(t)"
          >
            <div style="display: flex; align-items: center; justify-content: space-between">
              <span style="font-weight: 500">{{ t.name }}</span>
              <DeleteOutlined
                v-if="!t.builtin"
                style="color: var(--text-muted)"
                @click.stop="deleteTemplate(t.uuid)"
              />
            </div>
            <div v-if="t.purpose" style="font-size: 12px; color: var(--text-tertiary); margin: 4px 0">{{ t.purpose }}</div>
            <div style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 4px">
              <a-tag v-for="label in uniqueCategoryLabels(t.methods)" :key="label" :color="categoryLabelColor(label)" style="font-size: 10px">{{ label }}</a-tag>
            </div>
          </div>
        </div>
        <a-empty v-if="templatesByCategory.size === 0" description="No templates found" />
      </template>
    </a-drawer>

    <!-- ── Save current rule as template ────────────────────────────────────── -->
    <a-modal
      :open="saveTemplateModalOpen"
      title="Save as template"
      ok-text="Save"
      :confirm-loading="saveTemplateSaving"
      @ok="saveAsTemplate"
      @cancel="saveTemplateModalOpen = false"
    >
      <a-form layout="vertical">
        <a-form-item label="Template name" required>
          <a-input
            v-model:value="saveTemplateName"
            placeholder="e.g. My zone temperature preset"
            @press-enter="saveAsTemplate"
          />
        </a-form-item>
      </a-form>
      <p style="font-size: 12px; color: var(--text-tertiary)">
        Saves the current methods, threshold, window size, min confidence, cooldown, seasonality,
        and expected range as a reusable template under "My templates".
      </p>
    </a-modal>
  </AppLayout>
</template>

<style scoped>
.heading { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 16px; }
.heading p { color: var(--text-tertiary); margin: 0; }
.list-card { border-radius: 9px; }
.list-card :deep(.ant-table-thead > tr > th) { background: var(--bg-table-header); font-size: 12px; font-weight: 650; }
.list-card :deep(.ant-table-tbody > tr:hover > td) { background: var(--bg-table-hover); }
.filters { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 12px; }
.search { width: 300px; max-width: 100%; }
.filter { width: 170px; max-width: 100%; }
.toolbar-info { color: var(--text-tertiary); font-size: 12px; margin-bottom: 10px; }
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  gap: 8px;
  flex-wrap: wrap;
}

@keyframes severity-pulse {
  0%, 100% { opacity: 1; box-shadow: 0 0 7px 2px rgba(255, 77, 79, 0.75); }
  50%       { opacity: 0;   box-shadow: none; }
}

.severity-critical {
  animation: severity-pulse 0.75s ease-in-out infinite;
}

.detection-category-cards { display: flex; flex-direction: column; gap: 8px; }
.detection-category-card {
  display: flex; align-items: flex-start; gap: 12px;
  padding: 12px; border: 1px solid var(--border-color-strong); border-radius: 6px;
  cursor: pointer; transition: all 0.2s;
}
.detection-category-card:hover { border-color: #1677ff; }
.detection-category-card--active { border-color: #1677ff; background: var(--bg-selected); }
.detection-category-card__title { font-weight: 600; font-size: 13px; }
.detection-category-card__desc { font-size: 12px; color: var(--text-secondary); margin-top: 2px; }
.detection-method-warning { margin-top: 8px; color: #cf1322; font-size: 12px; }
.limits-inputs { margin-top: 8px; padding: 10px 12px; background: var(--bg-subtle); border: 1px solid var(--border-color); border-radius: 6px; }
.multi-category-note { margin-top: 8px; font-size: 12px; color: var(--text-tertiary); }
.sensitivity-description { margin-top: 6px; font-size: 12px; color: var(--text-tertiary); }
:deep(.ant-segmented-item-selected) { background: #1677ff !important; color: #fff !important; }
:deep(.ant-segmented-item-selected .ant-segmented-item-label) { color: #fff !important; }
.advanced-settings-collapse { margin: 0 -12px 16px; }
.advanced-settings-collapse :deep(.ant-collapse-header) { font-size: 13px; color: var(--text-secondary); padding: 8px 12px !important; }
.advanced-settings-collapse :deep(.ant-collapse-content-box) { padding: 0 12px !important; }
.advanced-setting-help { font-size: 12px; color: var(--text-tertiary); margin-top: 4px; }

.point-picker-trigger {
	display: flex; align-items: center; gap: 10px;
	padding: 8px 12px; border: 1px solid var(--border-color); border-radius: 6px;
	cursor: pointer; transition: border-color 0.2s; min-height: 40px;
}
.point-picker-trigger:hover { border-color: #1677ff; }
.point-picker-trigger--empty { justify-content: center; border-style: dashed; }

</style>
