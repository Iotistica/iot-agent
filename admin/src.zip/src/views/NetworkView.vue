<script setup lang="ts">
import { computed, ref, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { message, Modal } from 'ant-design-vue'
import type { TableColumnType } from 'ant-design-vue'
import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons-vue'
import AppLayout from '@/components/layout/AppLayout.vue'
import CaptureTab from '@/components/network/CaptureTab.vue'
import {
  networkApi,
  type FirewallRule,
  type FirewallResponse,
  type SystemFirewallRule,
  type PortEntry,
  type ReservedPort,
  type FirewallRuleInput,
  type NetworkInterfaceInfo,
} from '@/api/network'

const route = useRoute()
const router = useRouter()

const VALID_TABS = ['firewall', 'ports', 'capture'] as const
const activeTab = ref(
  typeof route.query.tab === 'string' && (VALID_TABS as readonly string[]).includes(route.query.tab)
    ? route.query.tab
    : 'firewall',
)

watch(activeTab, (tab) => {
  router.replace({ query: tab === 'firewall' ? {} : { tab } })
})

// ── Firewall ────────────────────────────────────────────────────────────────

const firewallData = ref<FirewallResponse | null>(null)
const firewallLoading = ref(false)
const firewallModeChanging = ref(false)
const firewallDisableConfirmationOpen = ref(false)

const manualFirewallMode = computed(() => {
  const mode = firewallData.value?.status?.mode
  return mode === 'on' || mode === 'off'
})

const firewallIsActive = computed(() => {
  const status = firewallData.value?.status
  return !!status?.initialized && (status.mode === 'on' || status.mode === 'auto')
})

type InboundRule = FirewallRule | SystemFirewallRule

function isSystemRule(rule: InboundRule): rule is SystemFirewallRule {
  return 'source' in rule && rule.source === 'system'
}

const inboundRules = computed<InboundRule[]>(() => {
  const systemRules = firewallData.value?.systemRules ?? []
  const userRules = firewallData.value?.rules ?? []
  const regularSystemRules = systemRules.filter((rule) => !rule.isFinal)
  const finalRules = systemRules.filter((rule) => rule.isFinal)

  return [...regularSystemRules, ...userRules, ...finalRules]
})

const drawerOpen = ref(false)
const editingRule = ref<FirewallRule | null>(null)
const ruleForm = ref<FirewallRuleInput>({ port: '', protocol: 'tcp', action: 'ACCEPT', interface_name: '', description: '' })
const saving = ref(false)
const networkInterfaces = ref<NetworkInterfaceInfo[]>([])
const interfacesLoading = ref(false)
const interfacesLoadError = ref(false)

const selectedInterfaceNotListed = computed(() => {
  const selectedInterface = ruleForm.value.interface_name
  return !!selectedInterface && !networkInterfaces.value.some((iface) => iface.name === selectedInterface)
})

function getInterfaceTypeLabel(iface: NetworkInterfaceInfo): string {
  const type = iface.type?.toLowerCase()
  const typeLabel = type === 'wireless' || type === 'wifi'
    ? 'Wi-Fi'
    : type === 'wired' || type === 'ethernet'
      ? 'Ethernet'
      : iface.type ?? ''
  if (iface.virtual) return typeLabel ? `Virtual ${typeLabel}` : 'Virtual'
  return typeLabel
}

const firewallColumns: TableColumnType<InboundRule>[] = [
  { title: 'Port', dataIndex: 'port', key: 'port', width: 120 },
  { title: 'Protocol', dataIndex: 'protocol', key: 'protocol', width: 100 },
  { title: 'Action', dataIndex: 'action', key: 'action', width: 110 },
  { title: 'Interface', dataIndex: 'interface_name', key: 'interface_name', width: 120 },
  { title: 'Description', dataIndex: 'description', key: 'description' },
  {
    title: 'Created',
    dataIndex: 'created_at',
    key: 'created_at',
    width: 180,
  },
  { title: 'Actions', key: 'actions', width: 100, fixed: 'right' },
]

const reservedColumns: TableColumnType<ReservedPort>[] = [
  { title: 'Port', dataIndex: 'port', key: 'port', width: 120 },
  { title: 'Service', dataIndex: 'service', key: 'service' },
]

async function loadFirewall() {
  firewallLoading.value = true
  try {
    firewallData.value = await networkApi.getFirewall()
  } finally {
    firewallLoading.value = false
  }
}

async function refreshFirewallAfterModeChange() {
  try {
    firewallData.value = await networkApi.getFirewall()
  } catch {
    firewallData.value = null
    message.error('Could not refresh firewall status and rules')
  }
}

async function applyFirewallMode(mode: 'on' | 'off') {
  if (firewallModeChanging.value) return

  firewallModeChanging.value = true
  try {
    const status = await networkApi.updateFirewallMode(mode)
    if (firewallData.value) {
      firewallData.value = { ...firewallData.value, available: status.enabled, status }
    }
    try {
      firewallData.value = await networkApi.getFirewall()
      message.success(`Firewall turned ${mode.toUpperCase()}`)
    } catch {
      firewallData.value = { ...firewallData.value!, systemRules: [] }
      message.error('Firewall mode changed, but its rules could not be refreshed')
    }
  } catch (err: any) {
    message.error(err?.response?.data?.error || err?.message || 'Failed to change firewall mode')
    await refreshFirewallAfterModeChange()
  } finally {
    firewallModeChanging.value = false
  }
}

function handleFirewallSwitchChange(enabled: boolean) {
  if (firewallModeChanging.value || firewallDisableConfirmationOpen.value) return
  if (enabled) {
    void applyFirewallMode('on')
    return
  }

  firewallDisableConfirmationOpen.value = true
  Modal.confirm({
    title: 'Disable Firewall?',
    content: 'Disabling the Iotistica firewall removes its managed network restrictions. Other system firewall rules may still apply. Do you want to continue?',
    okText: 'Disable Firewall',
    cancelText: 'Cancel',
    okType: 'danger',
    onOk: async () => {
      firewallDisableConfirmationOpen.value = false
      await applyFirewallMode('off')
    },
    onCancel: () => {
      firewallDisableConfirmationOpen.value = false
    },
  })
}

function switchToManualFirewall() {
  void applyFirewallMode('on')
}

async function loadNetworkInterfaces() {
  interfacesLoading.value = true
  interfacesLoadError.value = false
  try {
    networkInterfaces.value = await networkApi.getInterfaces()
  } catch {
    interfacesLoadError.value = true
  } finally {
    interfacesLoading.value = false
  }
}

function openAddRule() {
  editingRule.value = null
  ruleForm.value = { port: '', protocol: 'tcp', action: 'ACCEPT', interface_name: '', description: '' }
  drawerOpen.value = true
  void loadNetworkInterfaces()
}

function openEditRule(rule: FirewallRule) {
  editingRule.value = rule
  ruleForm.value = {
    port: rule.port,
    protocol: rule.protocol,
    action: rule.action ?? 'ACCEPT',
    interface_name: rule.interface_name || '',
    description: rule.description || '',
  }
  drawerOpen.value = true
  void loadNetworkInterfaces()
}

async function submitRule() {
  if (!ruleForm.value.port.trim()) {
    message.warning('Port is required')
    return
  }
  saving.value = true
  try {
    if (editingRule.value) {
      await networkApi.updateRule(editingRule.value.id, ruleForm.value)
      message.success('Rule updated')
    } else {
      await networkApi.addRule(ruleForm.value)
      message.success('Rule added')
    }
    drawerOpen.value = false
    await loadFirewall()
  } catch (err: any) {
    message.error(err?.message || 'Failed to save rule')
  } finally {
    saving.value = false
  }
}

function confirmDelete(rule: FirewallRule) {
  Modal.confirm({
    title: 'Delete Firewall Rule',
    icon: () => null,
    content: `Delete rule for port ${rule.port}/${rule.protocol}?`,
    okText: 'Delete',
    okType: 'danger',
    async onOk() {
      try {
        await networkApi.deleteRule(rule.id)
        message.success('Rule deleted')
        await loadFirewall()
      } catch (err: any) {
        message.error(err?.message || 'Failed to delete rule')
      }
    },
  })
}

// ── Ports ────────────────────────────────────────────────────────────────────

const ports = ref<PortEntry[]>([])
const portsReserved = ref<ReservedPort[]>([])
const portsLoading = ref(false)

const portsColumns: TableColumnType<PortEntry>[] = [
  { title: 'Port', dataIndex: 'port', key: 'port', width: 100, sorter: (a: PortEntry, b: PortEntry) => a.port - b.port, defaultSortOrder: 'ascend' },
  { title: 'Protocol', dataIndex: 'protocol', key: 'protocol', width: 100 },
  { title: 'Address', dataIndex: 'address', key: 'address', width: 160 },
  { title: 'Process / Container', dataIndex: 'process', key: 'process' },
  { title: 'Source', key: 'source', width: 100 },
]

async function loadPorts() {
  portsLoading.value = true
  try {
    const data = await networkApi.getPorts()
    ports.value = data.ports
    portsReserved.value = data.reservedPorts
  } finally {
    portsLoading.value = false
  }
}

function isReservedPort(port: number): boolean {
  return portsReserved.value.some((r) => r.port === port)
}

// ── Lifecycle ───────────────────────────────────────────────────────────────

onMounted(() => {
  loadFirewall()
  loadPorts()
})
</script>

<template>
  <AppLayout title="Network">
    <a-tabs v-model:activeKey="activeTab">
      <a-tab-pane key="firewall">
        <template #tab>Firewall</template>

        <a-alert
          v-if="firewallData && !firewallData.status"
          message="Firewall management is not available in this deployment mode"
          type="info"
          show-icon
          style="margin-bottom: 16px"
        />

        <template v-if="firewallData?.status">
          <div class="status-bar">
            <a-switch
              :checked="firewallData.status.mode === 'on'"
              checked-children="ON"
              un-checked-children="OFF"
              :loading="firewallModeChanging"
              :disabled="firewallModeChanging || firewallDisableConfirmationOpen || !manualFirewallMode"
              @change="handleFirewallSwitchChange"
            />
            <a-tag v-if="!manualFirewallMode" color="blue">
              Mode: {{ firewallData.status.mode.toUpperCase() }}
            </a-tag>
            <a-button
              v-if="!manualFirewallMode"
              size="small"
              :disabled="firewallModeChanging"
              @click="switchToManualFirewall"
            >
              Switch to manual (ON)
            </a-button>
            <a-tag :color="firewallIsActive ? 'green' : 'default'">
              {{ firewallIsActive ? 'Active' : 'Inactive' }}
            </a-tag>
          </div>
        </template>

        <div class="section-header">
          <h3>Inbound Rules</h3>
          <a-button type="primary" :disabled="!firewallData?.available" @click="openAddRule">
            <template #icon><PlusOutlined /></template>
            Add Rule
          </a-button>
        </div>

        <a-table
          :columns="firewallColumns"
          :data-source="inboundRules"
          :loading="firewallLoading"
          :pagination="false"
          row-key="id"
          size="small"
        >
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'protocol'">
              <a-tag>{{ (record as FirewallRule).protocol.toUpperCase() }}</a-tag>
            </template>
            <template v-else-if="column.key === 'action'">
              <a-tag :color="(record as InboundRule).action === 'ACCEPT' ? 'green' : (record as InboundRule).action === 'REJECT' ? 'orange' : (record as InboundRule).action === 'DROP' ? 'red' : 'default'">
                {{ (record as InboundRule).action }}
              </a-tag>
            </template>
            <template v-else-if="column.key === 'interface_name'">
              {{ (record as InboundRule).interface_name || '—' }}
            </template>
            <template v-else-if="column.key === 'created_at'">
              {{ isSystemRule(record as InboundRule) ? 'System' : new Date((record as FirewallRule).created_at).toLocaleString() }}
            </template>
            <template v-else-if="column.key === 'actions'">
              <a-space v-if="!isSystemRule(record as InboundRule)">
                <a-button type="text" size="small" @click="openEditRule(record as FirewallRule)">
                  <template #icon><EditOutlined /></template>
                </a-button>
                <a-button type="text" size="small" danger @click="confirmDelete(record as FirewallRule)">
                  <template #icon><DeleteOutlined /></template>
                </a-button>
              </a-space>
            </template>
          </template>
        </a-table>

        <template v-if="firewallData?.reservedPorts?.length">
          <h3 style="margin-top: 24px">Reserved Ports</h3>
          <a-table
            :columns="reservedColumns"
            :data-source="firewallData.reservedPorts"
            :pagination="false"
            row-key="port"
            size="small"
          />
        </template>
      </a-tab-pane>

      <a-tab-pane key="ports">
        <template #tab>Ports</template>

        <a-table
          :columns="portsColumns"
          :data-source="ports"
          :loading="portsLoading"
          :pagination="false"
          row-key="port"
          size="small"
        >
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'port'">
              <span>{{ (record as PortEntry).port }}</span>
              <a-tag v-if="isReservedPort((record as PortEntry).port)" color="orange" style="margin-left: 6px">reserved</a-tag>
            </template>
            <template v-else-if="column.key === 'source'">
              <a-tag :color="(record as PortEntry).source === 'docker' ? 'blue' : 'default'">
                {{ (record as PortEntry).source }}
              </a-tag>
            </template>
          </template>
        </a-table>
      </a-tab-pane>

      <a-tab-pane key="capture">
        <template #tab>Capture</template>
        <CaptureTab />
      </a-tab-pane>
    </a-tabs>

    <!-- Add / Edit Rule Drawer -->
    <a-drawer
      :open="drawerOpen"
      :title="editingRule ? 'Edit Firewall Rule' : 'Add Inbound Rule'"
      placement="right"
      :width="420"
      @close="drawerOpen = false"
    >
      <a-form layout="vertical">
        <a-form-item label="Port or Port Range" required>
          <a-input v-model:value="ruleForm.port" placeholder="e.g. 8080 or 8080-8090" />
        </a-form-item>
        <a-form-item label="Protocol">
          <a-select v-model:value="ruleForm.protocol" :get-popup-container="(t: HTMLElement) => t.parentElement!">
            <a-select-option value="tcp">TCP</a-select-option>
            <a-select-option value="udp">UDP</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="Action" required>
          <a-select v-model:value="ruleForm.action" :get-popup-container="(t: HTMLElement) => t.parentElement!">
            <a-select-option value="ACCEPT">ACCEPT — Allow traffic</a-select-option>
            <a-select-option value="REJECT">REJECT — Refuse traffic</a-select-option>
            <a-select-option value="DROP">DROP — Silently discard traffic</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="Interface">
          <a-select
            v-model:value="ruleForm.interface_name"
            placeholder="Any interface"
            :loading="interfacesLoading"
            :not-found-content="interfacesLoadError ? 'Could not load interfaces' : 'No matching interfaces'"
            :get-popup-container="(trigger: HTMLElement) => trigger.parentElement!"
          >
            <a-select-option value="">Any interface</a-select-option>
            <a-select-option
              v-if="ruleForm.interface_name && selectedInterfaceNotListed"
              :value="ruleForm.interface_name"
            >
              {{ ruleForm.interface_name }} ({{ interfacesLoadError ? 'availability unknown' : interfacesLoading ? 'checking' : 'unavailable' }})
            </a-select-option>
            <a-select-option
              v-for="iface in networkInterfaces"
              :key="iface.name"
              :value="iface.name"
            >
              {{ iface.name }}<span v-if="getInterfaceTypeLabel(iface)"> — {{ getInterfaceTypeLabel(iface) }}</span>
            </a-select-option>
          </a-select>
          <div v-if="interfacesLoadError" class="interface-hint">
            Could not load network interfaces. The saved selection is preserved.
          </div>
          <div v-else-if="!interfacesLoading && networkInterfaces.length === 0" class="interface-hint">
            No network interfaces found. Any interface can still be selected.
          </div>
        </a-form-item>
        <a-form-item label="Description">
          <a-input v-model:value="ruleForm.description" placeholder="Optional description" />
        </a-form-item>
      </a-form>

      <template #footer>
        <div class="drawer-footer">
          <a-button @click="drawerOpen = false">Cancel</a-button>
          <a-button type="primary" :loading="saving" @click="submitRule">
            {{ editingRule ? 'Update' : 'Add' }}
          </a-button>
        </div>
      </template>
    </a-drawer>
  </AppLayout>
</template>

<style scoped>
.interface-hint {
  margin-top: 6px;
  color: var(--text-secondary, rgba(255, 255, 255, 0.65));
  font-size: 12px;
}

.status-bar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}

.status-label {
  font-size: 13px;
  color: var(--text-secondary, rgba(255, 255, 255, 0.65));
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.section-header h3 {
  margin: 0;
}

.drawer-footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}
</style>
