<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'
import type { TableColumnType } from 'ant-design-vue'
import { Modal } from 'ant-design-vue'
import AppLayout from '@/components/layout/AppLayout.vue'
import { client } from '@/api/client'
import { pipelineApi, type SubscriptionActivity, type ActivityEvent } from '@/api/pipeline'
import { datasetsApi, type MlDataset } from '@/api/ml-datasets'
import { protocolColor, protocolLabel } from '@/utils/protocol'
import { BarChartOutlined, LineChartOutlined, WifiOutlined, WarningOutlined, ClockCircleOutlined, SaveOutlined, CloseOutlined, DatabaseOutlined, CopyOutlined, EditOutlined, DeleteOutlined, DownloadOutlined, ReloadOutlined, PauseOutlined, PlayCircleOutlined, PushpinOutlined, PushpinFilled } from '@ant-design/icons-vue'
import CreateDatasetDrawer from '@/components/CreateDatasetDrawer.vue'
import CreateViewDrawer from '@/components/CreateViewDrawer.vue'
import PointDetailsDrawer from '@/components/data/PointDetailsDrawer.vue'
import PointHistoryModal from '@/components/data/PointHistoryModal.vue'
import { viewsApi, type SavedView as SavedViewType } from '@/api/views'
import { sourcesApi } from '@/api/sources'
import type { Endpoint } from '@/types'
import { dataExplorerPointName, dataExplorerPoints, dataExplorerSourceLookup, dataExplorerSourceName, matchesDataExplorerView, missingDataExplorerViewPointCount, normalizeDataExplorerPointKey, orderDataExplorerViewPoints, type DataExplorerPointRow } from '@/utils/data-explorer-point-key'
import { mergePinnedDataExplorerPoints } from '@/utils/data-explorer-pins'
import { restoreDataExplorerTabs } from '@/utils/data-explorer-tabs'

type PointRow = DataExplorerPointRow
type DeviceRecord = { uuid: string; endpoint_id: number; name: string; protocol: string; metadata?: Record<string, unknown> }
const subscriptions = ref<SubscriptionActivity[]>([])
const latestReadings = ref<ActivityEvent[]>([])
const devices = ref<DeviceRecord[]>([])
const sources = ref<Endpoint[]>([])
const observedPointCount = ref(0)
const loading = ref(true)
const error = ref('')
const metadataError = ref('')
const search = ref('')
const protocolFilter = ref<string | undefined>(undefined)
const sourceFilter = ref<string | undefined>(undefined)
const qualityFilter = ref<string | undefined>(undefined)
const selected = ref<PointRow | null>(null)
const drawerOpen = ref(false)
const historyPoint = ref<PointRow | null>(null)
const historyOpen = ref(false)
const paused = ref(false)
const favorites = ref<string[]>([])
const pinnedKeys = ref<string[]>([])
const pinnedPointCache = ref(new Map<string, PointRow>())
function favKey(p: PointRow): string { return `${p.endpointName}::${p.metric}` }
const favPointCache = ref(new Map<string, PointRow>())
type SavedView = SavedViewType
const savedViews = ref<SavedView[]>([])
const activeTab = ref('all')
const openViewIds = ref<string[]>([])
const viewsLoading = ref(false)
const viewError = ref('')
const selectedPointKeys = ref<string[]>([])
const viewDrawerOpen = ref(false)
const editingView = ref<SavedView | null>(null)
const viewMode = computed(() => activeTab.value === 'favorites' ? 'favorites' : 'all')
const activeSavedView = computed(() => savedViews.value.find(v => v.id === activeTab.value))
const activeViewIds = computed(() => new Set((activeSavedView.value?.pointKeys || []).map(normalizeDataExplorerPointKey)))
const rowSelection = computed(() => ({
  selectedRowKeys: selectedPointKeys.value,
  onChange: (keys: (string | number)[]) => { selectedPointKeys.value = keys.map(String) },
}))
const pageSize = ref(20)
const tableSortField = ref<string | null>(null)
const tableSortOrder = ref<'ascend' | 'descend' | null>(null)
const lastSync = ref('')
const refreshing = ref(false)
const now = ref(Date.now())
const POLL_MS = 5000
const UNKNOWN_SOURCE = '__unknown__'
let timer: ReturnType<typeof setInterval> | undefined
let busy = false
let viewsLoaded = false
let nextMetadataRefresh = 0

const deviceNames = computed(() => {
  const map = new Map<string, string>()
  for (const d of devices.value) {
    const friendly = (d.metadata?.objectName as string | undefined) || d.name
    map.set(`${friendly}-${d.uuid.slice(0, 8)}`, friendly)
    map.set(friendly, friendly)
  }
  return map
})
function friendlyDevice(name: string) { return deviceNames.value.get(name) || name }
function deviceName(row: PointRow) { return row.deviceDisplayName || friendlyDevice(row.endpointName) }
const sourceLookup = computed(() => dataExplorerSourceLookup(sources.value, devices.value))
function sourceFor(row: PointRow) { return sourceLookup.value(row) }
function sourceName(row: PointRow) { return dataExplorerSourceName(sourceFor(row)) }
function pointName(row: PointRow) { return dataExplorerPointName(row) }
function originalName(row: PointRow) { return row.rawPointName || row.rawObjectName || row.metric }
function valueText(v: unknown) {
  if (v === null || v === undefined) return '—'
  if (typeof v === 'number') return Number.isInteger(v) ? String(v) : v.toFixed(2)
  return typeof v === 'object' ? JSON.stringify(v) : String(v)
}
function age(iso: string) {
  const ms = new Date(iso).getTime()
  if (!Number.isFinite(ms)) return 'Unknown'
  const s = Math.max(0, Math.floor((now.value - ms) / 1000))
  if (s < 5) return 'just now'
  if (s < 60) return `${s}s ago`
  if (s < 3600) return `${Math.floor(s / 60)}m ago`
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`
  return `${Math.floor(s / 86400)}d ago`
}
function isStale(iso: string) {
  const t = new Date(iso).getTime()
  return Number.isFinite(t) && now.value - t > 60000
}
// Events are a bounded recent sample, not a historical database or a full point inventory.
// Subscription snapshots can also contain readings absent from the recent sample.
const points = computed<PointRow[]>(() => dataExplorerPoints(latestReadings.value, subscriptions.value))
function persistFavorites() {
  try {
    localStorage.setItem('iot-explorer-favorites', JSON.stringify(favorites.value))
    const cache: Record<string, PointRow> = {}
    for (const [k, v] of favPointCache.value) cache[k] = v
    localStorage.setItem('iot-explorer-fav-cache', JSON.stringify(cache))
  } catch {}
}
function persistPinned() {
  try {
    localStorage.setItem('iot-explorer-pinned', JSON.stringify(pinnedKeys.value))
    const cache: Record<string, PointRow> = {}
    for (const [key, point] of pinnedPointCache.value) cache[key] = point
    localStorage.setItem('iot-explorer-pin-cache', JSON.stringify(cache))
  } catch {}
}
watch([points, favorites], () => {
  for (const p of points.value) {
    const fk = favKey(p)
    if (favorites.value.includes(fk)) favPointCache.value.set(fk, p)
  }
  for (const fk of favPointCache.value.keys()) {
    if (!favorites.value.includes(fk)) favPointCache.value.delete(fk)
  }
  persistFavorites()
})
watch([points, pinnedKeys], () => {
  const pinned = new Set(pinnedKeys.value)
  for (const point of points.value) {
    if (pinned.has(point.key)) pinnedPointCache.value.set(point.key, point)
  }
  for (const key of pinnedPointCache.value.keys()) {
    if (!pinned.has(key)) pinnedPointCache.value.delete(key)
  }
  persistPinned()
})
const sourceOptions = computed(() => {
  const options = new Map<string, string>()
  for (const point of points.value) {
    const source = sourceFor(point)
    options.set(source?.uuid ?? UNKNOWN_SOURCE, dataExplorerSourceName(source))
  }
  return [...options].sort((a, b) => a[1].localeCompare(b[1]))
    .map(([value, label]) => ({ value, label }))
})
const protocolOptions = computed(() => [...new Set([
  ...points.value.map(p => p.protocol),
  ...devices.value.map(d => d.protocol),
])].sort()
  .map(v => ({ value: v, label: protocolLabel(v) })))
function columnSort(a: PointRow, b: PointRow): number {
  const field = tableSortField.value
  const desc = tableSortOrder.value === 'descend' ? -1 : 1
  if (!field) return Date.parse(b.timestamp) - Date.parse(a.timestamp)
  if (field === 'source') return desc * sourceName(a).localeCompare(sourceName(b))
  if (field === 'device') return desc * deviceName(a).localeCompare(deviceName(b))
  if (field === 'point') return desc * pointName(a).localeCompare(pointName(b))
  if (field === 'value') {
    const na = typeof a.value === 'number' ? a.value : parseFloat(String(a.value ?? ''))
    const nb = typeof b.value === 'number' ? b.value : parseFloat(String(b.value ?? ''))
    if (isNaN(na) && isNaN(nb)) return 0
    if (isNaN(na)) return 1
    if (isNaN(nb)) return -1
    return desc * (na - nb)
  }
  if (field === 'updated') return desc * (Date.parse(a.timestamp) - Date.parse(b.timestamp))
  return 0
}
const pointsMatchingFilters = computed(() => {
  const liveKeys = new Set(points.value.map(favKey))
  let source = [...points.value]
  for (const [fk, p] of favPointCache.value) {
    if (!liveKeys.has(fk)) source.push(p)
  }
  source = mergePinnedDataExplorerPoints(source, pinnedKeys.value, pinnedPointCache.value)
  const q = search.value.trim().toLowerCase()
  return source.filter(p => {
    return (!q || [sourceName(p), deviceName(p), p.metric, p.normalizedName, p.rawPointName, p.rawObjectName, p.destinationName]
      .some(v => (v || '').toLowerCase().includes(q)))
      && (!protocolFilter.value || p.protocol === protocolFilter.value)
      && (sourceFilter.value === undefined || (sourceFor(p)?.uuid ?? UNKNOWN_SOURCE) === sourceFilter.value)
      && (!qualityFilter.value || (qualityFilter.value === 'STALE' ? isStale(p.timestamp) : qualityFilter.value === 'BAD' ? p.quality === 'BAD' : p.quality !== 'BAD' && !isStale(p.timestamp)))
  })
})
const livePointCount = computed(() => pointsMatchingFilters.value.length)
const filteredPoints = computed(() => {
  const filtered = pointsMatchingFilters.value.filter(p =>
    (viewMode.value !== 'favorites' || favorites.value.includes(favKey(p)))
    && (!activeSavedView.value || matchesDataExplorerView(p, activeViewIds.value)))
  if (viewMode.value === 'favorites') {
    return filtered.sort((a, b) => deviceName(a).localeCompare(deviceName(b)) || pointName(a).localeCompare(pointName(b)))
  }
  if (activeSavedView.value && !tableSortField.value) {
    return orderDataExplorerViewPoints(filtered, activeSavedView.value.pointKeys)
  }
  return filtered.sort(columnSort)
})
const favoriteCount = computed(() => favorites.value.length)
const missingViewCount = computed(() => missingDataExplorerViewPointCount(points.value, activeViewIds.value))
const candidateViewPoints = computed(() =>
  points.value.filter(p => selectedPointKeys.value.includes(p.key)))
function openCreateView(_selectedOnly = false) {
  editingView.value = null
  viewDrawerOpen.value = true
}
function openEditView(view: SavedView) {
  editingView.value = view
  viewDrawerOpen.value = true
}
async function loadViews() {
  viewsLoading.value = true
  try {
    savedViews.value = await viewsApi.list()
    viewError.value = ''
    viewsLoaded = true
  } catch { viewError.value = 'Saved views API is unavailable.' }
  finally { viewsLoading.value = false }
}
function onViewSaved() {
  loadViews()
}
function persistViewTabs() {
  try {
    localStorage.setItem('iot-explorer-tabs', JSON.stringify({ activeTab: activeTab.value, openViewIds: openViewIds.value }))
  } catch {}
}
function activateTab(id: string) {
  activeTab.value = id
  persistViewTabs()
}
function openSavedView(id: string) {
  if (!openViewIds.value.includes(id)) openViewIds.value.push(id)
  activeTab.value = id
  persistViewTabs()
}
function closeSavedView(id: string) {
  openViewIds.value = openViewIds.value.filter(v => v !== id)
  if (activeTab.value === id) activeTab.value = 'all'
  persistViewTabs()
}
async function deleteSavedView(id: string) {
  try {
    await viewsApi.remove(id)
    closeSavedView(id)
    await loadViews()
  } catch { viewError.value = 'Unable to delete the saved view.' }
}

function toggleFavorite(key: string) {
  if (favorites.value.includes(key)) {
    favorites.value = favorites.value.filter(v => v !== key)
    favPointCache.value.delete(key)
  } else {
    favorites.value = [...favorites.value, key]
    const point = points.value.find(p => favKey(p) === key)
    if (point) favPointCache.value.set(key, point)
  }
  persistFavorites()
}

function togglePin(point: PointRow) {
  if (pinnedKeys.value.includes(point.key)) {
    pinnedKeys.value = pinnedKeys.value.filter(key => key !== point.key)
    pinnedPointCache.value.delete(point.key)
  } else {
    pinnedKeys.value = [...pinnedKeys.value, point.key]
    pinnedPointCache.value.set(point.key, point)
  }
  persistPinned()
}

// ── ML Datasets ──────────────────────────────────────────────────────────────
const datasets = ref<MlDataset[]>([])
const datasetsLoading = ref(false)
const datasetDrawerOpen = ref(false)
const editingDataset = ref<MlDataset | null>(null)
const candidateDatasetPoints = computed(() =>
  points.value.filter(p => selectedPointKeys.value.includes(p.key)))

async function loadDatasets() {
  datasetsLoading.value = true
  try {
    datasets.value = await datasetsApi.list()
  } catch { /* datasets API may not be available yet */ }
  finally { datasetsLoading.value = false }
}

function openCreateDataset() {
  editingDataset.value = null
  datasetDrawerOpen.value = true
}

function openEditDataset(ds: MlDataset) {
  editingDataset.value = ds
  datasetDrawerOpen.value = true
}

async function duplicateDataset(ds: MlDataset) {
  try {
    await datasetsApi.create({
      name: ds.name + ' (copy)',
      description: ds.description,
      pointKeys: ds.pointKeys,
      samplingIntervalSecs: ds.samplingIntervalSecs,
      windowSecs: ds.windowSecs,
      missingValues: ds.missingValues,
      normalization: ds.normalization,
      excludeBadQuality: ds.excludeBadQuality,
      removeOutliers: ds.removeOutliers,
      outlierMethod: ds.removeOutliers ? ds.outlierMethod : undefined,
      outputFormat: ds.outputFormat,
    })
    await loadDatasets()
  } catch { /* error handled by interceptor */ }
}

function deleteDataset(id: string) {
  Modal.confirm({
    title: 'Delete this dataset?',
    okType: 'danger',
    okText: 'Delete',
    async onOk() {
      await datasetsApi.remove(id)
      await loadDatasets()
    },
  })
}

function onDatasetSaved() {
  loadDatasets()
}


function formatInterval(secs: number): string {
  if (secs < 60) return `${secs}s`
  if (secs < 3600) return `${secs / 60}m`
  return `${secs / 3600}h`
}

function downloadCsv(rows: PointRow[], filename: string) {
  const quote = (v: unknown) => '"' + String(v ?? '').replace(/"/g, '""') + '"'
  const data = rows.map(p => [
    protocolLabel(p.protocol), sourceName(p), deviceName(p), pointName(p), originalName(p),
    valueText(p.value), p.unit || '', p.quality || '', p.timestamp, p.destinationName
  ])
  const header = ['Protocol','Source','Device','Point','Original','Value','Unit','Quality','Timestamp','Destination']
  const csv = '\uFEFF' + [header, ...data].map(r => r.map(quote).join(',')).join('\r\n')
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }))
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  link.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}
function exportViewCsv(view: SavedView) {
  const viewKeys = new Set(view.pointKeys.map(normalizeDataExplorerPointKey))
  const viewPoints = points.value.filter(p => matchesDataExplorerView(p, viewKeys))
  downloadCsv(viewPoints, `${view.name.replace(/[^a-zA-Z0-9_-]/g, '_')}.csv`)
}
const badCount = computed(() => points.value.filter(p => p.quality === 'BAD').length)
const staleCount = computed(() => points.value.filter(p => isStale(p.timestamp)).length)
function sortOrderFor(key: string) { return tableSortField.value === key ? tableSortOrder.value : null }
const columns = computed<TableColumnType<PointRow>[]>(() => {
  const cols: TableColumnType<PointRow>[] = []
  cols.push(
    { title: 'Protocol', key: 'protocol', width: 105 },
    { title: 'Source', key: 'source', width: 180, ellipsis: true, sorter: true, sortOrder: sortOrderFor('source') },
    { title: 'Device', key: 'device', width: 180, ellipsis: true, sorter: true, sortOrder: sortOrderFor('device') },
    { title: 'Point', key: 'point', width: 320, ellipsis: true, sorter: true, sortOrder: sortOrderFor('point') },
    { title: 'Latest Value', key: 'value', width: 135, sorter: true, sortOrder: sortOrderFor('value') },
    { title: 'Unit', key: 'unit', width: 115, ellipsis: true },
    { title: 'Quality', key: 'quality', width: 105 },
    { title: 'Updated', key: 'updated', width: 110, sorter: true, sortOrder: sortOrderFor('updated') },
    { title: 'Destination', dataIndex: 'destinationName', key: 'destinationName', width: 150, ellipsis: true },
    { title: '', key: 'action', width: 125 },
  )
  return cols
})
const viewColumns: TableColumnType<SavedView>[] = [
  { title: 'Name', key: 'name', ellipsis: true },
  { title: 'Points', key: 'points', width: 80 },
  { title: 'Actions', key: 'actions', width: 200, fixed: 'right' },
]
const datasetColumns: TableColumnType<MlDataset>[] = [
  { title: 'Name', key: 'name', ellipsis: true },
  { title: 'Points', key: 'points', width: 80 },
  { title: 'Sampling', key: 'sampling', width: 100 },
  { title: 'Window', key: 'window', width: 100 },
  { title: 'Format', key: 'format', width: 90 },
  { title: 'Updated', key: 'updated', width: 110 },
  { title: 'Actions', key: 'actions', width: 130, fixed: 'right' },
]

function onTableChange(_pagination: unknown, _filters: unknown, sorter: { field?: string; columnKey?: string; order?: 'ascend' | 'descend' | null }) {
  if (!sorter || (!sorter.columnKey && !sorter.field)) return
  const key = sorter.columnKey as string || sorter.field as string || null
  tableSortField.value = sorter.order ? key : null
  tableSortOrder.value = sorter.order ?? null
}
async function loadSourceMetadata() {
  try {
    const [deviceResponse, endpointRows] = await Promise.all([
      client.get<{ devices: DeviceRecord[] }>('/v1/devices'),
      sourcesApi.getAll(),
    ])
    devices.value = deviceResponse.data.devices
    sources.value = endpointRows
    metadataError.value = ''
  } catch {
    metadataError.value = 'Unable to refresh source and device names. Showing the last available names.'
  }
}
async function poll() {
  if (busy) return
  busy = true
  refreshing.value = true
  try {
    const refreshMetadata = Date.now() >= nextMetadataRefresh
    if (refreshMetadata) nextMetadataRefresh = Date.now() + 30000
    const [subs, readings, overview] = await Promise.all([pipelineApi.getSubscriptions(), pipelineApi.getPoints(), pipelineApi.getOverview(), refreshMetadata ? loadSourceMetadata() : Promise.resolve()])
    subscriptions.value = subs
    latestReadings.value = readings
    observedPointCount.value = overview.activePoints
    error.value = ''
    lastSync.value = new Date().toLocaleTimeString()
    now.value = Date.now()
  } catch {
    error.value = 'Unable to refresh readings. Showing the last available data.'
  } finally {
    loading.value = false
    busy = false
    refreshing.value = false
  }
}
function openPointDrawer(row: PointRow) { selected.value = row; drawerOpen.value = true }
function openHistory(row: PointRow) { historyPoint.value = row; historyOpen.value = true }
function resetFilters() { search.value = ''; protocolFilter.value = undefined; sourceFilter.value = undefined; qualityFilter.value = undefined }
watch(points, () => {
  if (selected.value) selected.value = points.value.find(p => p.key === selected.value?.key) || selected.value
})
onMounted(async () => {
  let savedTabs: string | null = null
  try { savedTabs = localStorage.getItem('iot-explorer-tabs') } catch {}
  try {
    const saved = JSON.parse(localStorage.getItem('iot-explorer-favorites') || '[]')
    if (Array.isArray(saved)) {
      favorites.value = saved.filter((v): v is string => typeof v === 'string' && v.includes('::') && !v.startsWith('['))
      if (favorites.value.length !== saved.length) persistFavorites()
    }
  } catch { /* ignore invalid preferences */ }
  try {
    const saved = JSON.parse(localStorage.getItem('iot-explorer-pinned') || '[]')
    if (Array.isArray(saved)) pinnedKeys.value = saved.filter((v): v is string => typeof v === 'string')
  } catch { /* ignore invalid preferences */ }
  try {
    const savedCache = JSON.parse(localStorage.getItem('iot-explorer-pin-cache') || '{}')
    for (const [key, point] of Object.entries(savedCache)) {
      if (pinnedKeys.value.includes(key) && point && typeof point === 'object' && (point as PointRow).key === key) {
        pinnedPointCache.value.set(key, point as PointRow)
      }
    }
  } catch { /* ignore invalid cache */ }
  try {
    const savedCache = JSON.parse(localStorage.getItem('iot-explorer-fav-cache') || '{}')
    for (const [k, v] of Object.entries(savedCache)) {
      if (favorites.value.includes(k) && v && typeof v === 'object') favPointCache.value.set(k, v as PointRow)
    }
  } catch { /* ignore invalid cache */ }
  loadDatasets()
  await loadViews()
  if (viewsLoaded) {
    const restored = restoreDataExplorerTabs(savedTabs, savedViews.value.map(view => view.id))
    activeTab.value = restored.activeTab
    openViewIds.value = restored.openViewIds
    persistViewTabs()
  }
  await poll()
  for (const p of points.value) {
    const fk = favKey(p)
    if (favorites.value.includes(fk)) favPointCache.value.set(fk, p)
  }
  persistFavorites()
  timer = setInterval(() => { now.value = Date.now(); if (!paused.value) poll() }, POLL_MS)
})
onUnmounted(() => { if (timer) clearInterval(timer) })
</script>

<template>
  <AppLayout title="Data">
    <div class="explorer">

      <div class="heading">
        <p>Search, inspect and export the latest readings across your connected sources.</p>
      </div>
      <a-alert v-if="error"  type="warning" show-icon :message="error" style="margin-bottom: 14px" />
      <a-alert v-if="metadataError" type="warning" show-icon :message="metadataError" style="margin-bottom: 14px" />
      <a-row :gutter="12" class="stats">
        <a-col :xs="12" :md="6"><a-card size="small" class="metric-card" data-testid="stat-observed-points"><div class="metric-inner"><span class="metric-icon icon-points"><BarChartOutlined /></span><a-statistic title="Observed points" :value="observedPointCount" /></div></a-card></a-col>
        <a-col :xs="12" :md="6"><a-card size="small" class="metric-card" data-testid="stat-subscriptions"><div class="metric-inner"><span class="metric-icon icon-subscriptions"><WifiOutlined /></span><a-statistic title="Active subscriptions" :value="subscriptions.length" /></div></a-card></a-col>
        <a-col :xs="12" :md="6"><a-card size="small" class="metric-card"><div class="metric-inner"><span class="metric-icon icon-quality"><WarningOutlined /></span><a-statistic title="Bad quality" :value="badCount" /></div></a-card></a-col>
        <a-col :xs="12" :md="6"><a-card size="small" class="metric-card"><div class="metric-inner"><span class="metric-icon icon-stale"><ClockCircleOutlined /></span><a-statistic title="No update in 60s" :value="staleCount" /></div></a-card></a-col>
      </a-row>
      <a-card size="small" class="browser-card">
        <div class="filters">
          <a-input v-model:value="search" data-testid="data-search" placeholder="Search source, device, point, destination…" allow-clear class="search" />
          <a-select v-model:value="protocolFilter" :options="protocolOptions" placeholder="All protocols" allow-clear class="filter" />
          <a-select v-model:value="sourceFilter" :options="sourceOptions" show-search option-filter-prop="label" placeholder="All sources" allow-clear class="filter" />
          <a-select v-model:value="qualityFilter" placeholder="All states" allow-clear class="filter">
            <a-select-option value="GOOD">Good / current</a-select-option>
            <a-select-option value="BAD">Bad quality</a-select-option>
            <a-select-option value="STALE">No update in 60s</a-select-option>
          </a-select>
          <a-button data-testid="data-clear-filters" @click="resetFilters">Clear</a-button>
          <div class="filters-actions">
            <a-button data-testid="data-pause" @click="paused = !paused">
              <PauseOutlined v-if="!paused" />
              <PlayCircleOutlined v-else />
              {{ paused ? 'Resume' : 'Pause' }}
            </a-button>
            <a-button data-testid="data-refresh" @click="poll"><ReloadOutlined :spin="refreshing" /> Refresh</a-button>
            <a-button class="save-view-button" @click="openCreateView(false)"><SaveOutlined /> Add View</a-button>
            <a-button type="primary" :disabled="!filteredPoints.length" @click="openCreateDataset()"><DatabaseOutlined /> Add Dataset</a-button>
          </div>
        </div>
        <div class="views-bar">
          <div class="views-list">
            <button type="button" data-testid="data-tab-live" :class="['view-tab', { active: activeTab === 'all' }]" @click="activateTab('all')">Live ({{ livePointCount }})</button>
            <button type="button" data-testid="data-tab-favorites" :class="['view-tab', { active: activeTab === 'favorites' }]" @click="activateTab('favorites')"> Favorites ({{ favoriteCount }})</button>
            <div v-for="view in savedViews.filter(v => openViewIds.includes(v.id))" :key="view.id" :class="['saved-view-tab', { active: activeTab === view.id }]">
              <button type="button" @click="activateTab(view.id)">{{ view.name }} ({{ new Set(view.pointKeys.map(normalizeDataExplorerPointKey)).size }})</button>
              <button type="button" class="close-view" :aria-label="`Close ${view.name} tab`" @click="closeSavedView(view.id)"><CloseOutlined /></button>
            </div>
            <button type="button" data-testid="data-tab-views" :class="['view-tab', { active: activeTab === 'views' }]" @click="activateTab('views')">Views ({{ savedViews.length }})</button>
            <button type="button" data-testid="data-tab-datasets" :class="['view-tab', { active: activeTab === 'datasets' }]" @click="activateTab('datasets')">Datasets ({{ datasets.length }})</button>
          </div>
        </div>
        <a-alert v-if="viewError" type="warning" show-icon :message="viewError" style="margin-bottom: 10px" />
        <a-alert v-if="activeSavedView && missingViewCount" type="info" show-icon :message="`${missingViewCount} saved point(s) are not in the recent sample. They remain saved in this view.`" style="margin-bottom: 10px" />
        <div class="table-meta">
          <div></div>
          <span class="toolbar-info" data-testid="data-toolbar-info">Showing {{ activeTab === 'datasets' ? datasets.length + ' datasets' : activeTab === 'views' ? savedViews.length + ' views' : filteredPoints.length + ' points' }}<template v-if="lastSync"> · Last sync {{ lastSync }}</template></span>
        </div>

        <!-- Views tab content -->
        <template v-if="activeTab === 'views'">
          <a-table :columns="viewColumns" :data-source="savedViews" :loading="viewsLoading" row-key="id" size="small" :pagination="{ pageSize: 20, showSizeChanger: true, pageSizeOptions: ['10', '20', '50'] }">
            <template #bodyCell="{ column, record: view }">
              <template v-if="column.key === 'name'">
                <div class="point-primary" style="font-weight: 400">{{ view.name }}</div>
                <div v-if="view.description" class="point-secondary">{{ view.description }}</div>
              </template>
              <template v-else-if="column.key === 'points'">{{ new Set(view.pointKeys.map(normalizeDataExplorerPointKey)).size }}</template>
              <template v-else-if="column.key === 'actions'">
                <a-space>
                  <a-tooltip title="Open"><a-button size="small" @click="openSavedView(view.id)"><template #icon><BarChartOutlined /></template></a-button></a-tooltip>
                  <a-tooltip title="Export CSV"><a-button size="small" @click="exportViewCsv(view)"><template #icon><DownloadOutlined /></template></a-button></a-tooltip>
                  <a-tooltip title="Edit"><a-button size="small" @click="openEditView(view)"><template #icon><EditOutlined /></template></a-button></a-tooltip>
                  <a-popconfirm title="Delete this saved view permanently?" ok-text="Delete" @confirm="deleteSavedView(view.id)"><a-button size="small" danger><template #icon><DeleteOutlined /></template></a-button></a-popconfirm>
                </a-space>
              </template>
            </template>
            <template #emptyText>No saved views yet — filter points and click Save as View.</template>
          </a-table>
        </template>

        <!-- Datasets tab content -->
        <template v-else-if="activeTab === 'datasets'">
          <a-table :columns="datasetColumns" :data-source="datasets" :loading="datasetsLoading" row-key="id" size="small" :pagination="{ pageSize: 20, showSizeChanger: true, pageSizeOptions: ['10', '20', '50'] }">
            <template #bodyCell="{ column, record: ds }">
              <template v-if="column.key === 'name'">
                <div class="point-primary" style="font-weight: 400">{{ ds.name }}</div>
                <div v-if="ds.description" class="point-secondary">{{ ds.description }}</div>
              </template>
              <template v-else-if="column.key === 'points'">{{ ds.pointKeys.length }}</template>
              <template v-else-if="column.key === 'sampling'">{{ formatInterval(ds.samplingIntervalSecs) }}</template>
              <template v-else-if="column.key === 'window'">{{ formatInterval(ds.windowSecs) }}</template>
              <template v-else-if="column.key === 'format'"><a-tag>{{ ds.outputFormat }}</a-tag></template>
              <template v-else-if="column.key === 'updated'"><span class="age">{{ age(ds.updatedAt) }}</span></template>
              <template v-else-if="column.key === 'actions'">
                <a-space>
                  <a-tooltip title="Edit"><a-button size="small" @click="openEditDataset(ds)"><template #icon><EditOutlined /></template></a-button></a-tooltip>
                  <a-tooltip title="Duplicate"><a-button size="small" @click="duplicateDataset(ds)"><template #icon><CopyOutlined /></template></a-button></a-tooltip>
                  <a-tooltip title="Delete"><a-button size="small" danger @click="deleteDataset(ds.id)"><template #icon><DeleteOutlined /></template></a-button></a-tooltip>
                </a-space>
              </template>
            </template>
            <template #emptyText>No datasets yet — select points and click Create Dataset.</template>
          </a-table>
        </template>

        <!-- Points table -->
        <a-table v-else :columns="columns" :data-source="filteredPoints" :loading="loading" row-key="key" :row-selection="rowSelection" :customRow="(record: PointRow) => ({ onClick: (e: MouseEvent) => { if (!(e.target as HTMLElement).closest('.ant-checkbox-wrapper')) openPointDrawer(record) }, style: 'cursor: pointer' })" size="small" :pagination="{ pageSize, showSizeChanger: true, pageSizeOptions: ['10', '20', '50'], onShowSizeChange: (_: number, size: number) => { pageSize = size } }" :scroll="{ x: 1570 }" table-layout="fixed" @change="onTableChange">
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'protocol'"><a-tag :color="protocolColor(record.protocol)">{{ protocolLabel(record.protocol) }}</a-tag></template>
            <template v-else-if="column.key === 'source'">{{ sourceName(record) }}</template>
            <template v-else-if="column.key === 'device'">{{ deviceName(record) }}</template>
            <template v-else-if="column.key === 'point'"><div class="point-primary" data-testid="point-name" :title="pointName(record)">{{ pointName(record) }}</div><div v-if="record.normalizedName && originalName(record) !== pointName(record)" class="point-secondary" :title="originalName(record)">Original: {{ originalName(record) }}</div></template>
            <template v-else-if="column.key === 'value'"><a-tag v-if="record.quality === 'BAD' && record.value == null" color="red">No Value</a-tag><span v-else>{{ valueText(record.value) }}</span></template>
            <template v-else-if="column.key === 'unit'">{{ record.unit || '—' }}</template>
            <template v-else-if="column.key === 'quality'"><a-tag v-if="record.quality === 'BAD'" color="red">BAD</a-tag><a-tag v-else-if="isStale(record.timestamp)" color="orange">STALE</a-tag><a-tag v-else color="green">{{ record.quality || 'CURRENT' }}</a-tag></template>
            <template v-else-if="column.key === 'updated'"><span :class="isStale(record.timestamp) ? 'age stale' : 'age'"><i class="status-dot"></i>{{ age(record.timestamp) }}</span></template>
            <template v-else-if="column.key === 'action'"><a-button type="link" size="small" title="History" aria-label="History" style="color:#722ed1" @click.stop="openHistory(record)"><template #icon><LineChartOutlined /></template></a-button><a-button type="text" size="small" :title="favorites.includes(favKey(record)) ? 'Remove from Favorites' : 'Add to Favorites'" :aria-label="favorites.includes(favKey(record)) ? 'Remove from Favorites' : 'Add to Favorites'" @click.stop="toggleFavorite(favKey(record))"><span :class="favorites.includes(favKey(record)) ? 'star active' : 'star'">{{ favorites.includes(favKey(record)) ? '★' : '☆' }}</span></a-button><a-button type="text" size="small" :title="pinnedKeys.includes(record.key) ? 'Unpin — remove this point from the Live grid when it is no longer updating' : 'Pin — keep this point in the Live grid across refreshes'" :aria-label="pinnedKeys.includes(record.key) ? 'Unpin point' : 'Pin point'" :class="{ 'pin-active': pinnedKeys.includes(record.key) }" @click.stop="togglePin(record)"><template #icon><PushpinFilled v-if="pinnedKeys.includes(record.key)" /><PushpinOutlined v-else /></template></a-button></template>
          </template>
          <template #emptyText>No matching recent readings. Check your source, subscription, and destination configuration.</template>
        </a-table>
      </a-card>
      <p class="note">This view uses the latest reading per point plus subscription snapshots. It is not a historical archive. “Stale” means no observed update for 60 seconds, not necessarily a device failure.</p>
    </div>
    <CreateViewDrawer
      v-model:open="viewDrawerOpen"
      :point-rows="selectedPointKeys.length ? candidateViewPoints : filteredPoints"
      :editing-view="editingView"
      @saved="onViewSaved"
    />
    <PointDetailsDrawer
      :open="drawerOpen"
      :point="selected"
      :source-name="selected ? sourceName(selected) : ''"
      :device-name="selected ? deviceName(selected) : ''"
      :now="now"
      @update:open="drawerOpen = $event"
    />
    <PointHistoryModal v-model:open="historyOpen" :point="historyPoint" />
    <CreateDatasetDrawer
      v-model:open="datasetDrawerOpen"
      :point-rows="candidateDatasetPoints"
      :editing-dataset="editingDataset"
      @saved="onDatasetSaved"
    />
  </AppLayout>
</template>

<style scoped>
.explorer { padding: 2px 0 24px; }
.metric-inner { display: flex; align-items: center; gap: 15px; min-height: 66px; }
.metric-icon { width: 50px; height: 50px; flex-shrink: 0; border-radius: 14px; display: inline-flex; align-items: center; justify-content: center; font-size: 23px; }
.icon-points, .icon-subscriptions, .icon-stale { background: var(--icon-bg-blue); color: #1677ff; }
.icon-quality { background: var(--icon-bg-red); color: #f04452; }
.metric-card :deep(.ant-statistic-title) { color: var(--text-tertiary); }
.metric-card :deep(.ant-statistic-content) { font-size: 23px; }
.save-view-button { color: #1677ff; border-color: #1677ff; }
.views-bar { display: flex; justify-content: space-between; align-items: center; gap: 12px; border-bottom: 1px solid var(--border-color); margin: 8px 0 12px; }
.views-list { display: flex; align-items: stretch; gap: 4px; overflow-x: auto; min-width: 0; }
.view-tab, .saved-view-tab { background: transparent; color: var(--text-primary); border: 0; border-bottom: 2px solid transparent; padding: 10px 12px; font: inherit; white-space: nowrap; cursor: pointer; }
.view-tab.active, .saved-view-tab.active { color: #1677ff; border-bottom-color: #1677ff; }
.saved-view-tab { display: flex; gap: 10px; align-items: center; }
.saved-view-tab button { color: inherit; background: none; border: 0; cursor: pointer; padding: 0; font: inherit; }
.saved-view-tab .close-view { color: var(--text-tertiary); }
.table-meta { display: flex; justify-content: space-between; align-items: center; min-height: 28px; margin-bottom: 10px; gap: 8px; }
@media (max-width: 850px) { .views-bar { align-items: flex-start; flex-direction: column; } .metric-inner { gap: 8px; } .metric-icon { width: 38px; height: 38px; } }

.eyebrow { font-size: 10px; letter-spacing: 1.3px; font-weight: 700; color: var(--text-tertiary); margin-bottom: 7px; }
.header-actions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.browser-heading { display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px; }
.browser-heading h3 { font-size: 15px; margin: 0 0 3px; font-weight: 650; }
.browser-heading span { color: var(--text-tertiary); font-size: 11px; }
.browser-count { background: var(--bg-subtle); border-radius: 20px; padding: 5px 12px; }
.star { font-size: 21px; color: var(--text-muted); }
.star.active { color: #e2a42c; }
.pin-active { color: #1677ff; }
.age { display: inline-flex; align-items: center; gap: 7px; white-space: nowrap; }
.status-dot { width: 7px; height: 7px; border-radius: 50%; background: #3cb77d; display: inline-block; }
.age.stale .status-dot { background: #ed9a38; }
.stats :deep(.ant-card) { border-radius: 9px; border-color: var(--border-color-card); background: var(--bg-subtle); }
.stats :deep(.ant-card-body) { padding: 17px 18px; }
.browser-card { border-radius: 9px; }
.browser-card :deep(.ant-table-thead > tr > th) { background: var(--bg-table-header); font-size: 12px; font-weight: 650; }
.browser-card :deep(.ant-table-tbody > tr:hover > td) { background: var(--bg-table-hover); }
@media (max-width: 900px) { .heading { align-items: flex-start; flex-direction: column; } }
.heading { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 16px; }
.heading p { color: var(--text-tertiary); margin: 0; }
.stats { margin-bottom: 14px; }
.filters { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; margin-bottom: 12px; }
.search { width: 240px; flex-shrink: 0; }
.filter { width: 160px; flex-shrink: 0; }
.filter :deep(.ant-select) { width: 100% !important; }
.filters-actions { display: flex; gap: 8px; margin-left: auto; flex-shrink: 0; }
.toolbar-info { color: var(--text-tertiary); font-size: 12px; }
.note { color: var(--text-tertiary); font-size: 12px; margin-top: 12px; }
.point-primary { font-size: 13px; font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.point-secondary { color: var(--text-tertiary); font-size: 11px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

</style>
