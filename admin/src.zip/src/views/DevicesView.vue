<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { message, Modal } from 'ant-design-vue'
import { CheckCircleOutlined, StopOutlined, DeleteOutlined } from '@ant-design/icons-vue'
import type { TableColumnType } from 'ant-design-vue'
import AppLayout from '@/components/layout/AppLayout.vue'
import DeviceDrawer from '@/components/devices/DeviceDrawer.vue'
import { client } from '@/api/client'
import { protocolColor, protocolLabel } from '@/utils/protocol'

interface Device {
  uuid: string
  name: string
  protocol: string
  enabled: boolean
  identifier: string | null
  metadata?: Record<string, any>
  assetPath?: string | null
  lastSeenAt: string | null
  created_at: string
}

const rows = ref<Device[]>([])
const loading = ref(false)
const activeProtocol = ref<string | undefined>(undefined)
const search = ref('')
let refreshTimer: ReturnType<typeof setInterval> | null = null

const selectedUuids = ref<string[]>([])
const deleting = ref(false)
const bulkEnabling = ref(false)
const bulkDisabling = ref(false)

const drawerOpen = ref(false)
const drawerDevice = ref<Device | null>(null)

function openDrawer(device: Device) {
  drawerDevice.value = device
  drawerOpen.value = true
}

async function onDrawerSaved() {
  await load()
  if (drawerDevice.value) {
    const fresh = rows.value.find(d => d.uuid === drawerDevice.value!.uuid)
    if (fresh) drawerDevice.value = fresh
  }
}

const rowSelection = computed(() => ({
  selectedRowKeys: selectedUuids.value,
  onChange: (keys: string[]) => { selectedUuids.value = keys },
}))

const filtered = computed(() => rows.value.filter(d => {
  const q = search.value.trim().toLowerCase()
  const name = (d.metadata?.objectName as string | undefined) || d.name
  return (!q || [name, d.name, d.protocol, d.identifier].some(v => (v || '').toLowerCase().includes(q)))
    && (!activeProtocol.value || d.protocol === activeProtocol.value)
}))

const protocolOptions = computed(() => [...new Set(rows.value.map(d => d.protocol))].sort()
  .map(v => ({ value: v, label: protocolLabel(v) })))

function clearFilters() { search.value = ''; activeProtocol.value = undefined }

const columns: TableColumnType[] = [
  { title: 'Name',       key: 'name',       ellipsis: true, sorter: (a: Device, b: Device) => ((a.metadata?.objectName as string) || a.name).localeCompare((b.metadata?.objectName as string) || b.name) },
  { title: 'Protocol',   key: 'protocol',   width: 110, sorter: (a: Device, b: Device) => a.protocol.localeCompare(b.protocol) },
  { title: 'Identifier', key: 'identifier', width: 160, ellipsis: true },
{ title: 'Last Seen',  key: 'lastSeen',   width: 130, sorter: (a: Device, b: Device) => (new Date(a.lastSeenAt || 0).getTime()) - (new Date(b.lastSeenAt || 0).getTime()) },
  { title: 'Status',     key: 'status',     width: 110 },
]

async function load() {
  loading.value = true
  try {
    const { data } = await client.get<{ devices: Device[] }>('/v1/devices')
    rows.value = data.devices ?? []
  } finally {
    loading.value = false
  }
}

function timeSince(ts: string | null): string {
  if (!ts) return '—'
  const diff = Math.floor((Date.now() - new Date(ts).getTime()) / 1000)
  if (isNaN(diff) || diff < 0) return '—'
  if (diff < 5)    return 'just now'
  if (diff < 60)   return `${diff}s ago`
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`
  return `${Math.floor(diff / 86400)}d ago`
}

function deviceStatus(d: Device): { label: string; color: string } {
  if (!d.enabled) return { label: 'Disabled', color: 'default' }
  if (!d.lastSeenAt) return { label: 'Pending', color: 'gold' }
  const age = (Date.now() - new Date(d.lastSeenAt).getTime()) / 1000
  if (age < 300)  return { label: 'Active',   color: 'green' }
  if (age < 3600) return { label: 'Stale',    color: 'orange' }
  return { label: 'Inactive', color: 'red' }
}

function identifierLabel(d: Device): string {
  if (d.identifier) return d.identifier
  if (d.metadata?.slaveId != null) return `Slave ${d.metadata.slaveId}`
  return '—'
}

function confirmDeleteSelected() {
  const count = selectedUuids.value.length
  Modal.confirm({
    title: `Delete ${count} device${count !== 1 ? 's' : ''}?`,
    content: 'Removed devices will reappear if the endpoint reconnects.',
    okType: 'danger',
    okText: `Delete ${count}`,
    async onOk() {
      deleting.value = true
      try {
        const results = await Promise.allSettled(selectedUuids.value.map((uuid) => client.delete(`/v1/devices/${uuid}`)))
        reportBulkResult(results, 'Deleted', 'delete')
        selectedUuids.value = []
        await load()
      } finally {
        deleting.value = false
      }
    },
  })
}

// Promise.allSettled never throws — without inspecting each result, a bulk
// action against a broken/missing endpoint silently "succeeds" with nothing
// actually changed. Surface real failures instead of a blanket success.
function reportBulkResult(results: PromiseSettledResult<unknown>[], verbPast: string, verbInf: string): void {
  const failed = results.filter((r) => r.status === 'rejected').length
  const ok = results.length - failed
  if (failed === 0) {
    message.success(`${verbPast} ${ok} device${ok !== 1 ? 's' : ''}`)
  } else if (ok === 0) {
    message.error(`Failed to ${verbInf} ${failed} device${failed !== 1 ? 's' : ''}`)
  } else {
    message.warning(`${verbPast} ${ok}, failed to ${verbInf} ${failed}`)
  }
}

async function bulkEnable() {
  const uuids = [...selectedUuids.value]
  bulkEnabling.value = true
  try {
    const results = await Promise.allSettled(uuids.map((uuid) => client.patch(`/v1/devices/${uuid}`, { enabled: true })))
    reportBulkResult(results, 'Enabled', 'enable')
    selectedUuids.value = []
    await load()
  } finally {
    bulkEnabling.value = false
  }
}

async function bulkDisable() {
  const uuids = [...selectedUuids.value]
  bulkDisabling.value = true
  try {
    const results = await Promise.allSettled(uuids.map((uuid) => client.patch(`/v1/devices/${uuid}`, { enabled: false })))
    reportBulkResult(results, 'Disabled', 'disable')
    selectedUuids.value = []
    await load()
  } finally {
    bulkDisabling.value = false
  }
}

onMounted(() => {
  load()
  refreshTimer = setInterval(load, 30_000)
})

onUnmounted(() => {
  if (refreshTimer) clearInterval(refreshTimer)
})
</script>

<template>
  <AppLayout title="Devices">
    <div class="heading">
      <p>Physical and logical devices discovered through protocol endpoints.</p>
      <div class="header-actions">
        <template v-if="selectedUuids.length > 0">
          <span style="font-size: 13px; color: var(--text-secondary)">{{ selectedUuids.length }} selected</span>
          <a-button :loading="bulkEnabling" @click="bulkEnable"><template #icon><CheckCircleOutlined /></template>Enable</a-button>
          <a-button :loading="bulkDisabling" @click="bulkDisable"><template #icon><StopOutlined /></template>Disable</a-button>
          <a-button danger :loading="deleting" @click="confirmDeleteSelected"><template #icon><DeleteOutlined /></template>Delete</a-button>
        </template>
        <a-button @click="load" :loading="loading">Refresh</a-button>
      </div>
    </div>

    <a-card size="small" class="list-card">
      <div class="filters">
        <a-input v-model:value="search" placeholder="Search name, protocol, identifier…" allow-clear class="search" />
        <a-select v-model:value="activeProtocol" :options="protocolOptions" placeholder="All protocols" allow-clear class="filter" />
        <a-button @click="clearFilters">Clear</a-button>
      </div>
      <div class="toolbar-info">Showing {{ filtered.length }} of {{ rows.length }} devices</div>
      <a-table
        :dataSource="filtered"
        :columns="columns"
        :loading="loading"
        :pagination="{ pageSize: 20, showSizeChanger: true, pageSizeOptions: ['10', '20', '50'] }"
        :row-selection="rowSelection"
        :customRow="(record: Device) => ({ onClick: (e: MouseEvent) => { if (!(e.target as HTMLElement).closest('.ant-checkbox-wrapper')) openDrawer(record) }, style: 'cursor: pointer' })"
        row-key="uuid"
        size="small"
      >
        <template #bodyCell="{ column, record }">

          <template v-if="column.key === 'name'">
            <span class="device-name" data-testid="device-name" :title="record.name">{{ record.metadata?.objectName || record.name }}</span>
          </template>

          <template v-else-if="column.key === 'protocol'">
            <a-tag :color="protocolColor(record.protocol)">
              {{ protocolLabel(record.protocol) }}
            </a-tag>
          </template>

          <template v-else-if="column.key === 'identifier'">
            <span>{{ identifierLabel(record) }}</span>
          </template>

<template v-else-if="column.key === 'lastSeen'">
            <span :class="['lastseen', record.lastSeenAt ? 'has-time' : 'no-time']">
              {{ timeSince(record.lastSeenAt) }}
            </span>
          </template>

          <template v-else-if="column.key === 'status'">
            <a-badge
              data-testid="device-status"
              :color="deviceStatus(record).color === 'green' ? '#52c41a' : deviceStatus(record).color === 'orange' ? '#fa8c16' : deviceStatus(record).color === 'red' ? '#ff4d4f' : deviceStatus(record).color === 'gold' ? '#faad14' : '#8c8c8c'"
              :text="deviceStatus(record).label"
            />
          </template>

        </template>

        <template #emptyText>
          <a-empty description="No devices yet">
            <template #description>
              <span>Devices appear here once endpoints connect and report data.</span><br>
              <a-typography-link href="/admin/#/endpoints">Go to Endpoints →</a-typography-link>
            </template>
          </a-empty>
        </template>
      </a-table>
    </a-card>

    <DeviceDrawer
      :open="drawerOpen"
      :device="drawerDevice"
      @update:open="drawerOpen = $event"
      @saved="onDrawerSaved"
    />
  </AppLayout>
</template>

<style scoped>
.heading { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 16px; }
.heading p { color: var(--text-tertiary); margin: 0; }
.header-actions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.list-card { border-radius: 9px; }
.list-card :deep(.ant-table-thead > tr > th) { background: var(--bg-table-header); font-size: 12px; font-weight: 650; }
.list-card :deep(.ant-table-tbody > tr:hover > td) { background: var(--bg-table-hover); }
.filters { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 12px; }
.search { width: 300px; max-width: 100%; }
.filter { width: 170px; max-width: 100%; }
.toolbar-info { color: var(--text-tertiary); font-size: 12px; margin-bottom: 10px; }

.device-name {
  font-weight: 400;
}

.lastseen {
  font-size: 12px;
}

.lastseen.has-time {
  color: var(--text-secondary);
}

.lastseen.no-time {
  color: var(--text-placeholder);
}
</style>
