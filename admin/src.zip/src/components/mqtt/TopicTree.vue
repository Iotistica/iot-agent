<script setup lang="ts">
import { ref, computed } from 'vue'
import type { TopicNode } from '@/api/mqtt'

const props = defineProps<{
  nodes: Record<string, TopicNode>
  selectedTopic: string | null
  depth?: number
  collapsed?: Set<string>
  lazy?: boolean
}>()

const emit = defineEmits<{
  (e: 'select', node: TopicNode): void
  (e: 'toggle', topic: string): void
}>()

const localCollapsed = ref(new Set<string>())
const collapsedSet = computed(() => props.collapsed ?? localCollapsed.value)

function toggle(topic: string) {
  if (props.collapsed) {
    emit('toggle', topic)
  } else {
    if (localCollapsed.value.has(topic)) {
      localCollapsed.value.delete(topic)
    } else {
      localCollapsed.value.add(topic)
    }
  }
}

function isExpanded(node: TopicNode) {
  return !collapsedSet.value.has(node.fullTopic)
}

const sorted = computed(() =>
  Object.values(props.nodes).sort((a, b) => {
    // Folders (children) before leaves, then alphabetical
    const aHasChildren = Object.keys(a.children).length > 0
    const bHasChildren = Object.keys(b.children).length > 0
    if (aHasChildren !== bHasChildren) return aHasChildren ? -1 : 1
    return a.name.localeCompare(b.name)
  }),
)

function hasChildren(node: TopicNode) {
  return Object.keys(node.children).length > 0 || (!!props.lazy && !!node.expandable)
}

function typeColor(t: string) {
  if (t === 'json') return '#52c41a'
  if (t === 'binary') return '#722ed1'
  return '#1677ff'
}

function fmtCount(n: number) {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`
  return String(n)
}
</script>

<template>
  <div class="topic-tree">
    <div
      v-for="node in sorted"
      :key="node.fullTopic"
      class="topic-node"
    >
      <!-- Leaf topic (has messages) -->
      <div
        v-if="lazy || node.count > 0 || !hasChildren(node)"
        class="topic-row"
        :class="{ selected: selectedTopic === node.fullTopic }"
        @click="emit('select', node)"
      >
        <span class="topic-indent" :style="{ width: `${(depth ?? 0) * 14}px` }" />
        <span class="topic-icon">
          <span
            v-if="hasChildren(node)"
            class="folder-icon"
            :class="{ collapsed: !isExpanded(node) }"
            @click.stop="toggle(node.fullTopic)"
          >▾</span>
          <span v-else class="leaf-icon" :style="{ background: typeColor(node.messageType) }" />
        </span>
        <span class="topic-name">{{ node.name }}</span>
        <span v-if="!lazy && node.count > 0" class="topic-count">{{ fmtCount(node.count) }}</span>
        <span v-if="node.loading" class="topic-count">Loading…</span>
        <span v-if="node.retain" class="topic-retain" title="Retained">R</span>
      </div>

      <!-- Folder label (no own messages, only has children) -->
      <div
        v-else
        class="topic-row topic-folder"
        @click="toggle(node.fullTopic)"
      >
        <span class="topic-indent" :style="{ width: `${(depth ?? 0) * 14}px` }" />
        <span class="topic-icon">
          <span class="folder-icon" :class="{ collapsed: !isExpanded(node) }">▾</span>
        </span>
        <span class="topic-name topic-name--dim">{{ node.name }}</span>
      </div>

      <!-- Recurse -->
      <TopicTree
        v-if="hasChildren(node) && isExpanded(node)"
        :nodes="node.children"
        :selected-topic="selectedTopic"
        :depth="(depth ?? 0) + 1"
        :collapsed="collapsedSet"
        :lazy="lazy"
        @select="emit('select', $event)"
        @toggle="toggle($event)"
      />
    </div>
  </div>
</template>

<style scoped>
.topic-tree {
  font-size: 12px;
}

.topic-row {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 3px 10px 3px 6px;
  cursor: pointer;
  border-radius: 4px;
  user-select: none;
  transition: background 0.1s;
}

.topic-row:hover {
  background: rgba(22, 119, 255, 0.08);
}

.topic-row.selected {
  background: rgba(22, 119, 255, 0.14);
  color: #1677ff;
}

.topic-folder {
  opacity: 0.7;
}

.topic-indent {
  display: inline-block;
  flex-shrink: 0;
}

.topic-icon {
  width: 14px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
}

.folder-icon {
  font-size: 11px;
  color: var(--text-muted);
  cursor: pointer;
  transition: transform 0.15s;
  display: inline-block;
}

.folder-icon.collapsed {
  transform: rotate(-90deg);
}

.leaf-icon {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  display: inline-block;
}

.topic-name {
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.topic-name--dim {
  color: var(--text-muted);
}

.topic-count {
  font-size: 10px;
  color: var(--text-muted);
  background: var(--bg-subtle);
  border-radius: 8px;
  padding: 0 5px;
  flex-shrink: 0;
}

.topic-retain {
  font-size: 9px;
  color: #fa8c16;
  font-weight: 700;
  flex-shrink: 0;
}
</style>
