<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import {
  DashboardOutlined,
  CloudUploadOutlined,
  PartitionOutlined,
  ApartmentOutlined,
  RadarChartOutlined,
  BellOutlined,
  FileTextOutlined,
  ContainerOutlined,
  SettingOutlined,
  TeamOutlined,
  SafetyOutlined,
  WifiOutlined,
  ClusterOutlined,
  DatabaseOutlined,
  CodeOutlined,
  NodeIndexOutlined,
  ShopOutlined,
  GlobalOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
} from '@ant-design/icons-vue'
import IotisticaLogo from '@/components/IotisticaLogo.vue'
import { useSidebar } from '@/composables/useSidebar'
import { useAuth } from '@/composables/useAuth'
import { useImageUpdates } from '@/composables/useImageUpdates'
import { useDockerStatus } from '@/composables/useDockerStatus'

const route = useRoute()
const router = useRouter()

const { collapsed, toggle } = useSidebar()
const { hasRole } = useAuth()
const { updateCount } = useImageUpdates()
const { dockerAvailable } = useDockerStatus()

const selectedKey = computed(() => route.path)

const openKeys = computed(() => {
  const keys: string[] = []
  if (route.path.startsWith('/admin')) keys.push('administration')
  return keys
})

function onMenuClick({ key }: { key: string }) {
  router.push(key)
}
</script>

<template>
  <a-layout-sider
    :width="252"
    :collapsed="collapsed"
    :collapsed-width="64"
    collapsible
    :trigger="null"
    theme="dark"
    data-testid="sidebar"
    style="height: 100vh; background: #0a0a0a; display: flex; flex-direction: column; flex-shrink: 0;"
  >
    <div class="logo" :class="{ 'logo--collapsed': collapsed }">
      <div class="logo-row">
        <IotisticaLogo :size="36" />
        <template v-if="!collapsed">
          <span class="logo-title">Iotistica Edge</span>
        </template>
      </div>
    </div>

    <div class="nav-main">
      <a-menu
        theme="dark"
        mode="inline"
        :inline-collapsed="collapsed"
        :selected-keys="[selectedKey]"
        :open-keys="openKeys"
        @click="onMenuClick"
      >
        <a-menu-item key="/dashboard">
          <template #icon><DashboardOutlined /></template>
          Dashboard
        </a-menu-item>

        <a-menu-item key="/sources">
          <template #icon><ApartmentOutlined /></template>
          Sources
        </a-menu-item>

        <a-menu-item key="/destinations">
          <template #icon><CloudUploadOutlined /></template>
          Destinations
        </a-menu-item>

        <a-menu-item key="/subscriptions">
          <template #icon><PartitionOutlined /></template>
          Subscriptions
        </a-menu-item>

        <a-menu-item key="/data-flow">
          <template #icon><NodeIndexOutlined /></template>
          Data
        </a-menu-item>

        <a-menu-item key="/devices">
          <template #icon><ClusterOutlined /></template>
          Devices
        </a-menu-item>

        <!-- Assets hidden for now — route still works, just not linked from the sidebar. -->

        <a-menu-item key="/discovery-rules">
          <template #icon><RadarChartOutlined /></template>
          Discovery
        </a-menu-item>

        <a-menu-item key="/applications">
          <template #icon><ContainerOutlined /></template>
          Applications
          <a-badge v-if="dockerAvailable && updateCount > 0" :count="updateCount" :number-style="{ backgroundColor: '#1677ff', fontSize: '10px', minWidth: '16px', height: '16px', lineHeight: '16px', boxShadow: 'none' }" class="sidebar-update-badge" />
        </a-menu-item>

        <a-menu-item key="/marketplace">
          <template #icon><ShopOutlined /></template>
          Marketplace
        </a-menu-item>

        <a-menu-item key="/anomaly">
          <template #icon><BellOutlined /></template>
          Analytics
        </a-menu-item>

        <a-menu-item key="/mqtt-broker">
          <template #icon><WifiOutlined /></template>
          MQTT
        </a-menu-item>

        <a-menu-item key="/network">
          <template #icon><GlobalOutlined /></template>
          Network
        </a-menu-item>

        <a-menu-item key="/terminal">
          <template #icon><CodeOutlined /></template>
          Terminal
        </a-menu-item>

        <a-menu-item key="/logs">
          <template #icon><FileTextOutlined /></template>
          Logs
        </a-menu-item>

        <a-menu-item key="/settings">
          <template #icon><SettingOutlined /></template>
          Settings
        </a-menu-item>

        <a-sub-menu v-if="hasRole('admin')" key="administration">
          <template #icon><SafetyOutlined /></template>
          <template #title>Administration</template>

          <a-menu-item key="/admin/users">
            <template #icon><TeamOutlined /></template>
            Users
          </a-menu-item>

          <a-menu-item key="/admin/backups">
            <template #icon><DatabaseOutlined /></template>
            Backups
          </a-menu-item>
        </a-sub-menu>
      </a-menu>
    </div>


    <div class="sidebar-footer">
      <a-button type="text" size="small" class="collapse-btn" @click="toggle">
        <template #icon>
          <MenuUnfoldOutlined v-if="collapsed" />
          <MenuFoldOutlined v-else />
        </template>
      </a-button>
    </div>

  </a-layout-sider>
</template>

<style scoped>
.logo {
  height: var(--app-header-height, 72px);
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 4px;
  padding: 0 16px 0 30px;
  color: var(--text-primary);
  font-size: 20px;
  font-weight: 600;
  border-bottom: 1px solid var(--border-app-header);
  flex-shrink: 0;
  overflow: hidden;
  background: var(--bg-app-header);
}

.logo--collapsed {
  padding: 8px 0;
  align-items: center;
}

.logo--collapsed .logo-row {
  justify-content: center;
}

.logo-row {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}

.logo-title {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
  line-height: 1.3;
}

.nav-main {
  flex: 1;
  overflow-y: auto;
  background: #141414;
}

.sidebar-footer {
  flex-shrink: 0;
  padding: 8px;
  display: flex;
  justify-content: flex-end;
  border-top: 1px solid rgba(255, 255, 255, 0.08);
  background: #141414;
}

.collapse-btn {
  color: rgba(255, 255, 255, 0.45);
  font-size: 16px;
}

.collapse-btn:hover {
  color: #fff !important;
}

:deep(.ant-menu-dark),
:deep(.ant-menu-dark .ant-menu-sub),
:deep(.ant-menu-dark.ant-menu-inline) {
  background: #141414 !important;
}


:deep(.ant-layout-sider) {
  background: #0a0a0a !important;
}

:deep(.ant-layout-sider-children) {
  display: flex;
  flex-direction: column;
}


:deep(.ant-menu-dark .ant-menu-item:not(.ant-menu-item-selected):hover) {
  background: #111111 !important;
}

.sidebar-update-badge {
  margin-left: 6px;
}

.pro-badge {
  background: linear-gradient(135deg, #dc2626, #ef4444) !important;
  border: none !important;
  color: #fff !important;
  font-size: 9px !important;
  font-weight: 700 !important;
  letter-spacing: 0.06em !important;
  line-height: 14px !important;
  padding: 0 5px !important;
  height: 14px !important;
  margin-left: 6px !important;
  flex-shrink: 0 !important;
  white-space: nowrap !important;
  vertical-align: middle !important;
  border-radius: 3px !important;
}
</style>
