import { client } from './client'
import type {
  AnomalyAlert,
  AnomalyConfig,
  AnomalyStats,
  AnomalyBaseline,
  AnomalyRuleTemplate,
  EdgeAnomalyEvent,
  EdgeAnomalyIncident,
  EdgeAnomalyAlert,
  DriftRuleConfig,
  DriftRuleTemplate,
} from '@/types'

const BASE = '/v1/anomaly'

export type ResolutionReason = 'false_positive' | 'true_positive' | 'expected' | 'accepted'

export const RESOLUTION_REASON_LABELS: Record<ResolutionReason, string> = {
  false_positive: 'False Positive',
  true_positive: 'True Positive — Fixed',
  expected: 'Expected / Maintenance',
  accepted: 'Known / Accepted',
}

export type DriftAlertType = 'new-field' | 'missing-field' | 'type-drift' | 'rename-candidate'

// Mirrors src/publish/core/types.ts's DriftOptionsSchema (the shape saved to
// endpoint_outputs.drift_options_json and read by PublishManager at
// construction/reconfigure time) — kept as the single shared definition so
// AnomalyView.vue doesn't maintain its own drifted-apart copy.
export interface DriftOptions {
  enabled?: boolean
  warmupBatches?: number
  consecutiveMissingThreshold?: number
  alertCooldownMs?: number
  minFieldPresenceRatio?: number
  adaptiveRetireBatches?: number
  adaptiveRetireMs?: number
  alertOnDriftTypes?: DriftAlertType[]
  adaptivePromotionBatches?: number
  /** @deprecated No longer consulted by the detector — see adaptivePromotionMinElapsedMs. */
  adaptivePromotionRatio?: number
  adaptivePromotionMinElapsedMs?: number
  minTypeDominanceRatio?: number
  maxTrackedFields?: number
  maxTrackedDevices?: number
  maxTraversalDepth?: number
  maxFieldsPerBatch?: number
  maxRenameCandidates?: number
  maxRenameFieldLength?: number
  logSampleSize?: number
  checkIntervalBatches?: number
}

export interface ProtocolOutput {
  protocol: string
  drift_options?: DriftOptions | null
}

export interface BaselineProgress {
  metricName: string
  deviceState: string
  deviceId: string
  bufferSize: number
  windowSize: number
  configName?: string
}

export interface SchemaDriftBaselineRow {
  protocol: string
  device?: string
  field: string
  status: 'baseline' | 'pending'
  dominantType?: string
  missingStreak?: number
  stableBatches?: number
  /** Wall-clock ms since this candidate was first seen — see adaptivePromotionMinElapsedMs. */
  elapsedMs?: number
  updatedAt: string
}

export interface BadActor {
  metric: string
  device_name: string
  incident_count: number
  total_events: number
  critical_count: number
  warning_count: number
  info_count: number
  open_count: number
  resolved_count: number
  false_positive_count: number
  true_positive_count: number
  expected_count: number
  accepted_count: number
  unclassified_resolved_count: number
  last_seen: number
}

export const anomalyApi = {
  getConfig(): Promise<AnomalyConfig> {
    return client.get<{ config: AnomalyConfig }>(`${BASE}/config`).then((r) => r.data.config)
  },

  updateConfig(patch: Partial<AnomalyConfig>): Promise<AnomalyConfig> {
    return client
      .patch<{ config: AnomalyConfig }>(`${BASE}/config`, patch)
      .then((r) => r.data.config)
  },

  getAlerts(params?: {
    since?: number
    severity?: string
    metric?: string
    limit?: number
  }): Promise<{ alerts: AnomalyAlert[]; total: number }> {
    return client
      .get<{ alerts: AnomalyAlert[]; total: number }>(`${BASE}/alerts`, { params })
      .then((r) => r.data)
  },

  clearAlerts(): Promise<void> {
    return client.delete(`${BASE}/alerts`).then(() => undefined)
  },

  getStats(): Promise<{
    stats: AnomalyStats
    scores: Record<string, number>
    predictions: Record<string, unknown> | null
  }> {
    return client.get(`${BASE}/stats`).then((r) => r.data)
  },

  getBaselines(params?: {
    metric?: string
    limit?: number
  }): Promise<{ baselines: AnomalyBaseline[]; total: number }> {
    return client
      .get<{ baselines: AnomalyBaseline[]; total: number }>(`${BASE}/baselines`, { params })
      .then((r) => r.data)
  },

  getBaselineProgress(): Promise<BaselineProgress[]> {
    return client.get<{ progress: BaselineProgress[] }>(`${BASE}/baseline-progress`).then((r) => r.data.progress)
  },

  clearBaselines(): Promise<{ deleted: number }> {
    return client.delete<{ deleted: number }>(`${BASE}/baselines`).then((r) => r.data)
  },

  getSchemaDriftBaselines(params?: { q?: string }): Promise<{ baselines: SchemaDriftBaselineRow[]; total: number }> {
    return client
      .get<{ baselines: SchemaDriftBaselineRow[]; total: number }>('/v1/schema-drift/baselines', { params })
      .then((r) => r.data)
  },

  clearSchemaDriftBaselines(): Promise<{ deleted: number }> {
    return client.delete<{ deleted: number }>('/v1/schema-drift/baselines').then((r) => r.data)
  },

  getProtocolOutputs(): Promise<{ outputs: ProtocolOutput[] }> {
    return client.get<{ outputs: ProtocolOutput[] }>('/v1/protocol-outputs').then((r) => r.data)
  },

  // Applies to every configured protocol pipe — the one control surface
  // operators use (see src/api/v1.ts's PATCH /v1/protocol-outputs/drift).
  // Now also live-reconfigures the already-running agent server-side, no
  // restart required.
  updateDrift(driftOptions: DriftOptions | null): Promise<{ outputs: ProtocolOutput[] }> {
    return client
      .patch<{ outputs: ProtocolOutput[] }>('/v1/protocol-outputs/drift', { drift_options: driftOptions })
      .then((r) => r.data)
  },

  // ── Edge tracking ────────────────────────────────────────────────────────────

  getEdgeEvents(params?: { severity?: string; limit?: number; offset?: number }): Promise<{ events: EdgeAnomalyEvent[]; total: number }> {
    return client.get<{ events: EdgeAnomalyEvent[]; total: number }>('/v1/anomaly-events', { params }).then((r) => r.data)
  },

  getEdgeIncidents(params?: { status?: string; limit?: number; offset?: number }): Promise<{ incidents: EdgeAnomalyIncident[]; total: number }> {
    return client.get<{ incidents: EdgeAnomalyIncident[]; total: number }>('/v1/anomaly-incidents', { params }).then((r) => r.data)
  },

  getEdgeIncidentStats(): Promise<{ open: number; active: number; resolved: number; total: number }> {
    return client.get<{ open: number; active: number; resolved: number; total: number }>('/v1/anomaly-incidents/stats').then((r) => r.data)
  },

  resolveIncident(incidentId: string, reason?: ResolutionReason, notes?: string): Promise<void> {
    return client.patch(`/v1/anomaly-incidents/${incidentId}/resolve`, { reason, notes }).then(() => undefined)
  },

  getBadActors(params?: { windowDays?: number; limit?: number }): Promise<{ badActors: BadActor[]; windowDays: number }> {
    return client.get<{ badActors: BadActor[]; windowDays: number }>('/v1/anomaly-incidents/bad-actors', { params }).then((r) => r.data)
  },

  getEdgeAlerts(params?: { limit?: number; offset?: number }): Promise<{ alerts: EdgeAnomalyAlert[]; total: number }> {
    return client.get<{ alerts: EdgeAnomalyAlert[]; total: number }>('/v1/anomaly-alerts', { params }).then((r) => r.data)
  },

  getPoints(): Promise<
    Array<{
      name: string
      deviceId?: string
      deviceName?: string
      score?: number
      deviceState?: string
      unit?: string
      configured: boolean
      endpointName?: string
      protocol?: string
    }>
  > {
    return client
      .get<{
        metrics: Array<{
          name: string
          deviceId?: string
          deviceName?: string
          score?: number
          deviceState?: string
          unit?: string
          configured: boolean
          endpointName?: string
          protocol?: string
        }>
      }>(`${BASE}/points`)
      .then((r) => r.data.metrics)
  },

  // ── Rule templates (custom, saved) ─────────────────────────────────────────────

  getTemplates(): Promise<AnomalyRuleTemplate[]> {
    return client.get<{ templates: AnomalyRuleTemplate[] }>(`${BASE}/templates`).then((r) => r.data.templates)
  },

  createTemplate(data: Omit<AnomalyRuleTemplate, 'uuid'>): Promise<AnomalyRuleTemplate> {
    return client
      .post<{ template: AnomalyRuleTemplate }>(`${BASE}/templates`, data)
      .then((r) => r.data.template)
  },

  updateTemplate(uuid: string, patch: Partial<Omit<AnomalyRuleTemplate, 'uuid'>>): Promise<AnomalyRuleTemplate> {
    return client
      .patch<{ template: AnomalyRuleTemplate }>(`${BASE}/templates/${uuid}`, patch)
      .then((r) => r.data.template)
  },

  deleteTemplate(uuid: string): Promise<void> {
    return client.delete(`${BASE}/templates/${uuid}`).then(() => undefined)
  },
}

// ── Schema Drift Rules API ─────────────────────────────────────────────────

const DRIFT_BASE = '/v1/schema-drift'

export const driftRulesApi = {
  getRules(): Promise<DriftRuleConfig[]> {
    return client.get<{ rules: DriftRuleConfig[] }>(`${DRIFT_BASE}/rules`).then((r) => r.data.rules)
  },

  createRule(data: Omit<DriftRuleConfig, 'id' | 'createdAt' | 'updatedAt'>): Promise<DriftRuleConfig> {
    return client.post<{ rule: DriftRuleConfig }>(`${DRIFT_BASE}/rules`, data).then((r) => r.data.rule)
  },

  updateRule(uuid: string, patch: Partial<DriftRuleConfig>): Promise<DriftRuleConfig> {
    return client.patch<{ rule: DriftRuleConfig }>(`${DRIFT_BASE}/rules/${uuid}`, patch).then((r) => r.data.rule)
  },

  deleteRule(uuid: string): Promise<void> {
    return client.delete(`${DRIFT_BASE}/rules/${uuid}`).then(() => undefined)
  },

  getTemplates(): Promise<DriftRuleTemplate[]> {
    return client.get<{ templates: DriftRuleTemplate[] }>(`${DRIFT_BASE}/templates`).then((r) => r.data.templates)
  },

  createTemplate(data: Omit<DriftRuleTemplate, 'uuid' | 'createdAt' | 'updatedAt'>): Promise<DriftRuleTemplate> {
    return client.post<{ template: DriftRuleTemplate }>(`${DRIFT_BASE}/templates`, data).then((r) => r.data.template)
  },

  updateTemplate(uuid: string, patch: Partial<DriftRuleTemplate>): Promise<DriftRuleTemplate> {
    return client.patch<{ template: DriftRuleTemplate }>(`${DRIFT_BASE}/templates/${uuid}`, patch).then((r) => r.data.template)
  },

  deleteTemplate(uuid: string): Promise<void> {
    return client.delete(`${DRIFT_BASE}/templates/${uuid}`).then(() => undefined)
  },
}
