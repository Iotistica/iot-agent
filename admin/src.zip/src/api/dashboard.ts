import { client } from './client'

export interface NetworkBandwidth {
  iface: string
  rx_sec: number
  tx_sec: number
  rx_bytes: number
  tx_bytes: number
}

export interface DashboardStats {
  cpu_usage: number
  memory_percent: number
  memory_used: number
  memory_total: number
  storage_percent: number | null
  storage_used: number | null
  storage_total: number | null
  uptime: number
  hostname: string
  network: NetworkBandwidth[]
}

export interface NormalizationIssue {
  label: string
  protocol: string | null
  count: number
  firstSeen: string
  lastSeen: string
}

export interface NormalizationIssueSummary {
  count: number
  items: NormalizationIssue[]
}

export interface NormalizationHealth {
  unknownUnits: NormalizationIssueSummary
  conversionFailures: NormalizationIssueSummary
}

export interface CanonicalUnit {
  canonical_unit: string
  quantity: string
  symbol: string | null
  description: string | null
}

export interface CustomUnitAlias {
  id: number
  source_system: string | null
  alias: string
  canonical_unit: string
}

export interface UnitSuggestion {
  canonical_unit: string
  symbol: string | null
  quantity: string
  score: number
  matchedVia: string
}

export const dashboardApi = {
  getStats(): Promise<DashboardStats> {
    return client.get<DashboardStats>('/v1/dashboard/stats').then((r) => r.data)
  },
  getNormalizationHealth(): Promise<NormalizationHealth> {
    return client.get<NormalizationHealth>('/v1/normalization-health').then((r) => r.data)
  },
  getCanonicalUnits(): Promise<CanonicalUnit[]> {
    return client.get<CanonicalUnit[]>('/v1/units/canonical').then((r) => r.data)
  },
  getCustomUnitAliases(): Promise<CustomUnitAlias[]> {
    return client.get<CustomUnitAlias[]>('/v1/units/custom-aliases').then((r) => r.data)
  },
  suggestUnits(rawUnit: string, sourceSystem?: string | null): Promise<UnitSuggestion[]> {
    const params: Record<string, string> = { q: rawUnit }
    if (sourceSystem) params.source_system = sourceSystem
    return client.get<UnitSuggestion[]>('/v1/units/suggest', { params }).then((r) => r.data)
  },
  resolveUnknownUnit(rawUnit: string, sourceSystem: string | null, canonicalUnit: string): Promise<NormalizationHealth> {
    return client
      .post<NormalizationHealth>('/v1/normalization-health/resolve-unit', { rawUnit, sourceSystem, canonicalUnit })
      .then((r) => r.data)
  },
  createCanonicalUnit(data: { canonical_unit: string; quantity?: string; symbol?: string; description?: string }): Promise<CanonicalUnit> {
    return client.post<CanonicalUnit>('/v1/units/canonical', data).then((r) => r.data)
  },
  deleteCanonicalUnit(name: string): Promise<void> {
    return client.delete(`/v1/units/canonical/${encodeURIComponent(name)}`).then(() => {})
  },
}
